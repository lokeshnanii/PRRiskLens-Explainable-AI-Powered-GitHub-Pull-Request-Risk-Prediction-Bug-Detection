import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";

export default function LoadingState() {
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const started = Date.now();
    const timer = window.setInterval(() => setElapsed(Math.floor((Date.now() - started) / 1000)), 1000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <div className="glass-panel flex flex-col items-center gap-4 p-8 text-center sm:p-12" role="status" aria-live="polite">
      <div className="relative grid h-16 w-16 place-items-center">
        <span className="absolute inset-0 rounded-full border border-brand-400/25 animate-pulse-ring" aria-hidden="true" />
        <span className="absolute inset-2 rounded-full border border-aqua-400/20" aria-hidden="true" />
        <Loader2 className="h-7 w-7 animate-spin text-brand-300" aria-hidden="true" />
      </div>
      <div>
        <p className="text-sm font-semibold text-white">Analyzing the change…</p>
        <p className="mx-auto mt-2 max-w-xl text-[12px] leading-relaxed text-slate-400">
          Validating the link, fetching GitHub metadata and patches, extracting the six historical
          features, scoring with the trained model when available, computing explanations, and
          scanning the changed lines. Large pull requests can take a while.
        </p>
        <p className="mt-3 font-mono text-[11px] text-slate-500" aria-label={`Elapsed time ${elapsed} seconds`}>
          elapsed {elapsed}s
        </p>
      </div>
    </div>
  );
}
