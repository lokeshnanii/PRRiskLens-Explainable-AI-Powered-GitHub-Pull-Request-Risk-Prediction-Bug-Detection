import type { RiskCategory } from "../types/analysis";
import { RISK_TONE } from "../lib/format";

interface RiskRingProps {
  score: number | null;
  category: RiskCategory | null;
  size?: number;
}

export default function RiskRing({ score, category, size = 184 }: RiskRingProps) {
  const stroke = 10;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const clamped = score === null ? 0 : Math.max(0, Math.min(100, score));
  const offset = circumference - (clamped / 100) * circumference;
  const tone = category ? RISK_TONE[category] : null;
  const color = tone?.ring ?? "#64748b";

  return (
    <div
      className={`relative grid place-items-center ${tone?.glow ?? ""}`}
      style={{ width: size, height: size }}
      role="img"
      aria-label={
        score === null
          ? "No risk score is available"
          : `Risk score ${score} out of 100, category ${category ?? "unknown"}`
      }
    >
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90" aria-hidden="true">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="rgba(148,163,184,0.14)"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="transition-[stroke-dashoffset] duration-700 ease-out"
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <div className="font-mono text-4xl font-semibold tracking-tight text-white tabular-nums">
            {score === null ? "—" : score.toFixed(1)}
          </div>
          <div className="mt-1 text-[10px] uppercase tracking-[0.2em] text-slate-500">risk index</div>
          <div className={`mt-2 text-sm font-semibold ${tone?.text ?? "text-slate-400"}`}>
            {category ?? "Unavailable"}
          </div>
        </div>
      </div>
    </div>
  );
}
