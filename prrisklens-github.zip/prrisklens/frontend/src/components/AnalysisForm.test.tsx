import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import AnalysisForm from "./AnalysisForm";

function setup() {
  const onSubmit = vi.fn();
  const onClear = vi.fn();
  render(<AnalysisForm onSubmit={onSubmit} onClear={onClear} loading={false} />);
  return { onSubmit, onClear, input: screen.getByRole("textbox") };
}

describe("AnalysisForm", () => {
  it("shows a validation message for non-GitHub URLs and does not submit", () => {
    const { onSubmit, input } = setup();

    fireEvent.change(input, { target: { value: "https://gitlab.com/owner/repo/pull/1" } });
    fireEvent.click(screen.getByRole("button", { name: /analyze/i }));

    expect(onSubmit).not.toHaveBeenCalled();
    expect(screen.getByRole("alert")).toHaveTextContent(/Only github.com URLs are supported/i);
    expect(input).toHaveAttribute("aria-invalid", "true");
  });

  it("submits the canonical pull request URL", () => {
    const { onSubmit, input } = setup();

    fireEvent.change(input, { target: { value: "https://github.com/pallets/flask/pull/123/" } });
    fireEvent.click(screen.getByRole("button", { name: /analyze/i }));

    expect(onSubmit).toHaveBeenCalledWith("https://github.com/pallets/flask/pull/123");
  });

  it("clears the form and notifies the parent", () => {
    const { onClear, input } = setup();

    fireEvent.change(input, { target: { value: "https://github.com/pallets/flask/pull/123" } });
    fireEvent.click(screen.getByRole("button", { name: /clear/i }));

    expect(onClear).toHaveBeenCalledTimes(1);
    expect(input).toHaveValue("");
  });

  it("disables submission while loading", () => {
    render(<AnalysisForm onSubmit={vi.fn()} onClear={vi.fn()} loading />);

    expect(screen.getByRole("button", { name: /analyzing/i })).toBeDisabled();
    expect(screen.getByRole("textbox")).toBeDisabled();
  });
});
