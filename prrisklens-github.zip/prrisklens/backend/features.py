"""Extraction of the six historical model features from GitHub metadata.

Historical counts are computed with GitHub queries bounded by a cutoff that is
strictly before the analyzed change. For pull requests the cutoff is the
earliest commit's authored time, which prevents later commits from leaking
into the historical counts (see ``PR_AGGREGATION_NOTE``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from config import Settings
from core import FEATURES, TIMEZONE_CONVENTION, detect_bug_fix
from gh import ChangeSnapshot, GitHubClient, GitHubError

PR_AGGREGATION_NOTE = (
    "Pull request size features use the aggregated base...head diff. Historical "
    "features (author history and prior bug fixes) and commit_hour use the "
    "earliest commit's authored UTC timestamp and the pull request author, so "
    "commits later in the pull request cannot influence the counts."
)
COMMIT_AGGREGATION_NOTE = (
    "Commit features use the commit's own file statistics and its authored UTC "
    "timestamp. Historical counts only include commits strictly before that time."
)
HISTORY_LIMITATION_NOTE = (
    "Prior bug fixes are counted inside a bounded per-file commit window, not the "
    "repository's complete history."
)


@dataclass
class FeatureExtraction:
    values: dict[str, int]
    provenance: dict[str, str]
    completeness: dict[str, str]
    warnings: list[str] = field(default_factory=list)
    notes: dict[str, Any] = field(default_factory=dict)
    aggregation_note: str = ""

    @property
    def overall_completeness(self) -> str:
        states = list(self.completeness.values())
        if all(state == "unavailable" for state in states):
            return "unavailable"
        if any(state != "complete" for state in states):
            return "partial"
        return "complete"

    def to_dict(self) -> dict[str, Any]:
        return {
            "values": self.values,
            "order": list(FEATURES),
            "timezone": TIMEZONE_CONVENTION,
            "provenance": self.provenance,
            "completeness": self.completeness,
            "overall_completeness": self.overall_completeness,
            "aggregation": self.aggregation_note,
            "history": self.notes,
            "warnings": self.warnings,
        }


def _parse_date(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _prior_bug_fixes(
    client: GitHubClient,
    snapshot: ChangeSnapshot,
    cutoff: datetime,
    settings: Settings,
    warnings: list[str],
) -> tuple[int, dict[str, Any]]:
    files = sorted(
        snapshot.files,
        key=lambda item: (item.additions + item.deletions, item.filename),
        reverse=True,
    )
    sampled = files[: settings.max_history_files]
    analyzed_shas = snapshot.analyzed_shas
    fixes: dict[str, str] = {}
    truncated_windows = 0
    checked = 0
    errors = 0

    for changed in sampled:
        if not changed.filename:
            continue
        try:
            items = client.list_file_commits_before(
                snapshot.owner,
                snapshot.repo,
                changed.filename,
                cutoff,
                per_page=settings.history_commits_per_file,
            )
        except GitHubError as exc:
            if exc.code == "github_not_found":
                continue
            # History is part of the required feature values: surface failures
            # instead of silently pretending the count is zero.
            raise
        checked += 1
        if len(items) >= settings.history_commits_per_file:
            truncated_windows += 1
        for item in items:
            sha = str(item.get("sha") or "").lower()
            if not sha or sha in analyzed_shas:
                continue
            parents = item.get("parents") or []
            if isinstance(parents, list) and len(parents) > 1:
                continue  # merge commits are not treated as bug fixes
            detail = item.get("commit") or {}
            authored = _parse_date((detail.get("author") or {}).get("date"))
            if authored is None or authored >= cutoff:
                continue
            message = str(detail.get("message") or "")
            signal = detect_bug_fix(message)
            if signal.is_candidate:
                fixes[sha] = message[:200]

    if truncated_windows:
        warnings.append(
            "The per-file history window was full for "
            f"{truncated_windows} file(s); older bug-fix commits may not be counted."
        )
    if len(files) > len(sampled):
        warnings.append(
            f"Prior bug fixes were counted for the {len(sampled)} most-changed files "
            f"out of {len(files)} changed files."
        )
    notes = {
        "files_considered": len(files),
        "files_sampled": checked,
        "files_skipped": len(files) - len(sampled),
        "history_window_per_file": settings.history_commits_per_file,
        "truncated_windows": truncated_windows,
        "bug_fix_commits_matched": len(fixes),
        "method": "message heuristic over bounded per-file commit history",
        "errors": errors,
    }
    return len(fixes), notes


def extract_features(
    client: GitHubClient,
    snapshot: ChangeSnapshot,
    settings: Settings,
) -> FeatureExtraction:
    warnings = list(snapshot.warnings)
    cutoff = snapshot.earliest_commit_at.astimezone(timezone.utc)
    if snapshot.kind == "pull_request":
        aggregation_note = PR_AGGREGATION_NOTE
        if snapshot.timestamps_fallback or not snapshot.commits:
            warnings.append(
                "Commit timestamps were incomplete, so pull request creation time was "
                "used for historical feature cutoffs."
            )
    else:
        aggregation_note = COMMIT_AGGREGATION_NOTE

    commit_hour = cutoff.hour

    author = snapshot.author_login
    completeness: dict[str, str] = {}
    provenance: dict[str, str] = {}

    values: dict[str, int] = {
        "files_changed": max(0, int(snapshot.total_files)),
        "lines_added": max(0, int(snapshot.total_additions)),
        "lines_deleted": max(0, int(snapshot.total_deletions)),
    }
    size_source = (
        "github_pull_request_totals"
        if snapshot.kind == "pull_request"
        else "github_commit_stats"
    )
    for name in ("files_changed", "lines_added", "lines_deleted"):
        provenance[name] = size_source
        completeness[name] = "complete"
    if snapshot.files_truncated:
        completeness["files_changed"] = "partial"
        completeness["lines_added"] = "partial"
        completeness["lines_deleted"] = "partial"

    if author:
        try:
            prior_commits, capped = client.count_commits_before(
                snapshot.owner, snapshot.repo, author, cutoff
            )
            values["previous_author_commits"] = prior_commits
            completeness["previous_author_commits"] = "partial" if capped else "complete"
            provenance["previous_author_commits"] = (
                "github_commit_count(author, until=cutoff-1s)"
            )
            if capped:
                warnings.append(
                    "The author's prior commit count was capped at 5000; the model "
                    "receives a lower bound."
                )
        except GitHubError as exc:
            raise exc
    else:
        values["previous_author_commits"] = 0
        completeness["previous_author_commits"] = "unavailable"
        provenance["previous_author_commits"] = "unavailable(missing_author)"
        warnings.append(
            "The change author could not be resolved, so previous_author_commits "
            "was set to 0 and marked unavailable."
        )

    try:
        prior_fixes, history_notes = _prior_bug_fixes(
            client, snapshot, cutoff, settings, warnings
        )
        values["prior_bug_fixes_in_touched_files"] = prior_fixes
        completeness["prior_bug_fixes_in_touched_files"] = "partial"
        provenance["prior_bug_fixes_in_touched_files"] = (
            "github_file_commit_history(heuristic bug-fix messages)"
        )
    except GitHubError:
        raise

    values["commit_hour"] = commit_hour
    provenance["commit_hour"] = (
        "earliest_pull_request_commit_authored_utc"
        if snapshot.kind == "pull_request"
        else "commit_authored_utc"
    )
    completeness["commit_hour"] = "partial" if snapshot.timestamps_fallback else "complete"

    if not settings.github_token:
        warnings.append(
            "GITHUB_TOKEN is not configured: GitHub API requests are unauthenticated "
            "and limited (normally 60 requests/hour), and history windows are bounded."
        )

    ordered_values = {name: values[name] for name in FEATURES}
    ordered_completeness = {name: completeness[name] for name in FEATURES}
    ordered_provenance = {name: provenance[name] for name in FEATURES}
    notes = dict(history_notes)
    notes["cutoff_utc"] = cutoff.isoformat().replace("+00:00", "Z")
    notes["author"] = author

    return FeatureExtraction(
        values=ordered_values,
        provenance=ordered_provenance,
        completeness=ordered_completeness,
        warnings=list(dict.fromkeys(warnings)),
        notes=notes,
        aggregation_note=aggregation_note,
    )
