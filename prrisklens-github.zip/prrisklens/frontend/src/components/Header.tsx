import { Activity, Gauge, Github, RefreshCw, ShieldCheck } from "lucide-react";
import { formatDate, formatNumber } from "../lib/format";
import type { GitHubRateLimitResponse, HealthResponse } from "../types/analysis";

interface HeaderProps {
  health: HealthResponse | null;
  healthLoading: boolean;
  onRefreshHealth: () => void;
  rateLimit: GitHubRateLimitResponse | null;
  rateLimitLoading: boolean;
  onRefreshRateLimit: () => void;
}

const navItems = [
  { href: "#analyze", label: "Dashboard" },
  { href: "#how-it-works", label: "How It Works" },
  { href: "#methodology", label: "Methodology" },
];

export default function Header({
  health,
  healthLoading,
  onRefreshHealth,
  rateLimit,
  rateLimitLoading,
  onRefreshRateLimit,
}: HeaderProps) {
  const repoUrl = import.meta.env.VITE_GITHUB_REPO_URL;
  const online = Boolean(health);
  const modelReady = Boolean(health?.model_available);

  const authInfo = rateLimit ?? health?.github ?? null;
  const authenticated = Boolean(authInfo?.authenticated);
  const snapshot = rateLimit?.rate_limit ?? null;
  const limit = snapshot?.limit ?? authInfo?.expected_hourly_limit ?? null;
  const remaining = snapshot?.remaining ?? null;
  const lowQuota =
    snapshot?.near_limit ??
    (remaining !== null && limit !== null && limit > 0
      ? remaining <= Math.max(10, Math.floor(limit * 0.1))
      : false);
  const errorCode = rateLimit?.error?.code;
  const reset = snapshot?.reset_at ? formatDate(snapshot.reset_at) : null;

  const quotaLabel =
    rateLimitLoading && !snapshot
      ? "GitHub quota…"
      : remaining !== null && limit !== null
        ? `${formatNumber(remaining)}/${formatNumber(limit)}`
        : errorCode === "github_unauthorized"
          ? "Token rejected"
          : errorCode
            ? "Quota unavailable"
            : "Quota unknown";

  const quotaTitle = rateLimit?.error
    ? `GitHub quota unavailable: ${rateLimit.error.message}`
    : remaining !== null && limit !== null
      ? `${authenticated ? "Authenticated" : "Unauthenticated"} GitHub quota: ${formatNumber(remaining)} of ${formatNumber(limit)} requests remaining${reset ? ` · resets ${reset}` : ""}`
      : `${authenticated ? "Authenticated" : "Unauthenticated"} GitHub requests. Click to refresh the quota.`;

  return (
    <header className="sticky top-0 z-40 border-b border-white/[0.06] bg-ink-950/70 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-x-6 gap-y-3 px-4 py-3.5 sm:px-6 lg:px-8">
        <a href="#top" className="flex items-center gap-2.5 rounded-lg focus-visible:outline-offset-4">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-500 via-brand-400 to-aqua-400 shadow-glow">
            <ShieldCheck className="h-5 w-5 text-ink-950" aria-hidden="true" />
          </span>
          <span className="flex flex-col leading-tight">
            <span className="text-sm font-semibold tracking-tight text-white">PRRiskLens</span>
            <span className="text-[10px] uppercase tracking-[0.18em] text-slate-500">Risk intelligence</span>
          </span>
        </a>

        <nav aria-label="Primary" className="order-3 flex w-full items-center gap-1 overflow-x-auto sm:order-none sm:w-auto">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="rounded-lg px-3 py-2 text-[13px] font-medium text-slate-400 transition hover:bg-white/[0.05] hover:text-white"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <button
            type="button"
            onClick={onRefreshHealth}
            className="group flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] py-1.5 pl-2.5 pr-3 text-[11px] font-medium text-slate-300 transition hover:border-white/20 hover:text-white"
            aria-label="Refresh backend status"
            title={
              online
                ? `Backend online · ${modelReady ? "model loaded" : "no trained model"}`
                : "Backend status unknown"
            }
          >
            <span
              className={`h-2 w-2 rounded-full ${
                healthLoading ? "animate-pulse bg-slate-400" : online ? "bg-emerald-400" : "bg-rose-400"
              }`}
              aria-hidden="true"
            />
            <span>{healthLoading ? "Checking API" : online ? "API online" : "API offline"}</span>
            <Activity className={`h-3.5 w-3.5 ${online && modelReady ? "text-emerald-300" : "text-slate-500"}`} aria-hidden="true" />
            <RefreshCw className="h-3 w-3 text-slate-500 transition group-hover:text-slate-300" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={onRefreshRateLimit}
            className={`group flex items-center gap-2 rounded-full border py-1.5 pl-2.5 pr-3 text-[11px] font-medium transition ${
              lowQuota
                ? "border-rose-400/30 bg-rose-500/[0.07] text-rose-200"
                : "border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/20 hover:text-white"
            }`}
            aria-label="Refresh GitHub API quota"
            title={quotaTitle}
          >
            <Gauge
              className={`h-3.5 w-3.5 ${
                lowQuota
                  ? "text-rose-300"
                  : authenticated
                    ? "text-emerald-300"
                    : "text-amber-300"
              }`}
              aria-hidden="true"
            />
            <span>{quotaLabel}</span>
            {authInfo ? (
              <span className="hidden text-[10px] font-normal text-slate-500 sm:inline">
                {authenticated ? "token" : "public"}
              </span>
            ) : null}
            <RefreshCw className="h-3 w-3 text-slate-500 transition group-hover:text-slate-300" aria-hidden="true" />
          </button>

          {repoUrl ? (
            <a
              href={repoUrl}
              target="_blank"
              rel="noreferrer noopener"
              className="btn-ghost !px-3 !py-1.5 !text-[11px]"
            >
              <Github className="h-4 w-4" aria-hidden="true" />
              <span className="hidden sm:inline">Repository</span>
            </a>
          ) : null}
        </div>
      </div>
    </header>
  );
}
