import { fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import App from "./App";
import { DISCLAIMER } from "./lib/format";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("App", () => {
  it("renders the dashboard and surfaces an offline backend without crashing", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("fetch failed")));

    render(<App />);

    expect(
      screen.getByRole("heading", { level: 1, name: /Catch risky changes/i }),
    ).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /analyze/i })).toBeInTheDocument();
    expect(await screen.findByText(/API offline/i)).toBeInTheDocument();
    expect(screen.getByText(/The backend does not respond/i)).toBeInTheDocument();
    expect(screen.getAllByText(DISCLAIMER).length).toBeGreaterThan(0);
  });

  it("keeps URL and manual modes visually separate", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("fetch failed")));
    render(<App />);

    expect(screen.getByText(/Fetches real GitHub metadata/i)).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /manual features/i }));

    expect(screen.getByRole("button", { name: /predict risk/i })).toBeInTheDocument();
    expect(screen.getByText(/Score a change without fetching GitHub/i)).toBeInTheDocument();
    expect(await screen.findByText(/API offline/i)).toBeInTheDocument();
  });
});
