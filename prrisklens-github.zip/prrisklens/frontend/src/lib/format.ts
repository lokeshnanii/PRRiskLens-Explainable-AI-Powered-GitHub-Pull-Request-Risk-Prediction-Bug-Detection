import type { RiskCategory, Severity } from "../types/analysis";

export const DISCLAIMER =
  "PRRiskLens provides a historical risk ranking and potential bug indicators to assist code review. " +
  "SZZ-derived labels are approximate, historical associations do not prove causation, and model " +
  "performance may not generalize to repositories outside the training data. A low-risk score does " +
  "not guarantee bug-free code.";

export const RISK_TONE: Record<RiskCategory, { text: string; ring: string; chip: string; glow: string }> = {
  Low: {
    text: "text-emerald-300",
    ring: "#34d399",
    chip: "border-emerald-400/30 bg-emerald-400/10 text-emerald-200",
    glow: "shadow-[0_0_45px_-15px_rgba(52,211,153,0.65)]",
  },
  Medium: {
    text: "text-amber-300",
    ring: "#fbbf24",
    chip: "border-amber-400/30 bg-amber-400/10 text-amber-200",
    glow: "shadow-[0_0_45px_-15px_rgba(251,191,36,0.6)]",
  },
  High: {
    text: "text-rose-300",
    ring: "#fb7185",
    chip: "border-rose-400/30 bg-rose-400/10 text-rose-200",
    glow: "shadow-[0_0_45px_-15px_rgba(251,113,133,0.65)]",
  },
};

export const SEVERITY_TONE: Record<Severity, { label: string; chip: string; dot: string }> = {
  high: {
    label: "High",
    chip: "border-rose-400/30 bg-rose-400/10 text-rose-200",
    dot: "bg-rose-400",
  },
  medium: {
    label: "Medium",
    chip: "border-amber-400/30 bg-amber-400/10 text-amber-200",
    dot: "bg-amber-400",
  },
  low: {
    label: "Low",
    chip: "border-sky-400/30 bg-sky-400/10 text-sky-200",
    dot: "bg-sky-400",
  },
  info: {
    label: "Info",
    chip: "border-slate-400/30 bg-slate-400/10 text-slate-300",
    dot: "bg-slate-400",
  },
};

export const SEVERITY_ORDER: Record<Severity, number> = {
  high: 0,
  medium: 1,
  low: 2,
  info: 3,
};

export function formatDate(value: string | null | undefined): string {
  if (!value) return "Unavailable";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

export function formatNumber(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";
  return new Intl.NumberFormat().format(value);
}

export function shortSha(value: string | null | undefined, length = 7): string {
  if (!value) return "—";
  return value.length > length ? value.slice(0, length) : value;
}

export function formatDuration(ms: number): string {
  if (!Number.isFinite(ms) || ms < 0) return "—";
  if (ms < 1000) return `${Math.round(ms)} ms`;
  return `${(ms / 1000).toFixed(1)} s`;
}

export function formatPercent(value: number | null | undefined, digits = 1): string {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";
  return `${(value * 100).toFixed(digits)}%`;
}

export function titleCase(value: string): string {
  return value.replace(/[_-]+/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

export function featureValueLabel(name: string, value: number): string {
  if (name === "commit_hour") return `${String(value).padStart(2, "0")}:00 UTC`;
  return formatNumber(value);
}

export function riskDescription(category: RiskCategory, thresholds: { low_max: number; high_min: number }): string {
  if (category === "Low") {
    return `The model ranked this change below ${thresholds.low_max} on its 0-100 ranking index. Treat this as a prioritisation hint, not a safety guarantee.`;
  }
  if (category === "Medium") {
    return `The model ranked this change between ${thresholds.low_max} and ${thresholds.high_min}. Review the contributing factors and the code findings together.`;
  }
  return `The model ranked this change at or above ${thresholds.high_min}. Prioritise review, but confirm every concern in the code itself.`;
}
