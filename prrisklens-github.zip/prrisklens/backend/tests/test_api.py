"""API contract tests using FastAPI TestClient and an injected fake GitHub client."""

from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app import create_app
from config import Settings
from conftest import FakeGitHubClient, make_pull_snapshot, utc
from core import FEATURES
from gh import GitHubError, RateLimitSnapshot
from inference import ModelRegistry

VALID_FEATURES = {
    "files_changed": 4,
    "lines_added": 120,
    "lines_deleted": 30,
    "previous_author_commits": 25,
    "prior_bug_fixes_in_touched_files": 2,
    "commit_hour": 14,
}


def build_client(settings: Settings, snapshot=None) -> tuple[TestClient, FakeGitHubClient]:
    fake = FakeGitHubClient(snapshot or make_pull_snapshot())
    app = create_app(
        settings,
        client_factory=lambda: fake,
        registry=ModelRegistry(settings.models_dir),
    )
    return TestClient(app), fake


@pytest.fixture
def api(trained_models: Path, tmp_path: Path, snapshot):
    settings = Settings(
        github_token="test-token",
        models_dir=trained_models,
        data_dir=tmp_path / "data",
        rate_limit_per_minute=1000,
    )
    fake = FakeGitHubClient(snapshot)
    app = create_app(
        settings,
        client_factory=lambda: fake,
        registry=ModelRegistry(trained_models),
    )
    with TestClient(app) as client:
        yield client, fake


@pytest.fixture
def api_without_model(tmp_path: Path, snapshot):
    settings = Settings(
        github_token="test-token",
        models_dir=tmp_path / "missing-models",
        data_dir=tmp_path / "data",
        rate_limit_per_minute=1000,
    )
    fake = FakeGitHubClient(snapshot)
    app = create_app(
        settings,
        client_factory=lambda: fake,
        registry=ModelRegistry(settings.models_dir),
    )
    with TestClient(app) as client:
        yield client, fake


# ---------------------------------------------------------------------------
# Health and model information
# ---------------------------------------------------------------------------


def test_health_reports_loaded_model(api):
    client, _ = api
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["model_available"] is True
    assert body["model_version"]
    assert body["model_type"] in {"xgboost", "logistic"}
    assert body["feature_schema_version"] == "1.0.0"
    assert body["reason"] is None


def test_health_reports_missing_model(api_without_model):
    client, _ = api_without_model
    body = client.get("/health").json()
    assert body["model_available"] is False
    assert "No trained model" in body["reason"]


def test_health_reports_authenticated_github_mode(api):
    client, _ = api
    response = client.get("/health")
    body = response.json()
    assert body["github"]["authenticated"] is True
    assert body["github"]["mode"] == "authenticated"
    assert body["github"]["token_configured"] is True
    assert body["github"]["expected_hourly_limit"] == 5000
    assert body["github"]["note"]
    assert "test-token" not in response.text


def test_health_reports_unauthenticated_github_mode(trained_models: Path, tmp_path: Path):
    settings = Settings(
        github_token=None,
        models_dir=trained_models,
        data_dir=tmp_path / "data",
        rate_limit_per_minute=1000,
    )
    client, _ = build_client(settings)
    body = client.get("/health").json()
    assert body["github"]["authenticated"] is False
    assert body["github"]["mode"] == "unauthenticated"
    assert body["github"]["expected_hourly_limit"] == 60
    assert "GITHUB_TOKEN" in body["github"]["note"]


def test_github_rate_limit_endpoint_reports_quota(api):
    client, _ = api
    response = client.get("/github-rate-limit")
    assert response.status_code == 200
    body = response.json()
    assert body["authenticated"] is True
    assert body["expected_hourly_limit"] == 5000
    assert body["rate_limit"]["limit"] == 5000
    assert body["rate_limit"]["remaining"] == 4987
    assert body["rate_limit"]["reset_at"].startswith("2024-05-01")
    assert body["error"] is None
    assert "test-token" not in response.text


def test_github_rate_limit_endpoint_surfaces_errors(trained_models: Path, tmp_path: Path):
    fake = FakeGitHubClient(
        rate_limit_error=GitHubError(
            "github_unauthorized",
            "GitHub rejected the configured GITHUB_TOKEN (401).",
            502,
            {"authenticated": True},
        )
    )
    settings = Settings(
        github_token="test-token",
        models_dir=trained_models,
        data_dir=tmp_path / "data",
        rate_limit_per_minute=1000,
    )
    app = create_app(
        settings,
        client_factory=lambda: fake,
        registry=ModelRegistry(trained_models),
    )
    with TestClient(app) as client:
        response = client.get("/github-rate-limit")
    assert response.status_code == 200
    body = response.json()
    assert body["error"]["code"] == "github_unauthorized"
    assert body["authenticated"] is True


def test_model_info_exposes_schema_and_metrics(api):
    client, _ = api
    response = client.get("/model-info")
    assert response.status_code == 200
    body = response.json()
    assert body["available"] is True
    assert [feature["name"] for feature in body["features"]] == list(FEATURES)
    assert all(feature["label"] and feature["description"] for feature in body["features"])
    assert body["thresholds"] == {"low_max": 35.0, "high_min": 70.0}
    assert body["training"]["rows"] > 0
    assert body["metrics"]["test_size"] > 0
    assert body["training_config"]["split"].startswith("chronological")
    assert body["evaluation"] == {"results_available": True, "status": "ok"}
    assert body["training_required"] is False


def test_model_info_when_unavailable(api_without_model):
    client, _ = api_without_model
    body = client.get("/model-info").json()
    assert body["available"] is False
    assert body["training_required"] is True
    assert body["reason"]


# ---------------------------------------------------------------------------
# Manual prediction
# ---------------------------------------------------------------------------


def test_predict_with_trained_model(api):
    client, _ = api
    response = client.post("/predict", json=VALID_FEATURES)
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert 0 <= body["risk_score"] <= 100
    assert body["risk_category"] in {"Low", "Medium", "High"}
    assert body["input_features"] == VALID_FEATURES
    assert body["feature_order"] == list(FEATURES)
    assert 1 <= len(body["factors"]) <= 3
    assert len(body["all_contributions"]) == 6
    assert body["shap_available"] is True
    assert body["thresholds"] == {"low_max": 35.0, "high_min": 70.0}
    assert "calibrated" in body["model_output_note"]


def test_predict_without_model_returns_503(api_without_model):
    client, _ = api_without_model
    response = client.post("/predict", json=VALID_FEATURES)
    assert response.status_code == 503
    error = response.json()["error"]
    assert error["code"] == "model_unavailable"
    assert error["details"]["training_required"] is True


@pytest.mark.parametrize(
    "payload",
    [
        {**VALID_FEATURES, "commit_hour": 24},
        {**VALID_FEATURES, "files_changed": -2},
        {**VALID_FEATURES, "lines_added": 1.5},
        {**VALID_FEATURES, "previous_author_commits": True},
        {key: value for key, value in VALID_FEATURES.items() if key != "commit_hour"},
        {**VALID_FEATURES, "unexpected": 1},
        {},
    ],
)
def test_predict_validates_payload(api, payload):
    client, _ = api
    response = client.post("/predict", json=payload)
    assert response.status_code == 422
    error = response.json()["error"]
    assert error["code"] == "validation_error"
    assert error["details"]["errors"]


def test_validation_errors_do_not_echo_values(api):
    client, _ = api
    response = client.post("/predict", json={**VALID_FEATURES, "unexpected": "super-secret-value"})
    assert "super-secret-value" not in response.text


# ---------------------------------------------------------------------------
# URL analysis
# ---------------------------------------------------------------------------


def test_predict_url_returns_full_analysis(api):
    client, fake = api
    response = client.post("/predict_url", json={"url": "https://github.com/pallets/flask/pull/123"})
    assert response.status_code == 200
    body = response.json()

    assert body["analysis_id"]
    assert body["generated_at"].endswith("Z")
    assert body["source"]["kind"] == "pull"
    assert body["repository"]["full_name"] == "pallets/flask"
    assert body["change"]["title"] == "Add user lookup endpoint"
    assert body["features"]["values"] == {
        "files_changed": 3,
        "lines_added": 5,
        "lines_deleted": 4,
        "previous_author_commits": 12,
        "prior_bug_fixes_in_touched_files": 1,
        "commit_hour": 13,
    }
    assert body["features"]["order"] == list(FEATURES)
    assert body["prediction"]["status"] == "ok"
    assert body["prediction"]["risk_category"] in {"Low", "Medium", "High"}
    assert len(body["prediction"]["all_contributions"]) == 6

    assert body["code_analysis"]["status"] == "complete"
    detector_names = {finding["detector"] for finding in body["code_analysis"]["findings"]}
    assert {"sql_injection", "hardcoded_secret", "weakened_tests"} <= detector_names
    assert all(finding["verification"] in {"potential", "unverified"} for finding in body["code_analysis"]["findings"])
    assert all(finding["file"] and finding["evidence"] for finding in body["code_analysis"]["findings"])

    assert len(body["changed_files"]) == 3
    assert all("findings_count" in item for item in body["changed_files"])
    assert body["review_checklist"]
    assert body["data_completeness"]["overall"] in {"complete", "partial"}
    assert body["timings_ms"]["total"] >= 0
    assert body["thresholds"] == {"low_max": 35.0, "high_min": 70.0}

    # The token must never appear in a response.
    assert "test-token" not in response.text
    assert "Authorization" not in response.text
    # The fake client was used exactly once with the validated URL.
    assert fake.snapshot.owner == "pallets"


def test_predict_url_includes_github_auth_and_quota(api):
    client, _ = api
    response = client.post("/predict_url", json={"url": "https://github.com/pallets/flask/pull/123"})
    assert response.status_code == 200
    body = response.json()
    assert body["github"]["authenticated"] is True
    assert body["github"]["mode"] == "authenticated"
    assert body["github"]["expected_hourly_limit"] == 5000
    assert body["github"]["rate_limit"]["limit"] == 5000
    assert body["github"]["rate_limit"]["remaining"] == 4987
    assert "test-token" not in response.text


def test_predict_url_reports_unauthenticated_quota(trained_models: Path, tmp_path: Path):
    settings = Settings(
        github_token="your_github_personal_access_token",
        models_dir=trained_models,
        data_dir=tmp_path / "data",
        rate_limit_per_minute=1000,
    )
    fake = FakeGitHubClient(
        rate_limit_snapshot=RateLimitSnapshot(
            authenticated=False,
            limit=60,
            remaining=59,
            reset_at=utc(2024, 5, 1, 12, 0),
            observed_at=utc(2024, 5, 1, 11, 0),
        )
    )
    app = create_app(
        settings,
        client_factory=lambda: fake,
        registry=ModelRegistry(trained_models),
    )
    with TestClient(app) as client:
        response = client.post(
            "/predict_url", json={"url": "https://github.com/pallets/flask/pull/123"}
        )
    assert response.status_code == 200
    body = response.json()
    assert body["github"]["authenticated"] is False
    assert body["github"]["expected_hourly_limit"] == 60
    assert body["github"]["rate_limit"]["mode"] == "unauthenticated"


def test_predict_url_works_without_model(api_without_model):
    client, _ = api_without_model
    response = client.post("/predict_url", json={"url": "https://github.com/pallets/flask/pull/123"})
    assert response.status_code == 200
    body = response.json()
    assert body["prediction"]["status"] == "unavailable"
    assert body["prediction"]["model_training_required"] is True
    assert body["prediction"]["risk_score"] is None
    assert body["prediction"]["message"]
    # Code findings still come from the real diff.
    assert body["code_analysis"]["findings"]
    assert any(item["id"] == "model_missing" for item in body["review_checklist"])


def test_predict_url_rejects_invalid_url(api):
    client, _ = api
    for url in (
        "https://example.com/o/r/pull/1",
        "https://github.com/o/r/issues/1",
        "javascript:alert(1)",
        "http://169.254.169.254/latest/meta-data",
    ):
        response = client.post("/predict_url", json={"url": url})
        assert response.status_code == 422, url
        assert response.json()["error"]["code"] == "invalid_github_url"


def test_predict_url_surfaces_github_errors(tmp_path: Path):
    settings = Settings(
        github_token="test-token",
        models_dir=tmp_path / "models",
        data_dir=tmp_path / "data",
        rate_limit_per_minute=1000,
    )

    class FailingClient(FakeGitHubClient):
        def fetch(self, ref):
            raise GitHubError("github_not_found", "The repository was not found.", status_code=404)

    fake = FailingClient()
    app = create_app(settings, client_factory=lambda: fake, registry=ModelRegistry(settings.models_dir))
    with TestClient(app) as client:
        response = client.post("/predict_url", json={"url": "https://github.com/o/r/pull/1"})
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "github_not_found"


def test_predict_url_rejects_extra_fields(api):
    client, _ = api
    response = client.post(
        "/predict_url",
        json={"url": "https://github.com/o/r/pull/1", "callback": "http://evil.test"},
    )
    assert response.status_code == 422


# ---------------------------------------------------------------------------
# Cross-cutting behaviour
# ---------------------------------------------------------------------------


def test_rate_limiting(tmp_path: Path):
    settings = Settings(models_dir=tmp_path / "models", rate_limit_per_minute=1)
    app = create_app(settings, registry=ModelRegistry(settings.models_dir))
    with TestClient(app) as client:
        assert client.get("/model-info").status_code == 200
        blocked = client.get("/model-info")
        assert blocked.status_code == 429
        assert blocked.json()["error"]["code"] == "rate_limited"
        assert blocked.headers.get("Retry-After")
        # Health checks are exempt.
        assert client.get("/health").status_code == 200


def test_request_body_limit(tmp_path: Path):
    settings = Settings(models_dir=tmp_path / "models", max_request_bytes=128)
    app = create_app(settings, registry=ModelRegistry(settings.models_dir))
    with TestClient(app) as client:
        response = client.post(
            "/predict",
            content=b"x" * 200,
            headers={"content-type": "application/json"},
        )
    assert response.status_code == 413
    assert response.json()["error"]["code"] == "request_too_large"


def test_unknown_route_uses_error_envelope():
    client = TestClient(create_app(Settings(models_dir=Path("/tmp/no-model"))))
    response = client.get("/does-not-exist")
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "not_found"


def test_security_headers(tmp_path: Path):
    app = create_app(Settings(models_dir=tmp_path / "models"), registry=ModelRegistry(tmp_path / "models"))
    with TestClient(app) as client:
        response = client.get("/health")
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-Frame-Options"] == "DENY"
    assert response.headers["Referrer-Policy"] == "no-referrer"


def test_cors_allows_configured_origin_only(tmp_path: Path):
    settings = Settings(
        models_dir=tmp_path / "models",
        frontend_origins=("http://localhost:5173",),
    )
    app = create_app(settings, registry=ModelRegistry(tmp_path / "models"))
    with TestClient(app) as client:
        allowed = client.get("/health", headers={"Origin": "http://localhost:5173"})
        denied = client.get("/health", headers={"Origin": "https://evil.example"})
    assert allowed.headers["access-control-allow-origin"] == "http://localhost:5173"
    assert "access-control-allow-origin" not in denied.headers


def test_root_endpoint_lists_capabilities():
    app = create_app(Settings(models_dir=Path("/tmp/no-model")))
    with TestClient(app) as client:
        body = client.get("/").json()
    assert body["name"] == "PRRiskLens API"
    assert "/predict_url" in body["endpoints"]
    assert "does not prove" in body["note"]
