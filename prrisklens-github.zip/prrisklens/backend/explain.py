"""SHAP-based explanations for model predictions.

Tree models use ``shap.TreeExplainer`` and linear models use
``shap.LinearExplainer``. Both produce contributions on the model's log-odds
scale. If SHAP is unavailable for logistic regression, a mathematically
equivalent coefficient-based fallback is used and labelled as such. XGBoost
has no fallback, so failures produce an explicit unavailable state rather than
invented values.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

import numpy as np

from core import FEATURE_LABELS, FEATURES


@dataclass
class Explanation:
    available: bool
    explanation_status: str
    method: str | None
    shap_used: bool
    base_value: float | None
    output_value: float | None
    contributions: list[dict[str, Any]] = field(default_factory=list)
    factors: list[dict[str, Any]] = field(default_factory=list)
    note: str | None = None
    error: str | None = None
    contribution_scale: str = "log-odds"

    def to_dict(self) -> dict[str, Any]:
        return {
            "available": self.available,
            "explanation_status": self.explanation_status,
            "method": self.method,
            "shap_used": self.shap_used,
            "base_value": self.base_value,
            "output_value": self.output_value,
            "contributions": self.contributions,
            "factors": self.factors,
            "note": self.note,
            "error": self.error,
            "contribution_scale": self.contribution_scale,
        }


def _plain_explanation(feature: str, value: int) -> str:
    if feature == "files_changed":
        return (
            f"The change touches {value} file(s), so more code and ownership boundaries "
            "need to be reviewed together."
        )
    if feature == "lines_added":
        return (
            f"The diff adds {value} line(s), creating more new code paths that may need "
            "additional tests and review."
        )
    if feature == "lines_deleted":
        return (
            f"The diff removes {value} line(s); deleted behavior may still be relied on by "
            "callers outside the changed diff."
        )
    if feature == "previous_author_commits":
        if value < 5:
            return (
                f"The author has only {value} earlier commit(s) in this repository at this "
                "point, so the historical author signal is less informative."
            )
        return (
            f"The author has {value} earlier commit(s) in this repository, which the model "
            "uses as a historical context signal."
        )
    if feature == "prior_bug_fixes_in_touched_files":
        return (
            f"Bug-fix-like commits touched these files {value} time(s) in the inspected "
            "history window before this change; that history is only an association, not proof "
            "of a defect."
        )
    if feature == "commit_hour":
        return (
            f"The earliest commit was authored at {value}:00 UTC. Authoring time is a weak "
            "contextual signal and is not evidence of a defect."
        )
    return f"The feature {feature} has value {value}."


def _contribution_note(contribution: float) -> str:
    if contribution > 0:
        return (
            f"This factor raised the model output by {abs(contribution):.3f} "
            "on the log-odds scale."
        )
    if contribution < 0:
        return (
            f"This factor lowered the model output by {abs(contribution):.3f} "
            "on the log-odds scale."
        )
    return "This factor did not change the model output."


def _flatten_shap(values: Any, expected_features: int) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    if isinstance(values, list):
        array = np.asarray(values[1] if len(values) > 1 else values[0], dtype=float)
    array = np.squeeze(array)
    if array.ndim == 0:
        array = array.reshape(1)
    if array.ndim > 1:
        array = array.reshape(-1)
    if array.shape[0] != expected_features:
        raise ValueError(
            f"SHAP returned {array.shape[0]} contributions for {expected_features} features"
        )
    if not np.all(np.isfinite(array)):
        raise ValueError("SHAP returned non-finite contributions")
    return array


def _base_value(value: Any) -> float | None:
    if value is None:
        return None
    array = np.asarray(value, dtype=float).reshape(-1)
    if array.size == 0:
        return None
    number = float(array[0])
    return number if np.isfinite(number) else None


def _build_result(
    *,
    values: Mapping[str, int],
    contributions: np.ndarray,
    method: str,
    shap_used: bool,
    base_value: float | None,
    output_value: float | None,
    note: str | None = None,
) -> Explanation:
    rows: list[dict[str, Any]] = []
    for index, feature in enumerate(FEATURES):
        contribution = float(contributions[index])
        rows.append(
            {
                "feature": feature,
                "label": FEATURE_LABELS[feature],
                "value": int(values[feature]),
                "contribution": round(contribution, 6),
                "direction": "raises" if contribution > 0 else ("lowers" if contribution < 0 else "neutral"),
                "explanation": _plain_explanation(feature, int(values[feature])),
                "contribution_note": _contribution_note(contribution),
            }
        )
    positive = sorted(
        (row for row in rows if row["contribution"] > 0),
        key=lambda row: row["contribution"],
        reverse=True,
    )
    factors = positive[:3]
    factor_note = None
    if not positive:
        factor_note = (
            "No feature made a positive contribution above the baseline; the score reflects "
            "the combined negative contributions, so no risk-raising factors are shown."
        )
    elif len(positive) < 3:
        factor_note = (
            f"Only {len(positive)} feature(s) had a positive contribution, so fewer than three "
            "risk-raising factors are shown."
        )
    combined_note = "; ".join(item for item in (note, factor_note) if item) or None
    return Explanation(
        available=True,
        explanation_status="available",
        method=method,
        shap_used=shap_used,
        base_value=round(base_value, 6) if base_value is not None else None,
        output_value=round(output_value, 6) if output_value is not None else None,
        contributions=rows,
        factors=factors,
        note=combined_note,
    )


def explain_prediction(model_bundle: Any, values: Mapping[str, int]) -> Explanation:
    """Compute contributions for one feature vector.

    ``model_bundle`` is duck-typed: it exposes ``kind``, ``model``, ``scaler``
    and ``background`` attributes.
    """

    features = list(FEATURES)
    x = np.asarray([[int(values[name]) for name in features]], dtype=float)
    kind = getattr(model_bundle, "kind", None)
    values_map = {name: int(values[name]) for name in FEATURES}

    try:
        import shap  # lazy: keeps API startup fast
    except Exception as exc:  # pragma: no cover - import environment failure
        return _fallback_linear(model_bundle, x, values_map, f"SHAP import failed: {exc}")

    if kind == "xgboost":
        try:
            explainer = shap.TreeExplainer(model_bundle.model)
            shap_values = explainer.shap_values(x, check_additivity=False)
            contributions = _flatten_shap(shap_values, len(FEATURES))
            base = _base_value(getattr(explainer, "expected_value", None))
            return _build_result(
                values=values_map,
                contributions=contributions,
                method="shap.TreeExplainer",
                shap_used=True,
                base_value=base,
                output_value=float(base + contributions.sum()) if base is not None else None,
                note=None,
            )
        except Exception as exc:
            return Explanation(
                available=False,
                explanation_status="unavailable",
                method="shap.TreeExplainer",
                shap_used=False,
                base_value=None,
                output_value=None,
                error=f"SHAP explanation failed: {exc}",
            )

    if kind == "logistic":
        try:
            scaled = model_bundle.scaler.transform(x)
            background = np.asarray(model_bundle.background, dtype=float)
            background_scaled = model_bundle.scaler.transform(background)
            masker = shap.maskers.Independent(background_scaled, max_samples=background_scaled.shape[0])
            explainer = shap.LinearExplainer(model_bundle.model, masker)
            shap_values = explainer.shap_values(scaled)
            contributions = _flatten_shap(shap_values, len(FEATURES))
            base = _base_value(getattr(explainer, "expected_value", None))
            return _build_result(
                values=values_map,
                contributions=contributions,
                method="shap.LinearExplainer",
                shap_used=True,
                base_value=base,
                output_value=float(base + contributions.sum()) if base is not None else None,
            )
        except Exception as exc:
            return _fallback_linear(
                model_bundle, x, values_map, f"SHAP LinearExplainer failed: {exc}"
            )

    return Explanation(
        available=False,
        explanation_status="unavailable",
        method=None,
        shap_used=False,
        base_value=None,
        output_value=None,
        error=f"Unknown model kind: {kind!r}",
    )


def _fallback_linear(
    model_bundle: Any,
    x: np.ndarray,
    values: Mapping[str, int],
    reason: str,
) -> Explanation:
    """Mathematically correct logistic log-odds contributions."""

    if getattr(model_bundle, "kind", None) != "logistic":
        return Explanation(
            available=False,
            explanation_status="unavailable",
            method=None,
            shap_used=False,
            base_value=None,
            output_value=None,
            error=reason,
        )
    try:
        scaler = model_bundle.scaler
        model = model_bundle.model
        background = np.asarray(model_bundle.background, dtype=float)
        background_scaled = scaler.transform(background)
        scaled = scaler.transform(x)
        coefficients = np.asarray(model.coef_, dtype=float).reshape(-1)
        if coefficients.shape[0] != len(FEATURES):
            raise ValueError("Coefficient count does not match the feature schema")
        contributions = coefficients * (scaled[0] - background_scaled.mean(axis=0))
        base = float(model.intercept_[0] + coefficients @ background_scaled.mean(axis=0))
        output = float(base + contributions.sum())
        return _build_result(
            values=values,
            contributions=contributions,
            method="linear_coefficient_fallback",
            shap_used=False,
            base_value=base,
            output_value=output,
            note=f"SHAP was unavailable ({reason}); contributions use the logistic coefficients.",
        )
    except Exception as exc:
        return Explanation(
            available=False,
            explanation_status="unavailable",
            method=None,
            shap_used=False,
            base_value=None,
            output_value=None,
            error=f"{reason}; coefficient fallback failed: {exc}",
        )
