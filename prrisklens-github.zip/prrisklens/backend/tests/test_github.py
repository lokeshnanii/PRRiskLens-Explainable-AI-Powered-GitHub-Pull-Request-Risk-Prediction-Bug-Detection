"""Offline tests for GitHub URL validation and REST response normalisation."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Callable
from urllib.parse import urlsplit

import pytest

import gh
from gh import GitHubClient, GitHubError, parse_github_url

HEAD_SHA = "c" * 40
BASE_SHA = "b" * 40
COMMIT_SHA = "a" * 40


class FakeResponse:
    def __init__(
        self,
        status_code: int = 200,
        payload: Any = None,
        headers: dict[str, str] | None = None,
        *,
        json_error: bool = False,
    ) -> None:
        self.status_code = status_code
        self._payload = payload
        self.headers = headers or {}
        self._json_error = json_error

    def json(self) -> Any:
        if self._json_error:
            raise ValueError("not json")
        return self._payload


class FakeSession:
    """Routes requests by API path to payloads or callables."""

    def __init__(self, routes: dict[str, Any]) -> None:
        self.routes = routes
        self.calls: list[dict[str, Any]] = []

    def get(self, url: str, params: dict[str, Any] | None = None, headers: dict[str, str] | None = None, timeout: float | None = None):
        path = urlsplit(url).path
        self.calls.append({"url": url, "path": path, "params": dict(params or {}), "headers": dict(headers or {})})
        handler = self.routes.get(path)
        if handler is None:
            return FakeResponse(404, {"message": "Not Found"})
        if callable(handler):
            return handler(dict(params or {}))
        return handler


def client_for(routes: dict[str, Any], token: str | None = "test-token") -> tuple[GitHubClient, FakeSession]:
    session = FakeSession(routes)
    client = GitHubClient(token=token, session=session, timeout=5, max_retries=0)
    return client, session


PR_META = {
    "title": "Add user endpoint",
    "body": "Adds a database helper.",
    "user": {"login": "ada"},
    "state": "open",
    "merged": False,
    "head": {"sha": HEAD_SHA},
    "base": {"sha": BASE_SHA},
    "created_at": "2024-05-01T12:00:00Z",
    "updated_at": "2024-05-01T15:00:00Z",
    "changed_files": 2,
    "additions": 15,
    "deletions": 3,
}

PR_FILES = [
    {
        "filename": "app.py",
        "status": "modified",
        "additions": 10,
        "deletions": 3,
        "changes": 13,
        "patch": "@@ -1 +1 @@\n-old\n+new",
    },
    {
        "filename": "logo.png",
        "status": "added",
        "additions": 5,
        "deletions": 0,
        "changes": 5,
    },
]

PR_COMMITS = [
    {
        "sha": "d" * 40,
        "commit": {"message": "Add helper", "author": {"date": "2024-05-01T12:30:00Z", "name": "Ada"}},
        "author": {"login": "ada"},
        "parents": [{"sha": BASE_SHA}],
    },
    {
        "sha": HEAD_SHA,
        "commit": {"message": "Wire it up", "author": {"date": "2024-05-01T13:00:00Z", "name": "Ada"}},
        "author": {"login": "ada"},
        "parents": [{"sha": "d" * 40}],
    },
]


def pr_routes() -> dict[str, Any]:
    return {
        "/repos/pallets/flask/pulls/123": FakeResponse(200, PR_META),
        "/repos/pallets/flask/pulls/123/files": FakeResponse(200, PR_FILES),
        "/repos/pallets/flask/pulls/123/commits": FakeResponse(200, PR_COMMITS),
        "/repos/pallets/flask/pulls/123/reviews": FakeResponse(200, [{"state": "APPROVED"}]),
        f"/repos/pallets/flask/commits/{HEAD_SHA}/check-runs": FakeResponse(
            200, {"total_count": 1, "check_runs": [{"conclusion": "success", "status": "completed"}]}
        ),
        f"/repos/pallets/flask/commits/{HEAD_SHA}/status": FakeResponse(200, {"state": "success"}),
    }


# ---------------------------------------------------------------------------
# URL validation
# ---------------------------------------------------------------------------


def test_parse_pull_url():
    ref = parse_github_url("https://github.com/pallets/flask/pull/123")
    assert ref.kind == "pull"
    assert (ref.owner, ref.repo, ref.number, ref.sha) == ("pallets", "flask", 123, None)
    assert ref.canonical_url == "https://github.com/pallets/flask/pull/123"


def test_parse_commit_url_normalises_host_and_sha():
    ref = parse_github_url("http://www.github.com/psf/requests/commit/ABC1234")
    assert ref.kind == "commit"
    assert ref.sha == "abc1234"
    assert ref.canonical_url == "https://github.com/psf/requests/commit/abc1234"


@pytest.mark.parametrize(
    "url",
    [
        "",
        "   ",
        "ftp://github.com/o/r/pull/1",
        "https://gitlab.com/o/r/pull/1",
        "https://github.company.com/o/r/pull/1",
        "https://user:pass@github.com/o/r/pull/1",
        "https://github.com:443/o/r/pull/1",
        "https://github.com/o/r/pull/1?tab=files",
        "https://github.com/o/r/pull/1#discussion",
        "https://github.com/o/r/pull/1/extra",
        "https://github.com/o/r/pulls/1",
        "https://github.com/o/r/issues/1",
        "https://github.com/o/r/pull/0",
        "https://github.com/o/r/pull/abc",
        "https://github.com/o/r/commit/xyz",
        "https://github.com/o/r/commit/abc1234/extra",
        "https://github.com/o/r.git/pull/1",
        "https://github.com/o%2Fr/pull/1",
        "https://github.com//r/pull/1",
    ],
)
def test_reject_unsupported_urls(url):
    with pytest.raises(GitHubError) as excinfo:
        parse_github_url(url)
    assert excinfo.value.code == "invalid_github_url"
    assert excinfo.value.status_code == 422


# ---------------------------------------------------------------------------
# Pull request / commit normalisation
# ---------------------------------------------------------------------------


def test_fetch_pull_request_normalises_metadata():
    client, session = client_for(pr_routes())
    snapshot = client.fetch(parse_github_url("https://github.com/pallets/flask/pull/123"))

    assert snapshot.kind == "pull_request"
    assert snapshot.title == "Add user endpoint"
    assert snapshot.author_login == "ada"
    assert snapshot.sha == HEAD_SHA
    assert snapshot.base_sha == BASE_SHA
    assert snapshot.number == 123
    assert snapshot.merged is False
    assert snapshot.total_files == 2
    assert snapshot.total_additions == 15
    assert snapshot.total_deletions == 3
    assert len(snapshot.files) == 2
    assert snapshot.files[1].patch is None
    assert snapshot.patches_missing == 1
    assert snapshot.files_truncated is False
    assert [commit.sha for commit in snapshot.commits] == ["d" * 40, HEAD_SHA]
    assert snapshot.reviews is not None and snapshot.reviews.states == {"approved": 1}
    assert snapshot.checks is not None
    assert snapshot.checks.conclusions == {"success": 1}
    assert snapshot.checks.status_state == "success"
    assert any("no textual patch" in warning for warning in snapshot.warnings)
    assert snapshot.earliest_commit_at == datetime(2024, 5, 1, 12, 30, tzinfo=timezone.utc)
    assert snapshot.analyzed_shas == {"d" * 40, HEAD_SHA}

    # The token is sent only in server-side headers.
    assert session.calls[0]["headers"]["Authorization"] == "Bearer test-token"
    assert all("pallets" in call["url"] for call in session.calls)
    assert all(call["url"].startswith("https://api.github.com/") for call in session.calls)


def test_fetch_commit_normalises_metadata():
    commit_payload = {
        "sha": COMMIT_SHA,
        "commit": {
            "message": "Fix login\n\nDetails about the fix.",
            "author": {"date": "2024-04-02T08:15:00Z", "name": "Ada"},
            "committer": {"date": "2024-04-02T09:00:00Z"},
        },
        "author": {"login": "ada"},
        "parents": [{"sha": BASE_SHA}],
        "stats": {"additions": 7, "deletions": 1},
        "files": [
            {
                "filename": "app/login.py",
                "status": "modified",
                "additions": 7,
                "deletions": 1,
                "changes": 8,
                "patch": "@@ -1 +1 @@\n-a\n+b",
            }
        ],
    }
    routes = {
        f"/repos/psf/requests/commits/{COMMIT_SHA}": FakeResponse(200, commit_payload),
        f"/repos/psf/requests/commits/{COMMIT_SHA}/check-runs": FakeResponse(200, {"total_count": 0, "check_runs": []}),
        f"/repos/psf/requests/commits/{COMMIT_SHA}/status": FakeResponse(200, {"state": "pending"}),
    }
    client, _ = client_for(routes)
    snapshot = client.fetch(parse_github_url(f"https://github.com/psf/requests/commit/{COMMIT_SHA}"))

    assert snapshot.kind == "commit"
    assert snapshot.title == "Fix login"
    assert snapshot.description == "Details about the fix."
    assert snapshot.sha == COMMIT_SHA
    assert snapshot.number is None
    assert snapshot.base_sha == BASE_SHA
    assert snapshot.parent_shas == [BASE_SHA]
    assert snapshot.total_additions == 7
    assert snapshot.total_deletions == 1
    assert snapshot.total_files == 1
    assert snapshot.commits[0].authored_at == datetime(2024, 4, 2, 8, 15, tzinfo=timezone.utc)
    assert snapshot.timestamps_fallback is False
    assert snapshot.checks is not None and snapshot.checks.status_state == "pending"


def test_missing_commit_timestamp_falls_back_with_warning():
    commit_payload = {
        "sha": COMMIT_SHA,
        "commit": {"message": "No timestamp", "author": {}, "committer": {}},
        "parents": [],
        "stats": {"additions": 1, "deletions": 0},
        "files": [
            {
                "filename": "a.py",
                "status": "modified",
                "additions": 1,
                "deletions": 0,
                "changes": 1,
                "patch": "@@ -0,0 +1 @@\n+x = 1",
            }
        ],
    }
    routes = {
        f"/repos/o/r/commits/{COMMIT_SHA}": FakeResponse(200, commit_payload),
    }
    client, _ = client_for(routes)
    snapshot = client.fetch(parse_github_url(f"https://github.com/o/r/commit/{COMMIT_SHA}"))
    assert snapshot.timestamps_fallback is True
    assert any("timestamp was unavailable" in warning for warning in snapshot.warnings)


def test_files_truncation_is_reported():
    routes = pr_routes()
    routes["/repos/pallets/flask/pulls/123"] = FakeResponse(
        200, {**PR_META, "changed_files": 10}
    )
    client, _ = client_for(routes)
    snapshot = client.fetch(parse_github_url("https://github.com/pallets/flask/pull/123"))
    assert snapshot.files_truncated is True
    assert any("of 10 changed files" in warning for warning in snapshot.warnings)


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


def test_not_found_maps_to_structured_error():
    client, _ = client_for({})
    with pytest.raises(GitHubError) as excinfo:
        client.fetch(parse_github_url("https://github.com/o/r/pull/1"))
    assert excinfo.value.code == "github_not_found"
    assert excinfo.value.status_code == 404
    assert "token" in excinfo.value.message.lower()


def test_rate_limit_includes_reset_details():
    client, _ = client_for(
        {
            "/repos/o/r/pulls/1": FakeResponse(
                403,
                {"message": "API rate limit exceeded"},
                headers={"X-RateLimit-Remaining": "0", "X-RateLimit-Reset": "1714600000"},
            )
        }
    )
    with pytest.raises(GitHubError) as excinfo:
        client.fetch(parse_github_url("https://github.com/o/r/pull/1"))
    assert excinfo.value.code == "github_rate_limited"
    assert excinfo.value.status_code == 429
    assert excinfo.value.details["reset_at"].startswith("2024-05-01")


def test_forbidden_without_rate_limit_is_distinct():
    client, _ = client_for(
        {"/repos/o/r/pulls/1": FakeResponse(403, {"message": "Forbidden"}, headers={"X-RateLimit-Remaining": "42"})}
    )
    with pytest.raises(GitHubError) as excinfo:
        client.fetch(parse_github_url("https://github.com/o/r/pull/1"))
    assert excinfo.value.code == "github_forbidden"
    assert excinfo.value.status_code == 403


def test_malformed_json_is_rejected():
    client, _ = client_for({"/repos/o/r/pulls/1": FakeResponse(200, json_error=True)})
    with pytest.raises(GitHubError) as excinfo:
        client.fetch(parse_github_url("https://github.com/o/r/pull/1"))
    assert excinfo.value.code == "malformed_github_response"


def test_server_errors_are_retried_once(monkeypatch):
    calls = {"count": 0}

    def handler(_params: dict[str, Any]) -> FakeResponse:
        calls["count"] += 1
        if calls["count"] == 1:
            return FakeResponse(502, {"message": "bad gateway"})
        return FakeResponse(200, PR_META)

    sleep_calls: list[float] = []
    monkeypatch.setattr(gh.time, "sleep", lambda seconds: sleep_calls.append(seconds))

    routes = pr_routes()
    routes["/repos/pallets/flask/pulls/123"] = handler
    session = FakeSession(routes)
    client = GitHubClient(session=session, max_retries=1)
    snapshot = client.fetch(parse_github_url("https://github.com/pallets/flask/pull/123"))
    assert snapshot.title == "Add user endpoint"
    assert calls["count"] == 2
    assert sleep_calls


def test_authentication_header_is_optional():
    client, session = client_for(pr_routes(), token=None)
    client.fetch(parse_github_url("https://github.com/pallets/flask/pull/123"))
    assert "Authorization" not in session.calls[0]["headers"]


def test_open_files_without_patch_do_not_crash_normalisation():
    routes = pr_routes()
    routes["/repos/pallets/flask/pulls/123/files"] = FakeResponse(
        200, [{**PR_FILES[1], "patch": 1234}]
    )
    routes["/repos/pallets/flask/pulls/123"] = FakeResponse(200, {**PR_META, "changed_files": 1})
    client, _ = client_for(routes)
    snapshot = client.fetch(parse_github_url("https://github.com/pallets/flask/pull/123"))
    assert snapshot.files[0].patch is None


# ---------------------------------------------------------------------------
# History helpers
# ---------------------------------------------------------------------------


def test_count_commits_before_uses_link_header():
    last_page = "<https://api.github.com/repositories/1/commits?per_page=1&page=2>; rel=\"next\", " \
                "<https://api.github.com/repositories/1/commits?per_page=1&page=42>; rel=\"last\""
    routes = {
        "/repos/o/r/commits": FakeResponse(200, [{"sha": "a" * 40}], headers={"Link": last_page}),
    }
    client, session = client_for(routes)
    cutoff = datetime(2024, 5, 1, 12, 0, tzinfo=timezone.utc)
    count, capped = client.count_commits_before("o", "r", "ada", cutoff)
    assert (count, capped) == (42, False)
    sent = session.calls[0]["params"]
    assert sent["author"] == "ada"
    assert sent["until"] == "2024-05-01T11:59:59Z"
    assert sent["per_page"] == 1


def test_count_commits_before_caps_large_history():
    last_page = "<https://api.github.com/x?page=9000>; rel=\"last\""
    routes = {"/repos/o/r/commits": FakeResponse(200, [{}], headers={"Link": last_page})}
    client, _ = client_for(routes)
    count, capped = client.count_commits_before(
        "o", "r", "ada", datetime(2024, 5, 1, tzinfo=timezone.utc), cap=5000
    )
    assert (count, capped) == (5000, True)


def test_list_file_commits_before_encodes_path():
    routes = {"/repos/o/r/commits": FakeResponse(200, [{"sha": "a" * 40}, "junk"])}
    client, session = client_for(routes)
    cutoff = datetime(2024, 5, 1, 12, 0, tzinfo=timezone.utc)
    items = client.list_file_commits_before("o", "r", "src/my file.py", cutoff, per_page=7)
    assert items == [{"sha": "a" * 40}]
    assert session.calls[0]["params"]["path"] == "src%2Fmy%20file.py"
    assert session.calls[0]["params"]["per_page"] == 7


# ---------------------------------------------------------------------------
# Authenticated quota
# ---------------------------------------------------------------------------

RESET_EPOCH = 1714600000  # 2024-05-01T21:46:40Z


def _quota_headers(limit: int, remaining: int, *, used: int | None = None) -> dict[str, str]:
    headers = {
        "X-RateLimit-Limit": str(limit),
        "X-RateLimit-Remaining": str(remaining),
        "X-RateLimit-Reset": str(RESET_EPOCH),
    }
    if used is not None:
        headers["X-RateLimit-Used"] = str(used)
    return headers


def test_rate_limit_headers_are_captured_on_success():
    routes = pr_routes()
    routes["/repos/pallets/flask/pulls/123"] = FakeResponse(
        200, PR_META, headers=_quota_headers(5000, 4999, used=1)
    )
    client, _ = client_for(routes)
    client.fetch(parse_github_url("https://github.com/pallets/flask/pull/123"))

    snapshot = client.rate_limit()
    assert snapshot is not None
    payload = snapshot.to_dict()
    assert payload["authenticated"] is True
    assert payload["mode"] == "authenticated"
    assert payload["limit"] == 5000
    assert payload["remaining"] == 4999
    assert payload["used"] == 1
    assert payload["reset_at"].startswith("2024-05-01")
    assert payload["source"] == "response_headers"
    assert payload["near_limit"] is False


def test_primary_rate_limit_reports_authenticated_quota():
    client, _ = client_for(
        {
            "/repos/o/r/pulls/1": FakeResponse(
                403,
                {"message": "API rate limit exceeded"},
                headers=_quota_headers(5000, 0, used=5000),
            )
        }
    )
    with pytest.raises(GitHubError) as excinfo:
        client.fetch(parse_github_url("https://github.com/o/r/pull/1"))

    error = excinfo.value
    assert error.code == "github_rate_limited"
    assert error.status_code == 429
    assert "authenticated token" in error.message
    assert error.details["kind"] == "primary"
    assert error.details["authenticated"] is True
    assert error.details["expected_hourly_limit"] == 5000
    assert error.details["limit"] == 5000
    assert error.details["remaining"] == 0
    assert error.details["reset_at"].startswith("2024-05-01")
    assert "test-token" not in error.message
    assert "test-token" not in repr(error.details)


def test_unauthenticated_rate_limit_explains_token_benefit():
    client, _ = client_for(
        {
            "/repos/o/r/pulls/1": FakeResponse(
                403,
                {"message": "API rate limit exceeded"},
                headers=_quota_headers(60, 0, used=60),
            )
        },
        token=None,
    )
    with pytest.raises(GitHubError) as excinfo:
        client.fetch(parse_github_url("https://github.com/o/r/pull/1"))

    error = excinfo.value
    assert error.code == "github_rate_limited"
    assert "GITHUB_TOKEN" in error.message
    assert "5,000" in error.message
    assert error.details["authenticated"] is False
    assert error.details["mode"] == "unauthenticated"
    assert error.details["expected_hourly_limit"] == 60


def test_secondary_rate_limit_uses_retry_after():
    client, _ = client_for(
        {
            "/repos/o/r/pulls/1": FakeResponse(
                403,
                {"message": "You have exceeded a secondary rate limit."},
                headers={
                    "Retry-After": "45",
                    "X-RateLimit-Limit": "5000",
                    "X-RateLimit-Remaining": "4990",
                },
            )
        }
    )
    with pytest.raises(GitHubError) as excinfo:
        client.fetch(parse_github_url("https://github.com/o/r/pull/1"))

    error = excinfo.value
    assert error.code == "github_rate_limited"
    assert error.status_code == 429
    assert error.details["kind"] == "secondary"
    assert error.details["retry_after_seconds"] == 45
    assert "45 seconds" in error.message


def test_unauthorized_reports_token_mode_without_leaking_token():
    client, _ = client_for(
        {"/repos/o/r/pulls/1": FakeResponse(401, {"message": "Bad credentials"})}
    )
    with pytest.raises(GitHubError) as excinfo:
        client.fetch(parse_github_url("https://github.com/o/r/pull/1"))

    error = excinfo.value
    assert error.code == "github_unauthorized"
    assert error.status_code == 502
    assert error.details["authenticated"] is True
    assert error.details["github_message"] == "Bad credentials"
    assert "GITHUB_TOKEN" in error.message
    assert "test-token" not in error.message
    assert "test-token" not in repr(error.details)


def test_unauthorized_without_token_mentions_missing_configuration():
    client, _ = client_for({"/repos/o/r/pulls/1": FakeResponse(401, {})}, token=None)
    with pytest.raises(GitHubError) as excinfo:
        client.fetch(parse_github_url("https://github.com/o/r/pull/1"))

    assert excinfo.value.code == "github_unauthorized"
    assert excinfo.value.details["authenticated"] is False
    assert "no GITHUB_TOKEN" in excinfo.value.message


def test_fetch_rate_limit_reads_core_resource():
    routes = {
        "/rate_limit": FakeResponse(
            200,
            {
                "resources": {
                    "core": {
                        "limit": 5000,
                        "remaining": 4987,
                        "used": 13,
                        "reset": RESET_EPOCH,
                    }
                }
            },
        )
    }
    client, session = client_for(routes)
    snapshot = client.fetch_rate_limit()

    assert session.calls[0]["path"] == "/rate_limit"
    assert session.calls[0]["headers"]["Authorization"] == "Bearer test-token"
    payload = snapshot.to_dict()
    assert payload["authenticated"] is True
    assert payload["limit"] == 5000
    assert payload["remaining"] == 4987
    assert payload["used"] == 13
    assert payload["source"] == "rate_limit_endpoint"
    assert client.rate_limit() == snapshot


def test_fetch_rate_limit_reports_public_limit_without_token():
    routes = {
        "/rate_limit": FakeResponse(
            200,
            {"resources": {"core": {"limit": 60, "remaining": 58, "reset": RESET_EPOCH}}},
        )
    }
    client, _ = client_for(routes, token=None)
    payload = client.fetch_rate_limit().to_dict()
    assert payload["authenticated"] is False
    assert payload["mode"] == "unauthenticated"
    assert (payload["limit"], payload["remaining"]) == (60, 58)
