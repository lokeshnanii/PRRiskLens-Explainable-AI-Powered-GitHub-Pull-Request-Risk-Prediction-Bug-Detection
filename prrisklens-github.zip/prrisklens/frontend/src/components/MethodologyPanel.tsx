import {
  AlertTriangle,
  Brain,
  Database,
  FlaskConical,
  GitBranch,
  Info,
  Layers,
  ListChecks,
  Microscope,
  ShieldAlert,
  Sigma,
} from "lucide-react";
import type { FeatureDefinition, ModelInfoResponse } from "../types/analysis";
import { DISCLAIMER, formatDate, formatNumber, formatPercent } from "../lib/format";

interface MethodologyPanelProps {
  modelInfo: ModelInfoResponse | null;
  backendOnline: boolean;
}

const FALLBACK_FEATURES: FeatureDefinition[] = [
  { name: "files_changed", label: "Files changed", description: "Distinct files touched by the change." },
  { name: "lines_added", label: "Lines added", description: "Lines added across all changed files." },
  { name: "lines_deleted", label: "Lines deleted", description: "Lines removed across all changed files." },
  {
    name: "previous_author_commits",
    label: "Author's prior commits",
    description: "Commits by the same author strictly before the analyzed change.",
  },
  {
    name: "prior_bug_fixes_in_touched_files",
    label: "Prior bug fixes in touched files",
    description:
      "Heuristic bug-fix commits touching any changed file, strictly before the change and inside a bounded history window.",
  },
  { name: "commit_hour", label: "Commit hour (UTC)", description: "Authored hour in UTC (0–23)." },
];

const PIPELINE = [
  {
    icon: GitBranch,
    title: "Mine history",
    detail: "PyDriller clones the four target repositories once and records commit metadata, file paths and diff sizes.",
  },
  {
    icon: ListChecks,
    title: "SZZ labels",
    detail: "Bug-fix commits are traced back through blame-like line history to candidate introducing commits.",
  },
  {
    icon: Database,
    title: "Feature dataset",
    detail: "The same six features are built offline with strict time-ordering and equal-timestamp leakage guards.",
  },
  {
    icon: Brain,
    title: "Train & explain",
    detail: "A chronological split trains logistic regression and XGBoost; the selected model is explained with SHAP.",
  },
];

function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : null;
}

function asNumber(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function metric(record: Record<string, unknown> | null, key: string): number | null {
  return record ? asNumber(record[key]) : null;
}

function captureRate(record: Record<string, unknown> | null): number | null {
  const capture = record ? asRecord(record.top_10_percent_capture) : null;
  return capture ? asNumber(capture.capture_rate) : null;
}

function formatMetric(value: number | null, percent = false): string {
  if (value === null) return "Undefined";
  return percent ? formatPercent(value, 1) : value.toFixed(3);
}

function MetricCard({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
      <p className="text-[9.5px] uppercase tracking-wider text-slate-500">{label}</p>
      <p className={`mt-1 font-mono text-lg font-semibold ${value === "Undefined" ? "text-slate-500" : "text-slate-100"}`}>
        {value}
      </p>
      {note ? <p className="mt-0.5 text-[9.5px] leading-relaxed text-slate-500">{note}</p> : null}
    </div>
  );
}

function Evaluation({ modelInfo, backendOnline }: { modelInfo: ModelInfoResponse | null; backendOnline: boolean }) {
  if (!backendOnline) {
    return (
      <div className="rounded-xl border border-dashed border-white/15 bg-white/[0.015] p-5">
        <p className="text-[12px] font-medium text-slate-200">Evaluation pending</p>
        <p className="mt-1.5 text-[11px] leading-relaxed text-slate-400">
          The backend does not respond at the configured API base, so model metadata and evaluation
          results cannot be read. Start the FastAPI service to see the artifacts from a real training run.
        </p>
      </div>
    );
  }
  if (!modelInfo || !modelInfo.available) {
    return (
      <div className="rounded-xl border border-dashed border-white/15 bg-white/[0.015] p-5">
        <p className="text-[12px] font-medium text-slate-200">Evaluation pending — no trained model deployed</p>
        <p className="mt-1.5 text-[11px] leading-relaxed text-slate-400">
          This deployment has no model artifact, so no ROC-AUC, PR-AUC, precision, recall or bug-capture
          numbers are shown. Placeholder metrics are never substituted. Run the mining → SZZ → dataset →
          training pipeline to produce and display the real evaluation from <span className="font-mono">results.json</span>.
        </p>
        {modelInfo?.reason ? <p className="mt-2 font-mono text-[10px] text-slate-500">{modelInfo.reason}</p> : null}
      </div>
    );
  }

  const metrics = asRecord(modelInfo.metrics);
  const allMetrics = asRecord(modelInfo.all_metrics);
  const comparison = allMetrics
    ? Object.entries(allMetrics)
        .map(([name, value]) => ({ name, record: asRecord(value) }))
        .filter((entry) => entry.record !== null)
    : [];

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2">
        <span className="chip !border-emerald-400/25 !text-emerald-200">
          <FlaskConical className="h-3 w-3" aria-hidden="true" />
          {modelInfo.model_type ?? "model"} · {modelInfo.model_version ?? "unknown version"}
        </span>
        {modelInfo.evaluation.results_available ? (
          <span className="chip">results.json · {modelInfo.evaluation.status ?? "unknown"}</span>
        ) : null}
        {modelInfo.training_metadata.trained_at ? (
          <span className="chip">trained {formatDate(modelInfo.training_metadata.trained_at)}</span>
        ) : null}
      </div>

      {metrics ? (
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <MetricCard label="ROC-AUC" value={formatMetric(metric(metrics, "roc_auc"))} note="Test split" />
          <MetricCard label="PR-AUC" value={formatMetric(metric(metrics, "pr_auc_average_precision"))} note="Average precision" />
          <MetricCard label="Precision" value={formatMetric(metric(metrics, "precision"))} note="At selected threshold" />
          <MetricCard label="Recall" value={formatMetric(metric(metrics, "recall"))} note="At selected threshold" />
          <MetricCard label="F1" value={formatMetric(metric(metrics, "f1"))} note="At selected threshold" />
          <MetricCard
            label="Top-10% capture"
            value={formatMetric(captureRate(metrics), true)}
            note="Share of test bugs in the highest-scoring decile"
          />
          <MetricCard label="Test rows" value={formatNumber(metric(metrics, "test_size"))} note={`${formatNumber(metric(metrics, "positive_test_examples"))} positive`} />
          <MetricCard label="Threshold" value={formatMetric(metric(metrics, "threshold"))} note="Decision threshold" />
        </div>
      ) : (
        <p className="mt-3 rounded-lg border border-white/10 bg-white/[0.02] p-3 text-[11px] text-slate-400">
          The model is loaded but its metadata contains no evaluation metrics.
        </p>
      )}

      {comparison.length ? (
        <div className="mt-3 overflow-x-auto rounded-xl border border-white/[0.07]">
          <table className="w-full min-w-[30rem] text-left text-[11px]">
            <thead className="bg-white/[0.03] text-[9.5px] uppercase tracking-wider text-slate-500">
              <tr>
                <th scope="col" className="px-3 py-2 font-medium">Family</th>
                <th scope="col" className="px-3 py-2 font-medium">ROC-AUC</th>
                <th scope="col" className="px-3 py-2 font-medium">PR-AUC</th>
                <th scope="col" className="px-3 py-2 font-medium">F1</th>
                <th scope="col" className="px-3 py-2 font-medium">Top-10% capture</th>
              </tr>
            </thead>
            <tbody>
              {comparison.map(({ name, record }) => (
                <tr key={name} className="border-t border-white/[0.05]">
                  <td className="px-3 py-2 font-medium text-slate-200">{name.replace(/_/g, " ")}</td>
                  <td className="px-3 py-2 font-mono text-slate-300">{formatMetric(record ? metric(record, "roc_auc") : null)}</td>
                  <td className="px-3 py-2 font-mono text-slate-300">
                    {formatMetric(record ? metric(record, "pr_auc_average_precision") : null)}
                  </td>
                  <td className="px-3 py-2 font-mono text-slate-300">{formatMetric(record ? metric(record, "f1") : null)}</td>
                  <td className="px-3 py-2 font-mono text-slate-300">{formatMetric(captureRate(record), true)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}

      {modelInfo.training_metadata.selection_reason ? (
        <p className="mt-3 flex items-start gap-2 text-[10.5px] leading-relaxed text-slate-500">
          <Info className="mt-0.5 h-3 w-3 shrink-0" aria-hidden="true" />
          {modelInfo.training_metadata.selection_reason}
        </p>
      ) : null}

      {modelInfo.training ? (
        <p className="mt-2 text-[10.5px] leading-relaxed text-slate-500">
          Training data: {formatNumber(modelInfo.training.rows ?? null)} commits ·{" "}
          {formatNumber(modelInfo.training.positives ?? null)} positives
          {modelInfo.training.positive_rate !== undefined
            ? ` (${formatPercent(modelInfo.training.positive_rate)} positive rate)`
            : ""}
          {modelInfo.training.repositories?.length
            ? ` · ${modelInfo.training.repositories.join(", ")}`
            : ""}
          {modelInfo.training.date_range?.start && modelInfo.training.date_range?.end
            ? ` · ${formatDate(modelInfo.training.date_range.start)} → ${formatDate(modelInfo.training.date_range.end)}`
            : ""}
        </p>
      ) : null}

      {Array.isArray(metrics?.notes) && metrics.notes.length ? (
        <ul className="mt-2 space-y-1">
          {(metrics.notes as unknown[]).map((note) => (
            <li key={String(note)} className="text-[10.5px] leading-relaxed text-amber-200/75">
              • {String(note)}
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

export default function MethodologyPanel({ modelInfo, backendOnline }: MethodologyPanelProps) {
  const features = modelInfo?.features?.length ? modelInfo.features : FALLBACK_FEATURES;

  return (
    <section className="glass-panel p-5 sm:p-6" aria-labelledby="methodology-title">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 id="methodology-title" className="flex items-center gap-2 text-base font-semibold text-white">
            <Microscope className="h-4 w-4 text-aqua-400" aria-hidden="true" />
            Methodology, evaluation and limitations
          </h2>
          <p className="mt-1 max-w-3xl text-[11.5px] leading-relaxed text-slate-400">
            The risk ranking and the code findings are two independent systems. The model learns from
            historical commits; the findings come from deterministic checks on the actual diff.
          </p>
        </div>
        <span className="chip">
          <Layers className="h-3 w-3" aria-hidden="true" />
          schema {modelInfo?.feature_schema_version ?? "1.0.0"}
        </span>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {PIPELINE.map((step, index) => {
          const Icon = step.icon;
          return (
            <div key={step.title} className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-3.5">
              <span className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-gradient-to-br from-brand-500/20 to-aqua-400/10 text-brand-200">
                <Icon className="h-4 w-4" aria-hidden="true" />
              </span>
              <p className="mt-2.5 flex items-center gap-2 text-[12px] font-semibold text-slate-100">
                <span className="font-mono text-[9.5px] text-slate-500">0{index + 1}</span>
                {step.title}
              </p>
              <p className="mt-1 text-[10.5px] leading-relaxed text-slate-400">{step.detail}</p>
            </div>
          );
        })}
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-[1.15fr_1fr]">
        <div>
          <h3 className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">
            <Sigma className="h-3.5 w-3.5" aria-hidden="true" />
            The six model features
          </h3>
          <div className="mt-2 overflow-hidden rounded-xl border border-white/[0.07]">
            <table className="w-full text-left">
              <thead className="bg-white/[0.03] text-[9.5px] uppercase tracking-wider text-slate-500">
                <tr>
                  <th scope="col" className="px-3 py-2 font-medium">Feature</th>
                  <th scope="col" className="px-3 py-2 font-medium">Meaning</th>
                </tr>
              </thead>
              <tbody>
                {features.map((feature) => (
                  <tr key={feature.name} className="border-t border-white/[0.05] align-top">
                    <td className="px-3 py-2 font-mono text-[10px] text-slate-300">{feature.name}</td>
                    <td className="px-3 py-2 text-[10.5px] leading-relaxed text-slate-400">
                      <span className="font-medium text-slate-300">{feature.label}.</span> {feature.description}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-2 text-[10px] leading-relaxed text-slate-500">
            Features use UTC. Historical counts only include commits strictly before the analyzed change,
            and equal-timestamp commits cannot influence each other. Pull requests are aggregated at the
            earliest commit's authored time and PR author.
          </p>
        </div>

        <div>
          <h3 className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">
            <FlaskConical className="h-3.5 w-3.5" aria-hidden="true" />
            Measured evaluation
          </h3>
          <div className="mt-2">
            <Evaluation modelInfo={modelInfo} backendOnline={backendOnline} />
          </div>
        </div>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-4">
          <h3 className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">
            <AlertTriangle className="h-3.5 w-3.5 text-amber-300" aria-hidden="true" />
            Known limitations
          </h3>
          <ul className="mt-2 space-y-1.5 text-[10.5px] leading-relaxed text-slate-400">
            <li>• SZZ labels are approximate: blame tracing plus a message heuristic can miss or misattribute bug fixes.</li>
            <li>• Historical association is not causation; the model does not prove a change contains a defect.</li>
            <li>• Training covers only the mined repositories; performance may not generalise to other projects.</li>
            <li>• GitHub history windows are bounded and author counts can be capped, so historical features may be partial.</li>
            <li>• Code findings are deterministic pattern matches with evidence, not confirmed bugs. Pull request code is never executed.</li>
            <li>• Private repositories require a backend token; no GitHub credential ever reaches this browser application.</li>
          </ul>
        </div>
        <div className="rounded-xl border border-amber-400/20 bg-amber-400/[0.04] p-4">
          <h3 className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-amber-200">
            <ShieldAlert className="h-3.5 w-3.5" aria-hidden="true" />
            Required disclaimer
          </h3>
          <p className="mt-2 text-[11px] leading-relaxed text-amber-100/85">{DISCLAIMER}</p>
          <p className="mt-3 flex items-start gap-2 text-[10px] leading-relaxed text-slate-400">
            <Info className="mt-0.5 h-3 w-3 shrink-0" aria-hidden="true" />
            The 0–100 score is a ranking index, not a calibrated probability. Use it to prioritise review,
            never to skip it.
          </p>
        </div>
      </div>
    </section>
  );
}
