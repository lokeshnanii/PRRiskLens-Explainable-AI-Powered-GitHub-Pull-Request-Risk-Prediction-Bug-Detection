"""FastAPI application for PRRiskLens.

The API exposes the trained model and the diff-analysis pipeline. It never
accepts arbitrary URLs for fetching: only validated github.com pull request and
commit links are passed to the GitHub client.
"""

from __future__ import annotations

import logging
import math
import threading
import time
from collections import deque
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any, Callable, Deque, Mapping

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from config import Settings, get_settings
from core import FEATURE_SCHEMA_VERSION
from gh import GitHubClient, GitHubError
from inference import ModelRegistry
from schemas import (
    AnalysisResponse,
    ErrorResponse,
    FeatureRequest,
    GitHubAuthInfo,
    GitHubRateLimitResponse,
    HealthResponse,
    PredictUrlRequest,
    Prediction,
    Thresholds,
)
from service import AnalysisService, ModelUnavailableError

logger = logging.getLogger("prrisklens.api")

APP_NAME = "PRRiskLens API"
APP_VERSION = "1.0.0"


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _error(
    status_code: int,
    code: str,
    message: str,
    details: Mapping[str, Any] | None = None,
    headers: Mapping[str, str] | None = None,
) -> JSONResponse:
    body = ErrorResponse.model_validate(
        {"error": {"code": code, "message": message, "details": dict(details or {})}}
    )
    return JSONResponse(
        status_code=status_code,
        content=body.model_dump(mode="json"),
        headers=dict(headers or {}),
    )


class RateLimiter:
    """Small in-process sliding-window limiter.

    This is a per-process guard against accidental bursts from a single client;
    it is not a replacement for an edge proxy in a multi-instance deployment.
    """

    def __init__(self, limit: int, window_seconds: float = 60.0) -> None:
        self.limit = max(1, limit)
        self.window_seconds = window_seconds
        self._hits: dict[str, Deque[float]] = {}
        self._lock = threading.Lock()

    def check(self, key: str) -> tuple[bool, int]:
        now = time.monotonic()
        cutoff = now - self.window_seconds
        with self._lock:
            if len(self._hits) > 5000:
                self._hits.clear()
            hits = self._hits.setdefault(key, deque())
            while hits and hits[0] <= cutoff:
                hits.popleft()
            if len(hits) >= self.limit:
                retry_after = max(1, math.ceil(hits[0] + self.window_seconds - now))
                return False, retry_after
            hits.append(now)
            return True, 0


def _client_key(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def _secured(response: JSONResponse | Any) -> Any:
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    return response


def create_app(
    settings: Settings | None = None,
    *,
    client_factory: Callable[[], GitHubClient] | None = None,
    registry: ModelRegistry | None = None,
) -> FastAPI:
    resolved = settings or get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):  # pragma: no cover - exercised at runtime
        # Preload the model so the first request does not pay disk IO.
        try:
            app.state.service.registry.get()
        except Exception:  # never prevent the API from starting
            logger.exception("Model preload failed; predictions will report unavailable")
        logger.info(
            "PRRiskLens API ready (model available: %s)",
            app.state.service.registry.status()["model_available"],
        )
        yield

    app = FastAPI(
        title=APP_NAME,
        version=APP_VERSION,
        description=(
            "Explainable bug-risk scoring for GitHub pull requests and commits. "
            "Historical risk rankings come from a supervised model; code findings "
            "come from deterministic diff analysis."
        ),
        lifespan=lifespan,
    )
    app.state.settings = resolved
    app.state.service = AnalysisService(
        resolved, client_factory=client_factory, registry=registry
    )
    app.state.rate_limiter = RateLimiter(resolved.rate_limit_per_minute)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(resolved.frontend_origins),
        allow_credentials=False,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Content-Type", "Accept"],
        max_age=600,
    )

    @app.middleware("http")
    async def guard_requests(request: Request, call_next):
        # Security headers are applied to every response, including errors.
        if request.method == "OPTIONS":
            response = await call_next(request)
            return response

        content_length = request.headers.get("content-length")
        if content_length is not None:
            try:
                length = int(content_length)
            except ValueError:
                return _secured(
                    _error(400, "invalid_request", "Content-Length must be a number.")
                )
            if length > resolved.max_request_bytes:
                return _secured(
                    _error(
                        413,
                        "request_too_large",
                        f"Request body exceeds {resolved.max_request_bytes} bytes.",
                    )
                )

        path = request.url.path
        if path not in {"/health", "/", "/docs", "/redoc", "/openapi.json"}:
            allowed, retry_after = app.state.rate_limiter.check(_client_key(request))
            if not allowed:
                return _secured(
                    _error(
                        429,
                        "rate_limited",
                        "Too many requests. Wait a moment and try again.",
                        {"retry_after_seconds": retry_after},
                        {"Retry-After": str(retry_after)},
                    )
                )

        response = await call_next(request)
        _secured(response)
        if path.startswith("/predict"):
            response.headers.setdefault("Cache-Control", "no-store")
        return response

    # -- exception handlers ------------------------------------------------

    @app.exception_handler(GitHubError)
    async def handle_github_error(_: Request, exc: GitHubError) -> JSONResponse:
        logger.info("GitHub error %s: %s", exc.code, exc.message)
        return _error(exc.status_code, exc.code, exc.message, exc.details)

    @app.exception_handler(ModelUnavailableError)
    async def handle_model_unavailable(_: Request, exc: ModelUnavailableError) -> JSONResponse:
        return _error(
            503,
            "model_unavailable",
            str(exc),
            {"training_required": True, "train_command": "python backend/train.py"},
        )

    @app.exception_handler(RequestValidationError)
    async def handle_validation(_: Request, exc: RequestValidationError) -> JSONResponse:
        # Echo field locations and messages only; never echo the submitted values.
        errors = []
        for item in exc.errors():
            location = [str(part) for part in item.get("loc", ()) if part != "body"]
            errors.append(
                {
                    "field": ".".join(location) or "body",
                    "message": item.get("msg", "Invalid value"),
                    "type": item.get("type", "value_error"),
                }
            )
        return _error(
            422,
            "validation_error",
            "Request validation failed. Check the field values and try again.",
            {"errors": errors[:20]},
        )

    @app.exception_handler(StarletteHTTPException)
    async def handle_http(_: Request, exc: StarletteHTTPException) -> JSONResponse:
        code = "not_found" if exc.status_code == 404 else "http_error"
        message = "Not found." if exc.status_code == 404 else str(exc.detail)
        return _error(exc.status_code, code, message)

    @app.exception_handler(Exception)
    async def handle_unexpected(_: Request, exc: Exception) -> JSONResponse:
        logger.exception("Unhandled API error")
        return _error(
            500,
            "internal_error",
            "An unexpected server error occurred. Check the server logs for details.",
        )

    # -- routes ------------------------------------------------------------

    @app.get("/", include_in_schema=False)
    async def root() -> dict[str, Any]:
        return {
            "name": APP_NAME,
            "version": APP_VERSION,
            "docs": "/docs",
            "endpoints": [
                "/health",
                "/github-rate-limit",
                "/model-info",
                "/predict",
                "/predict_url",
            ],
            "note": (
                "PRRiskLens ranks historical bug risk and flags potential code issues. "
                "It does not prove the presence or absence of bugs."
            ),
        }

    @app.get("/health", response_model=HealthResponse)
    async def health() -> HealthResponse:
        status = app.state.service.registry.status()
        return HealthResponse(
            status="ok",
            model_available=status["model_available"],
            model_version=status["model_version"],
            model_type=status["model_type"],
            feature_schema_version=FEATURE_SCHEMA_VERSION,
            reason=status["reason"],
            time=_iso_now(),
            github=GitHubAuthInfo(**app.state.service.github_auth_info()),
        )

    @app.get("/github-rate-limit", response_model=GitHubRateLimitResponse)
    async def github_rate_limit() -> GitHubRateLimitResponse:
        return GitHubRateLimitResponse.model_validate(
            app.state.service.github_rate_limit()
        )

    @app.get("/model-info")
    async def model_info() -> dict[str, Any]:
        return app.state.service.model_info()

    @app.post("/predict", response_model=Prediction)
    async def predict(payload: FeatureRequest) -> Prediction:
        result = app.state.service.predict_features(payload.model_dump())
        result.setdefault(
            "thresholds",
            Thresholds(
                low_max=resolved.low_risk_threshold,
                high_min=resolved.high_risk_threshold,
            ).model_dump(),
        )
        return Prediction.model_validate(result)

    @app.post("/predict_url", response_model=AnalysisResponse)
    async def predict_url(payload: PredictUrlRequest) -> AnalysisResponse:
        result = app.state.service.analyze_url(payload.url)
        return AnalysisResponse.model_validate(result)

    return app


app = create_app()


if __name__ == "__main__":  # pragma: no cover
    import uvicorn

    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=False)
