import { ArrowRight, FileDiff, Gauge, GitPullRequest, Sparkles } from "lucide-react";

const steps = [
  {
    icon: GitPullRequest,
    title: "GitHub URL",
    detail: "Paste a pull request or commit link. Only github.com URLs are fetched.",
  },
  {
    icon: FileDiff,
    title: "Change Analysis",
    detail: "Real metadata, changed files, patches and deterministic code checks.",
  },
  {
    icon: Gauge,
    title: "Risk Assessment",
    detail: "Six historical features scored by a supervised model, when trained.",
  },
  {
    icon: Sparkles,
    title: "Explainable Findings",
    detail: "SHAP factors for the ranking, plus evidence from the changed lines.",
  },
];

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden pb-14 pt-14 sm:pt-20" aria-labelledby="hero-title">
      <div
        className="pointer-events-none absolute inset-0 -z-10 bg-grid-faint [background-size:42px_42px] [mask-image:radial-gradient(ellipse_at_top,black,transparent_72%)]"
        aria-hidden="true"
      />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <div className="chip mb-5 !border-brand-400/25 !bg-brand-400/[0.08] !text-brand-200">
            <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
            Explainable review intelligence
          </div>
          <h1 id="hero-title" className="text-balance text-4xl font-semibold tracking-tight text-white sm:text-5xl lg:text-[3.4rem] lg:leading-[1.08]">
            Catch risky changes{" "}
            <span className="bg-gradient-to-r from-brand-300 via-aqua-400 to-violet-400 bg-clip-text text-transparent">
              before they become production bugs.
            </span>
          </h1>
          <p className="mt-5 max-w-2xl text-pretty text-base leading-relaxed text-slate-400 sm:text-lg">
            Analyze GitHub pull requests with machine learning, explainable risk factors, and
            evidence-based code findings. Every result separates a historical ranking from actual
            diff evidence.
          </p>
          <div className="mt-7 flex flex-wrap items-center gap-3">
            <a href="#analyze" className="btn-primary">
              Analyze a change
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </a>
            <a href="#methodology" className="btn-ghost">
              Read the methodology
            </a>
          </div>
        </div>

        <div id="how-it-works" className="mt-14 scroll-mt-24">
          <div className="mb-4 flex items-center gap-3">
            <span className="section-label">Workflow</span>
            <span className="h-px flex-1 bg-gradient-to-r from-white/15 to-transparent" aria-hidden="true" />
          </div>
          <ol className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <li key={step.title} className="glass-panel-soft group relative p-4 transition hover:border-white/15 hover:bg-white/[0.045]">
                  <div className="flex items-start gap-3">
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-white/10 bg-gradient-to-br from-brand-500/20 to-aqua-400/10 text-brand-200">
                      <Icon className="h-4 w-4" aria-hidden="true" />
                    </span>
                    <div>
                      <p className="flex items-center gap-2 text-sm font-semibold text-slate-100">
                        <span className="font-mono text-[10px] text-slate-500">0{index + 1}</span>
                        {step.title}
                      </p>
                      <p className="mt-1 text-[12px] leading-relaxed text-slate-400">{step.detail}</p>
                    </div>
                  </div>
                  {index < steps.length - 1 ? (
                    <ArrowRight
                      className="absolute -right-2 top-1/2 hidden h-4 w-4 -translate-y-1/2 text-slate-700 xl:block"
                      aria-hidden="true"
                    />
                  ) : null}
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </section>
  );
}
