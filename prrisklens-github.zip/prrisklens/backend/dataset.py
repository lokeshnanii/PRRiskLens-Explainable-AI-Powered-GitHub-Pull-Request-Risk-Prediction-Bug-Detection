"""Build leak-free training data from raw mining output and SZZ labels.

Leakage guards:
* All history counters are updated only after every commit sharing the same
  authored timestamp has been featurised, so equal-timestamp commits cannot
  influence each other.
* ``prior_bug_fixes_in_touched_files`` only counts bug-fix commits strictly
  before the current timestamp.
* ``previous_author_commits`` only counts earlier commits by the same author.

Usage:
    python dataset.py --raw data/raw/commits_pilot.csv \
                      --labels data/processed/labels_pilot.csv \
                      --out data/processed/features_pilot.csv
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

import pandas as pd

from config import BACKEND_DIR
from core import FEATURES, FEATURE_SCHEMA_VERSION, TIMEZONE_CONVENTION, detect_bug_fix

OUTPUT_COLUMNS = [
    "repo",
    "sha",
    "author_date",
    "label",
    "label_provenance",
    "bug_fix_message",
    *FEATURES,
]


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse_date(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, str) and value:
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
    else:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _to_int(value: Any) -> int | None:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number >= 0 else None


def _json_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value]
    if isinstance(value, str) and value:
        try:
            parsed = json.loads(value)
        except ValueError:
            return []
        if isinstance(parsed, list):
            return [str(item) for item in parsed]
    return []


def _is_merge(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() == "true"


def build_training_frame(
    records: Iterable[Mapping[str, Any]],
    labels: Iterable[Mapping[str, Any]],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Return (features dataframe, dataset metadata) with strict time ordering."""

    skipped = Counter()
    prepared: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    for raw in records:
        repo = str(raw.get("repo") or "").strip()
        sha = str(raw.get("sha") or "").strip().lower()
        if raw.get("error"):
            skipped["row_error"] += 1
            continue
        if _is_merge(raw.get("is_merge")):
            skipped["merge_commit"] += 1
            continue
        if not repo or not sha:
            skipped["missing_identity"] += 1
            continue
        if (repo, sha) in seen:
            skipped["duplicate"] += 1
            continue

        timestamp = _parse_date(raw.get("author_date"))
        if timestamp is None:
            skipped["missing_timestamp"] += 1
            continue
        author_key = (
            str(raw.get("author_email") or "").strip().lower()
            or str(raw.get("author_name") or "").strip().lower()
        )
        if not author_key:
            skipped["missing_author"] += 1
            continue
        files = sorted({path for path in _json_list(raw.get("file_paths")) if path})
        if not files:
            skipped["empty_diff"] += 1
            continue
        lines_added = _to_int(raw.get("lines_added"))
        lines_deleted = _to_int(raw.get("lines_deleted"))
        files_changed = _to_int(raw.get("files_changed"))
        if lines_added is None or lines_deleted is None or files_changed is None:
            skipped["invalid_counts"] += 1
            continue

        seen.add((repo, sha))
        message = str(raw.get("message") or "")
        prepared.append(
            {
                "repo": repo,
                "sha": sha,
                "timestamp": timestamp,
                "author_key": author_key,
                "files": files,
                "files_changed": files_changed,
                "lines_added": lines_added,
                "lines_deleted": lines_deleted,
                "message": message,
                "bug_fix_message": detect_bug_fix(message).is_candidate,
            }
        )

    label_map: dict[str, dict[str, Any]] = defaultdict(dict)
    label_counts = Counter()
    for label in labels:
        provenance = str(label.get("provenance") or "")
        if provenance != "szz_candidate":
            label_counts[provenance or "unknown"] += 1
            continue
        introducing = str(label.get("introducing_sha") or "").strip().lower()
        if not introducing:
            continue
        label_counts["szz_candidate"] += 1
        label_map[introducing].setdefault(
            "fix_sha", str(label.get("fix_sha") or "")
        )

    prepared.sort(key=lambda item: (item["timestamp"], item["sha"]))
    prepared_shas = {item["sha"] for item in prepared}
    introducing_outside_window = len(set(label_map) - prepared_shas)

    history_author: Counter[str] = Counter()
    history_bug_fixes: dict[str, set[str]] = defaultdict(set)
    bugfix_history_commits = 0
    rows: list[dict[str, Any]] = []

    index = 0
    while index < len(prepared):
        timestamp = prepared[index]["timestamp"]
        group: list[dict[str, Any]] = []
        while index < len(prepared) and prepared[index]["timestamp"] == timestamp:
            group.append(prepared[index])
            index += 1

        # Featurise the whole timestamp group before updating history.
        for item in group:
            touched = item["files"]
            prior_fixes: set[str] = set()
            for path in touched:
                prior_fixes.update(history_bug_fixes.get(path, set()))
            is_labeled = item["sha"] in label_map
            rows.append(
                {
                    "repo": item["repo"],
                    "sha": item["sha"],
                    "author_date": _iso(item["timestamp"]),
                    "label": 1 if is_labeled else 0,
                    "label_provenance": "szz_candidate" if is_labeled else "no_szz_label",
                    "bug_fix_message": item["bug_fix_message"],
                    "files_changed": item["files_changed"],
                    "lines_added": item["lines_added"],
                    "lines_deleted": item["lines_deleted"],
                    "previous_author_commits": history_author.get(item["author_key"], 0),
                    "prior_bug_fixes_in_touched_files": len(prior_fixes),
                    "commit_hour": item["timestamp"].hour,
                }
            )

        for item in group:
            history_author[item["author_key"]] += 1
            if item["bug_fix_message"]:
                bugfix_history_commits += 1
                for path in item["files"]:
                    history_bug_fixes[path].add(item["sha"])

    frame = pd.DataFrame(rows, columns=OUTPUT_COLUMNS)
    if not frame.empty:
        for column in (*FEATURES, "label"):
            frame[column] = frame[column].astype(int)

    positives = int(frame["label"].sum()) if not frame.empty else 0
    repos = sorted(frame["repo"].unique().tolist()) if not frame.empty else []
    date_range = None
    if not frame.empty:
        date_range = {
            "start": str(frame["author_date"].min()),
            "end": str(frame["author_date"].max()),
        }

    meta = {
        "generated_at": _iso(datetime.now(timezone.utc)),
        "rows": int(len(frame)),
        "positives": positives,
        "positive_rate": round(positives / len(frame), 6) if len(frame) else None,
        "repositories": repos,
        "date_range": date_range,
        "features": list(FEATURES),
        "feature_schema_version": FEATURE_SCHEMA_VERSION,
        "timezone": TIMEZONE_CONVENTION,
        "labels": {
            "szz_label_rows": label_counts.get("szz_candidate", 0),
            "untraceable_rows": label_counts.get("untraceable", 0),
            "excluded_rows": label_counts.get("excluded", 0),
            "positive_commits": positives,
            "introducing_outside_window": introducing_outside_window,
        },
        "skipped": dict(skipped),
        "bug_fix_history_commits": bugfix_history_commits,
        "leakage_guard": (
            "Commits are sorted by authored UTC timestamp and SHA. Feature values "
            "for every commit in an equal-timestamp group are computed before that "
            "group updates the author or file bug-fix history. Prior bug fixes use "
            "only commits with strictly earlier timestamps."
        ),
        "label_source": (
            "Approximate SZZ blame plus a configurable bug-fix message heuristic. "
            "Labels are not ground truth."
        ),
    }
    return frame, meta


def _read_csv(path: Path) -> list[dict[str, Any]]:
    frame = pd.read_csv(path, dtype=str, keep_default_na=False)
    return frame.to_dict(orient="records")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build the six-feature training dataset")
    parser.add_argument("--raw", required=True, help="Raw commits CSV from mine.py")
    parser.add_argument("--labels", required=True, help="Labels CSV from szz.py")
    parser.add_argument("--out", default=None, help="Processed feature CSV")
    parser.add_argument("--meta", default=None, help="Dataset metadata JSON")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    raw_path = Path(args.raw)
    labels_path = Path(args.labels)
    out_path = Path(args.out) if args.out else raw_path.with_name("features.csv")
    meta_path = Path(args.meta) if args.meta else out_path.with_name(
        out_path.stem + "_meta.json"
    )
    for path in (raw_path, labels_path):
        if not path.exists():
            print(f"Input not found: {path}", file=sys.stderr)
            return 1

    frame, meta = build_training_frame(_read_csv(raw_path), _read_csv(labels_path))
    meta["raw_input"] = str(raw_path)
    meta["labels_input"] = str(labels_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(out_path, index=False)
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    print(f"Features: {out_path} ({len(frame)} rows, {meta['positives']} positives)")
    print(f"Metadata: {meta_path}")
    if meta["positives"] == 0:
        print("Warning: no positive labels are available; training will refuse to run.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
