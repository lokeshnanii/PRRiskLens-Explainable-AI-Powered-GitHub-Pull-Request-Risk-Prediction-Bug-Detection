import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import ErrorState from "./ErrorState";
import { ApiError } from "../services/api";

describe("ErrorState GitHub quota hints", () => {
  it("explains the unauthenticated limit and shows quota details", () => {
    render(
      <ErrorState
        error={
          new ApiError("github_rate_limited", "GitHub API rate limit exceeded.", 429, {
            authenticated: false,
            mode: "unauthenticated",
            kind: "primary",
            limit: 60,
            remaining: 0,
            reset_at: "2026-11-01T11:00:00Z",
          })
        }
      />,
    );

    expect(screen.getByText(/limited to 60 per hour/i)).toBeInTheDocument();
    expect(screen.getByText(/GITHUB_TOKEN/)).toBeInTheDocument();
    expect(screen.getByText(/5,000 per hour/)).toBeInTheDocument();
    expect(screen.getByText(/GitHub quota: 0\/60 remaining/)).toBeInTheDocument();
    expect(screen.getByText(/unauthenticated/)).toBeInTheDocument();
  });

  it("does not blame the token when the authenticated quota is exhausted", () => {
    render(
      <ErrorState
        error={
          new ApiError("github_rate_limited", "GitHub API rate limit exceeded.", 429, {
            authenticated: true,
            mode: "authenticated",
            kind: "primary",
            limit: 5000,
            remaining: 0,
            reset_at: "2026-11-01T11:00:00Z",
          })
        }
      />,
    );

    expect(screen.getByText(/authenticated GitHub quota/i)).toBeInTheDocument();
    expect(screen.getByText(/GitHub quota: 0\/5,000 remaining/)).toBeInTheDocument();
    expect(screen.getByText(/^authenticated$/)).toBeInTheDocument();
  });

  it("reports secondary limits and the retry window", () => {
    render(
      <ErrorState
        error={
          new ApiError("github_rate_limited", "GitHub secondary rate limit triggered.", 429, {
            authenticated: true,
            kind: "secondary",
            retry_after_seconds: 45,
          })
        }
      />,
    );

    expect(screen.getByText(/secondary \(abuse\) rate limit/i)).toBeInTheDocument();
    expect(screen.getByText(/Retry after 45s/)).toBeInTheDocument();
  });

  it("explains a rejected token without exposing it", () => {
    const { container } = render(
      <ErrorState
        error={
          new ApiError("github_unauthorized", "GitHub rejected the configured GITHUB_TOKEN (401).", 502, {
            authenticated: true,
          })
        }
      />,
    );

    expect(screen.getByText(/not expired, and not revoked/i)).toBeInTheDocument();
    expect(screen.getByText(/never sent to the browser/i)).toBeInTheDocument();
    expect(container.textContent ?? "").not.toMatch(/ghp_|github_pat_/);
  });
});
