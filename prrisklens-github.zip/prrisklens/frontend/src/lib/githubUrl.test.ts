import { describe, expect, it } from "vitest";
import { parseGitHubUrl } from "./githubUrl";

describe("parseGitHubUrl", () => {
  it("accepts a pull request URL and canonicalises it", () => {
    const result = parseGitHubUrl("https://github.com/pallets/flask/pull/123/");
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.kind).toBe("pull");
    expect(result.owner).toBe("pallets");
    expect(result.repo).toBe("flask");
    expect(result.number).toBe(123);
    expect(result.canonical).toBe("https://github.com/pallets/flask/pull/123");
    expect(result.preview).toContain("#123");
  });

  it("accepts full and abbreviated commit URLs", () => {
    const full = parseGitHubUrl("https://github.com/psf/requests/commit/0123456789abcdef0123456789abcdef01234567");
    const short = parseGitHubUrl("https://www.github.com/psf/requests/commit/0123abc");
    expect(full.ok && full.kind).toBe("commit");
    expect(short.ok && short.sha).toBe("0123abc");
  });

  it.each([
    ["", /Enter a GitHub/],
    ["not a url", /complete URL/],
    ["https://gitlab.com/owner/repo/pull/1", /Only github.com/],
    ["https://github.com.evil.example/owner/repo/pull/1", /Only github.com/],
    ["https://user:pass@github.com/owner/repo/pull/1", /credentials/],
    ["https://github.com:8443/owner/repo/pull/1", /ports/],
    ["https://github.com/owner/repo/pull/1?token=x", /query strings/],
    ["https://github.com/owner/repo/pull/1#discussion", /query strings/],
    ["https://github.com/owner/repo/issues/1", /pull request and commit/],
    ["https://github.com/owner/repo/pull/0", /positive integers/],
    ["https://github.com/owner/repo/commit/xyz", /hexadecimal/],
    ["https://github.com/owner/repo.git", /Expected/],
    ["https://github.com/owner/repo/pull/1/extra", /Expected/],
    ["https://github.com/owner/repo/blob/main/app.py", /Expected/],
    ["https://github.com/owner/repo/tree/main", /pull request and commit/],
  ])("rejects %s", (input, expected) => {
    const result = parseGitHubUrl(input);
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.error).toMatch(expected);
  });

  it("rejects percent-encoded paths", () => {
    const result = parseGitHubUrl("https://github.com/owner/repo/pull/%31");
    expect(result.ok).toBe(false);
  });
});
