"""Approximate SZZ labelling with provenance.

For each commit whose message looks like a bug fix, the deleted/modified source
lines are blamed in the fix's parent commit. The commits that introduced those
lines are suspected bug-introducing commits. Labels are approximate: they can
contain false positives and negatives, and every edge is written to CSV with
its provenance and reason.

Usage:
    python szz.py --raw data/raw/commits_pilot.csv \
                  --out data/processed/labels_pilot.csv --max-fixes 60
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import subprocess
import sys
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from config import BACKEND_DIR
from core import detect_bug_fix
from repo_utils import ensure_clone, repo_path_for

SOURCE_EXTENSIONS = {
    ".py",
    ".pyx",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".java",
    ".go",
    ".rb",
    ".php",
    ".c",
    ".h",
    ".cc",
    ".cpp",
    ".rs",
    ".kt",
}
SKIP_PATH_RE = re.compile(
    r"(^|/)(tests?|docs?|examples?|migrations?|vendor|node_modules|\.github)(/|$)"
    r"|(^|/)test_[^/]+$|_test\.py$|\.(md|rst|txt|json|ya?ml|lock)$",
    re.IGNORECASE,
)
BLAME_HEADER_RE = re.compile(r"^([0-9a-fA-F^]{7,41}) \d+ \d+(?: \d+)?$")

LABEL_COLUMNS = [
    "repo",
    "fix_sha",
    "fix_message",
    "fix_date",
    "introducing_sha",
    "provenance",
    "fix_signal",
    "in_window",
    "file",
    "old_line_start",
    "old_line_end",
    "reason",
]


def _iso(value: Any) -> str:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    return ""


def _parse_date(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _load_raw(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row.get("error"):
                continue
            if str(row.get("is_merge", "")).lower() == "true":
                continue
            parents = []
            try:
                parsed_parents = json.loads(row.get("parents") or "[]")
                if isinstance(parsed_parents, list):
                    parents = [str(item) for item in parsed_parents]
            except ValueError:
                pass
            files = []
            try:
                parsed_files = json.loads(row.get("file_paths") or "[]")
                if isinstance(parsed_files, list):
                    files = [str(item) for item in parsed_files]
            except ValueError:
                pass
            records.append(
                {
                    "repo": row.get("repo", ""),
                    "sha": (row.get("sha") or "").lower(),
                    "message": row.get("message") or "",
                    "author_date": row.get("author_date") or "",
                    "parents": parents,
                    "files": files,
                }
            )
    return records


def _group_spans(line_numbers: Iterable[int]) -> list[tuple[int, int]]:
    ordered = sorted({int(number) for number in line_numbers if int(number) > 0})
    spans: list[tuple[int, int]] = []
    for number in ordered:
        if spans and number == spans[-1][1] + 1:
            spans[-1] = (spans[-1][0], number)
        else:
            spans.append((number, number))
    return spans


def _blame(
    repo_path: Path,
    parent_sha: str,
    file_path: str,
    start: int,
    end: int,
    timeout: int,
) -> tuple[list[str], str | None]:
    try:
        completed = subprocess.run(
            [
                "git",
                "-C",
                str(repo_path),
                "blame",
                "--porcelain",
                "-L",
                f"{start},{end}",
                parent_sha,
                "--",
                file_path,
            ],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return [], "git blame timed out"
    if completed.returncode != 0:
        return [], (completed.stderr or "git blame failed").strip()[:300]
    shas: list[str] = []
    for line in completed.stdout.splitlines():
        match = BLAME_HEADER_RE.match(line)
        if not match:
            continue
        sha = match.group(1).lstrip("^").lower()
        if set(sha) == {"0"}:
            continue
        if sha not in shas:
            shas.append(sha)
    return shas, None


def _is_eligible_path(path: str | None) -> bool:
    if not path:
        return False
    lowered = path.lower()
    dot = lowered.rfind(".")
    if dot < 0 or lowered[dot:] not in SOURCE_EXTENSIONS:
        return False
    return not SKIP_PATH_RE.search(lowered)


def _source_lines(deleted: Any) -> list[int]:
    numbers: list[int] = []
    if not isinstance(deleted, list):
        return numbers
    for item in deleted:
        if not isinstance(item, (list, tuple)) or len(item) != 2:
            continue
        number, text = item
        if not isinstance(number, int) or not text:
            continue
        stripped = str(text).strip()
        if not stripped or stripped.startswith(("#", "//", "/*", "*")):
            continue
        numbers.append(number)
    return numbers


def label_repository(
    repo: str,
    records: list[dict[str, Any]],
    *,
    clone_dir: Path,
    max_fixes: int,
    max_files_per_fix: int,
    max_spans_per_file: int,
    max_blame_calls: int,
    blame_timeout: int,
) -> tuple[list[dict[str, str]], dict[str, Any]]:
    from pydriller import Git  # lazy import

    repo_status: dict[str, Any] = {
        "repo": repo,
        "candidates": 0,
        "fixes_processed": 0,
        "fixes_traced": 0,
        "fixes_untraceable": 0,
        "excluded": 0,
        "label_edges": 0,
        "blame_calls": 0,
        "truncated_fixes": 0,
        "errors": 0,
        "status": "ok",
    }
    rows: list[dict[str, str]] = []
    commit_by_sha = {record["sha"]: record for record in records if record["sha"]}
    excluded_records = []
    candidates = []
    for record in records:
        signal = detect_bug_fix(record["message"])
        if signal.is_candidate and len(record["parents"]) == 1:
            candidates.append(record)
        elif signal.excluded:
            excluded_records.append((record, signal))

    repo_status["candidates"] = len(candidates)
    for record, signal in excluded_records:
        repo_status["excluded"] += 1
        rows.append(
            {
                "repo": repo,
                "fix_sha": record["sha"],
                "fix_message": record["message"][:300],
                "fix_date": record["author_date"],
                "introducing_sha": "",
                "provenance": "excluded",
                "fix_signal": "heuristic_bug_fix",
                "in_window": "false",
                "file": "",
                "old_line_start": "",
                "old_line_end": "",
                "reason": signal.reason,
            }
        )

    try:
        clone_path = ensure_clone(repo, clone_dir)
        local = Git(str(clone_path))
    except Exception as exc:
        repo_status["status"] = "failed"
        repo_status["failure"] = str(exc)[:500]
        return rows, repo_status

    for record in candidates[:max_fixes]:
        repo_status["fixes_processed"] += 1
        fix_sha = record["sha"]
        parent_sha = record["parents"][0]
        try:
            fix_commit = local.get_commit(fix_sha)
        except Exception as exc:
            repo_status["errors"] += 1
            repo_status["fixes_untraceable"] += 1
            rows.append(
                {
                    "repo": repo,
                    "fix_sha": fix_sha,
                    "fix_message": record["message"][:300],
                    "fix_date": record["author_date"],
                    "introducing_sha": "",
                    "provenance": "untraceable",
                    "fix_signal": "heuristic_bug_fix",
                    "in_window": "false",
                    "file": "",
                    "old_line_start": "",
                    "old_line_end": "",
                    "reason": f"could not load fix commit: {exc}"[:300],
                }
            )
            continue

        found: dict[str, dict[str, Any]] = {}
        blame_calls = 0
        truncated = False
        try:
            modifications = list(fix_commit.modified_files)
        except Exception as exc:
            repo_status["errors"] += 1
            repo_status["fixes_untraceable"] += 1
            rows.append(
                {
                    "repo": repo,
                    "fix_sha": fix_sha,
                    "fix_message": record["message"][:300],
                    "fix_date": record["author_date"],
                    "introducing_sha": "",
                    "provenance": "untraceable",
                    "fix_signal": "heuristic_bug_fix",
                    "in_window": "false",
                    "file": "",
                    "old_line_start": "",
                    "old_line_end": "",
                    "reason": f"could not read modifications: {exc}"[:300],
                }
            )
            continue
        for modification in modifications[:max_files_per_fix]:
            change_type = getattr(modification.change_type, "name", str(modification.change_type))
            if change_type not in {"MODIFY", "DELETE"}:
                continue
            old_path = modification.old_path
            if not _is_eligible_path(old_path):
                continue
            line_numbers = _source_lines((modification.diff_parsed or {}).get("deleted"))
            for start, end in _group_spans(line_numbers)[:max_spans_per_file]:
                if blame_calls >= max_blame_calls:
                    truncated = True
                    break
                blame_calls += 1
                repo_status["blame_calls"] += 1
                shas, error = _blame(
                    clone_path, parent_sha, old_path or "", start, end, blame_timeout
                )
                if error:
                    continue
                for sha in shas:
                    if sha == fix_sha.lower():
                        continue
                    found.setdefault(
                        sha,
                        {
                            "file": old_path or "",
                            "start": start,
                            "end": end,
                            "reason": (
                                f"blame of {old_path}:{start}-{end} in parent {parent_sha[:7]} "
                                f"attributes the lines deleted by bug-fix commit {fix_sha[:7]} to {sha[:7]}"
                            ),
                        },
                    )
            if truncated:
                break
        if truncated:
            repo_status["truncated_fixes"] += 1
        if found:
            repo_status["fixes_traced"] += 1
            for introducing_sha, detail in found.items():
                in_window = introducing_sha in commit_by_sha
                rows.append(
                    {
                        "repo": repo,
                        "fix_sha": fix_sha,
                        "fix_message": record["message"][:300],
                        "fix_date": record["author_date"],
                        "introducing_sha": introducing_sha,
                        "provenance": "szz_candidate",
                        "fix_signal": "heuristic_bug_fix",
                        "in_window": "true" if in_window else "false",
                        "file": detail["file"],
                        "old_line_start": str(detail["start"]),
                        "old_line_end": str(detail["end"]),
                        "reason": detail["reason"],
                    }
                )
                repo_status["label_edges"] += 1
        else:
            repo_status["fixes_untraceable"] += 1
            rows.append(
                {
                    "repo": repo,
                    "fix_sha": fix_sha,
                    "fix_message": record["message"][:300],
                    "fix_date": record["author_date"],
                    "introducing_sha": "",
                    "provenance": "untraceable",
                    "fix_signal": "heuristic_bug_fix",
                    "in_window": "false",
                    "file": "",
                    "old_line_start": "",
                    "old_line_end": "",
                    "reason": "no blame-traceable deleted source lines were found",
                }
            )
    return rows, repo_status


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Approximate SZZ bug-introducing commit labelling")
    parser.add_argument("--raw", required=True, help="Raw commit CSV produced by mine.py")
    parser.add_argument("--out", default=None, help="Labels CSV output")
    parser.add_argument("--status-out", default=None)
    parser.add_argument("--clone-dir", default=str(BACKEND_DIR / "data" / "repos"))
    parser.add_argument("--max-fixes", type=int, default=100, help="Candidate fixes per repository")
    parser.add_argument("--max-files-per-fix", type=int, default=10)
    parser.add_argument("--max-spans-per-file", type=int, default=8)
    parser.add_argument("--max-blame-calls", type=int, default=30, help="Blame calls per fix")
    parser.add_argument("--blame-timeout", type=int, default=30)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    raw_path = Path(args.raw)
    out_path = Path(args.out) if args.out else raw_path.with_name("labels.csv")
    status_path = Path(args.status_out) if args.status_out else out_path.with_name(
        out_path.stem + "_status.json"
    )
    if not raw_path.exists():
        print(f"Raw commit file not found: {raw_path}", file=sys.stderr)
        return 1

    records = _load_raw(raw_path)
    by_repo: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        by_repo[record["repo"]].append(record)

    started = time.monotonic()
    all_rows: list[dict[str, str]] = []
    repo_statuses = []
    for repo in sorted(by_repo):
        print(f"[{repo}] labelling up to {args.max_fixes} candidate fixes...")
        try:
            rows, repo_status = label_repository(
                repo,
                by_repo[repo],
                clone_dir=Path(args.clone_dir),
                max_fixes=args.max_fixes,
                max_files_per_fix=args.max_files_per_fix,
                max_spans_per_file=args.max_spans_per_file,
                max_blame_calls=args.max_blame_calls,
                blame_timeout=args.blame_timeout,
            )
        except RuntimeError as exc:
            print(f"[{repo}] failed: {exc}", file=sys.stderr)
            rows, repo_status = [], {"repo": repo, "status": "failed", "failure": str(exc)[:500]}
        all_rows.extend(rows)
        repo_statuses.append(repo_status)
        print(
            f"[{repo}] {repo_status.get('status')} traces={repo_status.get('fixes_traced', 0)} "
            f"untraceable={repo_status.get('fixes_untraceable', 0)} edges={repo_status.get('label_edges', 0)}"
        )

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=LABEL_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(all_rows)

    status = {
        "raw": str(raw_path),
        "output": str(out_path),
        "generated_at": _iso(datetime.now(timezone.utc)),
        "duration_seconds": round(time.monotonic() - started, 2),
        "label_rows": len(all_rows),
        "szz_edges": sum(1 for row in all_rows if row["provenance"] == "szz_candidate"),
        "untraceable_fixes": sum(1 for row in all_rows if row["provenance"] == "untraceable"),
        "excluded": sum(1 for row in all_rows if row["provenance"] == "excluded"),
        "repositories": repo_statuses,
        "limitations": (
            "SZZ is approximate. Blame only inspects the fix's parent, skips test/doc files, "
            "and is limited by the mined commit window and blame caps."
        ),
    }
    status_path.write_text(json.dumps(status, indent=2), encoding="utf-8")
    print(f"Labels: {out_path} ({len(all_rows)} rows)")
    print(f"Status: {status_path}")
    return 0 if any(item.get("status") == "ok" for item in repo_statuses) else 1


if __name__ == "__main__":
    raise SystemExit(main())
