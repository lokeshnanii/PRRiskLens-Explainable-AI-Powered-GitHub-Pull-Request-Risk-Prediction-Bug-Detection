"""Tests for the shared feature schema, risk bands and bug-fix heuristic."""

from __future__ import annotations

from dataclasses import replace
from datetime import timedelta
from pathlib import Path

import pytest

from config import Settings
from conftest import FakeGitHubClient, bug_fix_commit, iso, make_pull_snapshot, utc
from core import (
    FEATURES,
    FeatureValidationError,
    detect_bug_fix,
    feature_vector,
    risk_category,
    validate_features,
)
from features import extract_features
from gh import GitHubError

VALID = {
    "files_changed": 4,
    "lines_added": 120,
    "lines_deleted": 30,
    "previous_author_commits": 25,
    "prior_bug_fixes_in_touched_files": 2,
    "commit_hour": 14,
}


def test_feature_order_is_the_contract():
    assert FEATURES == (
        "files_changed",
        "lines_added",
        "lines_deleted",
        "previous_author_commits",
        "prior_bug_fixes_in_touched_files",
        "commit_hour",
    )


def test_validate_features_returns_canonical_order():
    cleaned = validate_features({"commit_hour": 3, **{k: v for k, v in VALID.items() if k != "commit_hour"}})
    assert list(cleaned) == list(FEATURES)
    assert cleaned["commit_hour"] == 3
    assert feature_vector(VALID) == (4, 120, 30, 25, 2, 14)


@pytest.mark.parametrize(
    "bad, expected",
    [
        ({"files_changed": -1}, "files_changed"),
        ({"commit_hour": 24}, "commit_hour"),
        ({"commit_hour": -1}, "commit_hour"),
        ({"files_changed": 1.5}, "files_changed"),
        ({"files_changed": True}, "files_changed"),
        ({"files_changed": "4"}, "files_changed"),
        ({"lines_added": None}, "lines_added"),
    ],
)
def test_validate_features_rejects_invalid_values(bad, expected):
    with pytest.raises(FeatureValidationError) as excinfo:
        validate_features({**VALID, **bad})
    assert expected in excinfo.value.errors


def test_validate_features_rejects_missing_and_extra():
    with pytest.raises(FeatureValidationError) as missing:
        validate_features({k: v for k, v in VALID.items() if k != "commit_hour"})
    assert "commit_hour" in missing.value.errors

    with pytest.raises(FeatureValidationError) as extra:
        validate_features({**VALID, "surprise": 1})
    assert "surprise" in extra.value.errors

    # Extra keys are allowed only when explicitly requested (internal callers).
    assert validate_features({**VALID, "surprise": 1}, allow_extra=True)["files_changed"] == 4


@pytest.mark.parametrize(
    "score, expected",
    [(0, "Low"), (34.9, "Low"), (35, "Medium"), (69.9, "Medium"), (70, "High"), (100, "High")],
)
def test_risk_category_boundaries(score, expected):
    assert risk_category(score) == expected


def test_risk_category_custom_bands():
    assert risk_category(50, low_threshold=60, high_threshold=90) == "Low"
    assert risk_category(65, low_threshold=60, high_threshold=90) == "Medium"
    assert risk_category(95, low_threshold=60, high_threshold=90) == "High"


def test_risk_category_rejects_invalid_scores():
    with pytest.raises(ValueError):
        risk_category(-1)
    with pytest.raises(ValueError):
        risk_category(101)
    with pytest.raises(ValueError):
        risk_category(float("nan"))


@pytest.mark.parametrize(
    "message, expected",
    [
        ("Fix crash in parser", True),
        ("Fix null pointer when name is missing", True),
        ("Fix bug #12 in login flow", True),
        ("patch regression in retry logic", True),
        ("Correct incorrect behavior in pagination", True),
        ("Fix typo in docs", False),
        ("Fix formatting and whitespace", False),
        ("Update README", False),
        ("Refactor storage layer", False),
        ("", False),
        (None, False),
    ],
)
def test_bug_fix_heuristic(message, expected):
    signal = detect_bug_fix(message)
    assert signal.is_candidate is expected
    if expected:
        assert signal.terms


def test_bug_fix_heuristic_explains_exclusions():
    signal = detect_bug_fix("fix typo in docs")
    assert signal.is_candidate is False
    assert signal.excluded is True
    assert "non-bug" in signal.reason


def test_extract_features_pull_request(settings: Settings):
    client = FakeGitHubClient()
    snapshot = make_pull_snapshot()
    extraction = extract_features(client, snapshot, settings)

    assert list(extraction.values) == list(FEATURES)
    assert extraction.values == {
        "files_changed": 3,
        "lines_added": 5,
        "lines_deleted": 4,
        "previous_author_commits": 12,
        "prior_bug_fixes_in_touched_files": 1,
        "commit_hour": 13,
    }
    assert extraction.provenance["files_changed"] == "github_pull_request_totals"
    assert extraction.provenance["commit_hour"] == "earliest_pull_request_commit_authored_utc"
    # Historical windows are always partial: they are bounded by design.
    assert extraction.completeness["prior_bug_fixes_in_touched_files"] == "partial"
    assert extraction.overall_completeness == "partial"

    cutoff = snapshot.earliest_commit_at
    assert client.count_calls == [cutoff]
    assert all(call_cutoff == cutoff for _, call_cutoff in client.history_calls)
    # A pull request has several files; the history is bounded to the most changed ones.
    assert len(client.history_calls) == len(snapshot.files)


def test_extract_features_missing_author(settings: Settings):
    snapshot = replace(make_pull_snapshot(), author_login=None)
    client = FakeGitHubClient(snapshot)
    extraction = extract_features(client, snapshot, settings)
    assert extraction.values["previous_author_commits"] == 0
    assert extraction.completeness["previous_author_commits"] == "unavailable"
    assert any("author" in warning.lower() for warning in extraction.warnings)


def test_extract_features_emits_token_warning():
    settings = Settings(models_dir=Path("/tmp/nope"))
    extraction = extract_features(FakeGitHubClient(), make_pull_snapshot(), settings)
    assert any("GITHUB_TOKEN is not configured" in warning for warning in extraction.warnings)


def test_history_is_strictly_before_cutoff(settings: Settings):
    snapshot = make_pull_snapshot()
    cutoff = snapshot.earliest_commit_at
    history = [
        bug_fix_commit(sha="a" * 40, authored_at=iso(cutoff - timedelta(days=1))),
        # Same timestamp as the cutoff must not count as "prior".
        bug_fix_commit(sha="b" * 40, authored_at=iso(cutoff)),
        # The analyzed commit itself must never count.
        bug_fix_commit(sha=snapshot.sha, authored_at=iso(cutoff - timedelta(days=2))),
        # Merge commits are ignored.
        {
            "sha": "f" * 40,
            "parents": [{"sha": "1" * 40}, {"sha": "2" * 40}],
            "commit": {
                "author": {"date": iso(cutoff - timedelta(days=3))},
                "message": "Merge branch 'fix'",
            },
        },
    ]
    client = FakeGitHubClient(snapshot, file_history=history)
    extraction = extract_features(client, snapshot, settings)
    assert extraction.values["prior_bug_fixes_in_touched_files"] == 1


def test_history_errors_are_not_silenced(settings: Settings):
    class BrokenClient(FakeGitHubClient):
        def list_file_commits_before(self, *args, **kwargs):
            raise GitHubError("github_upstream_error", "boom", status_code=502)

    with pytest.raises(GitHubError):
        extract_features(BrokenClient(), make_pull_snapshot(), settings)


def test_commit_snapshot_aggregation_note(settings: Settings):
    snapshot = replace(
        make_pull_snapshot(),
        kind="commit",
        number=None,
        commits=make_pull_snapshot().commits[:1],
        author_login=None,
    )
    extraction = extract_features(FakeGitHubClient(snapshot), snapshot, settings)
    assert "Commit features" in extraction.aggregation_note
    assert extraction.provenance["commit_hour"] == "commit_authored_utc"
    assert extraction.values["files_changed"] == snapshot.total_files
