export type ParsedGitHubUrl =
  | {
      ok: true;
      kind: "pull" | "commit";
      owner: string;
      repo: string;
      number: number | null;
      sha: string | null;
      canonical: string;
      preview: string;
    }
  | { ok: false; error: string };

const OWNER_RE = /^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$/;
const REPO_RE = /^[A-Za-z0-9._-]{1,100}$/;
const SHA_RE = /^[0-9a-fA-F]{7,40}$/;
const PR_RE = /^[1-9][0-9]{0,9}$/;

/**
 * Mirror of the backend validator. The backend re-validates every URL, so this
 * exists to give immediate feedback rather than as a security boundary.
 */
export function parseGitHubUrl(raw: string): ParsedGitHubUrl {
  const value = raw.trim();
  if (!value) {
    return { ok: false, error: "Enter a GitHub pull request or commit URL." };
  }
  if (value.length > 500) {
    return { ok: false, error: "URL is too long." };
  }

  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    return { ok: false, error: "Enter a complete URL beginning with https://." };
  }

  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    return { ok: false, error: "Only http(s) GitHub URLs are supported." };
  }
  if (parsed.username || parsed.password) {
    return { ok: false, error: "URLs with embedded credentials are not allowed." };
  }
  if (parsed.port) {
    return { ok: false, error: "URLs with explicit ports are not supported." };
  }
  const host = parsed.hostname.toLowerCase();
  if (host !== "github.com" && host !== "www.github.com") {
    return { ok: false, error: "Only github.com URLs are supported." };
  }
  if (parsed.search || parsed.hash) {
    return { ok: false, error: "Remove query strings and fragments from the URL." };
  }
  if (parsed.pathname.includes("%")) {
    return { ok: false, error: "Encoded URL paths are not supported." };
  }

  const segments = parsed.pathname.replace(/^\/+|\/+$/g, "").split("/");
  if (segments.length !== 4) {
    return {
      ok: false,
      error: "Expected https://github.com/OWNER/REPOSITORY/pull/NUMBER or /commit/SHA.",
    };
  }
  const [owner, repo, resource, tail] = segments;
  if (!OWNER_RE.test(owner)) {
    return { ok: false, error: "That GitHub owner name is not valid." };
  }
  if (!REPO_RE.test(repo) || repo.endsWith(".git")) {
    return { ok: false, error: "That GitHub repository name is not valid." };
  }

  if (resource === "pull") {
    if (!PR_RE.test(tail)) {
      return { ok: false, error: "Pull request numbers must be positive integers." };
    }
    const number = Number(tail);
    return {
      ok: true,
      kind: "pull",
      owner,
      repo,
      number,
      sha: null,
      canonical: `https://github.com/${owner}/${repo}/pull/${number}`,
      preview: `${owner}/${repo} · Pull request #${number}`,
    };
  }

  if (resource === "commit") {
    if (!SHA_RE.test(tail)) {
      return { ok: false, error: "Commit URLs need a 7-40 character hexadecimal SHA." };
    }
    const sha = tail.toLowerCase();
    return {
      ok: true,
      kind: "commit",
      owner,
      repo,
      number: null,
      sha,
      canonical: `https://github.com/${owner}/${repo}/commit/${sha}`,
      preview: `${owner}/${repo} · Commit ${sha.slice(0, 7)}`,
    };
  }

  return { ok: false, error: "Only pull request and commit URLs are supported." };
}
