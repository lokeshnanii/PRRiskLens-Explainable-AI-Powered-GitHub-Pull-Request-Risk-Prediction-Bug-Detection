"""Model artifact loading and inference.

The model is loaded from ``models/model.joblib`` and reloaded automatically if
the artifact changes on disk. A missing or invalid artifact never produces a
prediction; the API reports an explicit unavailable state instead.
"""

from __future__ import annotations

import json
import logging
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

import joblib
import numpy as np

from core import (
    FEATURES,
    FEATURE_SCHEMA_VERSION,
    SCORE_INTERPRETATION,
    risk_category,
    validate_features,
)
from explain import explain_prediction

logger = logging.getLogger("prrisklens.inference")


@dataclass
class ModelBundle:
    kind: str
    model: Any
    model_version: str
    schema_version: str
    threshold: float
    metadata: dict[str, Any] = field(default_factory=dict)
    scaler: Any | None = None
    background: np.ndarray | None = None
    training_rows: int | None = None

    @property
    def explanation_available(self) -> bool:
        return self.kind in {"xgboost", "logistic"}


class ModelRegistry:
    """Thread-safe lazy loader with artifact-change detection."""

    def __init__(self, models_dir: Path) -> None:
        self.models_dir = Path(models_dir)
        self._lock = threading.Lock()
        self._signature: tuple[Any, ...] | None = None
        self._bundle: ModelBundle | None = None
        self._last_error: str | None = None

    def _signature_now(self) -> tuple[Any, ...]:
        paths = [
            self.models_dir / "model.joblib",
            self.models_dir / "metadata.json",
            self.models_dir / "background.joblib",
        ]
        return tuple(
            (str(path), path.stat().st_mtime_ns, path.stat().st_size) if path.exists() else (str(path), None, None)
            for path in paths
        )

    def get(self) -> ModelBundle | None:
        with self._lock:
            try:
                signature = self._signature_now()
            except OSError as exc:
                self._bundle = None
                self._last_error = f"Could not inspect model artifacts: {exc}"
                return None
            if signature == self._signature:
                return self._bundle
            self._signature = signature
            self._bundle = None
            self._last_error = None
            self._bundle = self._load()
            return self._bundle

    def _load(self) -> ModelBundle | None:
        artifact = self.models_dir / "model.joblib"
        if not artifact.exists():
            self._last_error = (
                "No trained model artifact found. Run mine.py, szz.py, dataset.py and train.py."
            )
            return None
        metadata: dict[str, Any] = {}
        metadata_path = self.models_dir / "metadata.json"
        if metadata_path.exists():
            try:
                metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            except (ValueError, OSError) as exc:
                logger.warning("Ignoring unreadable metadata.json: %s", exc)

        try:
            payload = joblib.load(artifact)
        except Exception as exc:
            self._last_error = f"Model artifact could not be loaded: {exc}"
            logger.exception("Failed to load model artifact")
            return None
        if not isinstance(payload, dict):
            self._last_error = "Model artifact has an unexpected format."
            return None

        kind = payload.get("kind")
        model = payload.get("model")
        features = payload.get("features")
        schema_version = str(
            payload.get("feature_schema_version")
            or metadata.get("feature_schema_version")
            or ""
        )
        if kind not in {"xgboost", "logistic"} or model is None:
            self._last_error = "Model artifact is missing a supported estimator."
            return None
        if features != list(FEATURES):
            self._last_error = (
                "Model feature schema does not match the API schema; retrain the model."
            )
            return None
        if schema_version != FEATURE_SCHEMA_VERSION:
            self._last_error = (
                f"Model schema version {schema_version or 'unknown'} does not match "
                f"API schema {FEATURE_SCHEMA_VERSION}; retrain the model."
            )
            return None
        if kind == "logistic" and payload.get("scaler") is None:
            self._last_error = "Logistic model artifact is missing its scaler."
            return None

        background = None
        background_path = self.models_dir / "background.joblib"
        if background_path.exists():
            try:
                loaded = joblib.load(background_path)
                background = np.asarray(loaded, dtype=float)
                if background.ndim != 2 or background.shape[1] != len(FEATURES):
                    background = None
            except Exception as exc:
                logger.warning("Background sample could not be loaded: %s", exc)
                background = None

        if kind == "logistic" and background is None:
            self._last_error = (
                "Logistic model requires a background sample for SHAP explanations; "
                "retrain or restore background.joblib."
            )
            return None

        version = str(
            payload.get("model_version")
            or metadata.get("model_version")
            or "unknown"
        )
        threshold = float(payload.get("threshold") or metadata.get("threshold") or 0.5)
        bundle = ModelBundle(
            kind=str(kind),
            model=model,
            model_version=version,
            schema_version=schema_version,
            threshold=threshold,
            metadata=metadata,
            scaler=payload.get("scaler"),
            background=background,
            training_rows=payload.get("training_rows") or (metadata.get("dataset") or {}).get("rows"),
        )
        self._last_error = None
        logger.info("Loaded model %s (%s)", version, kind)
        return bundle

    def status(self) -> dict[str, Any]:
        bundle = self.get()
        return {
            "model_available": bundle is not None,
            "model_version": bundle.model_version if bundle else None,
            "model_type": bundle.kind if bundle else None,
            "feature_schema_version": FEATURE_SCHEMA_VERSION,
            "reason": None if bundle else self._last_error,
        }


def predict_with_bundle(
    bundle: ModelBundle,
    values: Mapping[str, Any],
    *,
    low_threshold: float,
    high_threshold: float,
) -> dict[str, Any]:
    cleaned = validate_features(values)
    x = np.asarray([[cleaned[name] for name in FEATURES]], dtype=float)

    if bundle.kind == "xgboost":
        probabilities = bundle.model.predict_proba(x)
    else:
        scaled = bundle.scaler.transform(x)
        probabilities = bundle.model.predict_proba(scaled)
    probability = float(np.asarray(probabilities).reshape(-1)[1])
    if not np.isfinite(probability):
        raise RuntimeError("Model produced a non-finite prediction")
    probability = min(1.0, max(0.0, probability))
    score = round(probability * 100, 1)
    category = risk_category(score, low_threshold, high_threshold)

    warnings: list[str] = []
    if bundle.training_rows and bundle.training_rows < 500:
        warnings.append(
            f"The deployed model was trained on only {bundle.training_rows} commits; treat "
            "its ranking as a weak signal."
        )

    explanation = explain_prediction(bundle, cleaned)
    if not explanation.available:
        warnings.append(
            "SHAP explanation is unavailable for this prediction; no factor contributions "
            "are shown."
        )

    return {
        "status": "ok",
        "risk_score": score,
        "risk_category": category,
        "model_version": bundle.model_version,
        "model_type": bundle.kind,
        "model_output": round(probability, 6),
        "model_output_note": (
            "Raw classifier output, not a calibrated bug probability. The 0-100 score is a "
            "normalized ranking index."
        ),
        "input_features": cleaned,
        "feature_order": list(FEATURES),
        "factors": explanation.factors,
        "all_contributions": explanation.contributions,
        "base_value": explanation.base_value,
        "shap_available": explanation.shap_used,
        "explanation_status": explanation.explanation_status,
        "explanation_method": explanation.method,
        "explanation_note": explanation.note,
        "explanation_error": explanation.error,
        "contribution_scale": explanation.contribution_scale,
        "thresholds": {"low_max": low_threshold, "high_min": high_threshold},
        "score_interpretation": SCORE_INTERPRETATION,
        "warnings": warnings,
    }
