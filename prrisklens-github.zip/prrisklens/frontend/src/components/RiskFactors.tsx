import { useState } from "react";
import { ArrowDownRight, ArrowUpRight, BarChart3, Info, Minus, Sparkles } from "lucide-react";
import type { FeatureBlock, Prediction, RiskFactor } from "../types/analysis";
import { featureValueLabel, titleCase } from "../lib/format";

interface RiskFactorsProps {
  prediction: Prediction;
  features?: FeatureBlock;
}

function signed(value: number): string {
  if (value === 0) return "0.000";
  return `${value > 0 ? "+" : "−"}${Math.abs(value).toFixed(3)}`;
}

function ContributionRow({ factor, maxAbs }: { factor: RiskFactor; maxAbs: number }) {
  const width = maxAbs > 0 ? Math.min(100, (Math.abs(factor.contribution) / maxAbs) * 100) : 0;
  const positive = factor.contribution > 0;
  const neutral = factor.contribution === 0;

  return (
    <li className="rounded-lg border border-white/[0.06] bg-white/[0.015] p-3">
      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
        <span className="text-[12px] font-medium text-slate-200">{factor.label}</span>
        <span className="font-mono text-[10px] text-slate-500">= {featureValueLabel(factor.feature, factor.value)}</span>
        <span
          className={`ml-auto inline-flex items-center gap-1 font-mono text-[10.5px] ${
            neutral ? "text-slate-400" : positive ? "text-rose-300" : "text-sky-300"
          }`}
        >
          {neutral ? (
            <Minus className="h-3 w-3" aria-hidden="true" />
          ) : positive ? (
            <ArrowUpRight className="h-3 w-3" aria-hidden="true" />
          ) : (
            <ArrowDownRight className="h-3 w-3" aria-hidden="true" />
          )}
          {signed(factor.contribution)}
        </span>
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/[0.05]" aria-hidden="true">
        <div
          className={`h-full rounded-full ${
            neutral
              ? "bg-slate-500"
              : positive
                ? "bg-gradient-to-r from-amber-400 to-rose-400"
                : "bg-gradient-to-r from-sky-400 to-emerald-400"
          }`}
          style={{ width: `${Math.max(2, width)}%` }}
        />
      </div>
      <p className="mt-2 text-[11px] leading-relaxed text-slate-400">{factor.explanation}</p>
      {factor.contribution_note ? (
        <p className="mt-1 font-mono text-[10px] text-slate-500">{factor.contribution_note}</p>
      ) : null}
    </li>
  );
}

export default function RiskFactors({ prediction, features }: RiskFactorsProps) {
  const [expanded, setExpanded] = useState(false);

  if (prediction.status !== "ok") return null;

  const factors = prediction.factors ?? [];
  const contributions = prediction.all_contributions ?? [];
  const maxAbs = contributions.reduce((max, item) => Math.max(max, Math.abs(item.contribution)), 0);
  const values = features?.values ?? prediction.input_features ?? null;
  const order = features?.order ?? prediction.feature_order ?? [];

  return (
    <section className="glass-panel flex h-full flex-col p-5 sm:p-6" aria-labelledby="risk-factors-title">
      <div className="flex items-center justify-between gap-2">
        <h2 id="risk-factors-title" className="section-label">
          Why this ranking
        </h2>
        <span className="chip">
          <Sparkles className="h-3 w-3 text-violet-300" aria-hidden="true" />
          {prediction.shap_available ? "SHAP contributions" : prediction.explanation_status ?? "No explanation"}
        </span>
      </div>

      {values && order.length ? (
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
          {order.map((name) => {
            const contribution = contributions.find((item) => item.feature === name);
            const completeness = features?.completeness?.[name];
            return (
              <div key={name} className="rounded-lg border border-white/[0.07] bg-white/[0.02] p-2.5">
                <p className="text-[9px] uppercase tracking-wider text-slate-500">
                  {contribution?.label ?? titleCase(name)}
                </p>
                <p className="mt-1 font-mono text-sm font-medium text-slate-100">
                  {featureValueLabel(name, values[name] ?? 0)}
                </p>
                {completeness ? (
                  <p className={`mt-0.5 text-[9px] ${completeness === "complete" ? "text-emerald-300/80" : "text-amber-300/80"}`}>
                    {completeness}
                  </p>
                ) : null}
              </div>
            );
          })}
        </div>
      ) : null}

      {factors.length ? (
        <div className="mt-5">
          <div className="mb-2 flex items-center gap-2">
            <span className="text-[11px] font-semibold text-rose-200">Top risk-raising factors</span>
            <span className="h-px flex-1 bg-gradient-to-r from-rose-400/20 to-transparent" aria-hidden="true" />
          </div>
          <ol className="space-y-2">
            {factors.map((factor) => (
              <ContributionRow key={factor.feature} factor={factor} maxAbs={maxAbs} />
            ))}
          </ol>
        </div>
      ) : (
        <p className="mt-5 rounded-lg border border-white/10 bg-white/[0.02] p-3 text-[11px] leading-relaxed text-slate-400">
          {prediction.explanation_note ||
            "No feature made a positive contribution above the baseline, so no risk-raising factors are available."}
        </p>
      )}

      {prediction.explanation_note ? (
        <p className="mt-3 flex items-start gap-2 text-[10.5px] leading-relaxed text-slate-500">
          <Info className="mt-0.5 h-3 w-3 shrink-0" aria-hidden="true" />
          {prediction.explanation_note}
        </p>
      ) : null}

      {prediction.explanation_error ? (
        <p className="mt-2 rounded-lg border border-amber-400/20 bg-amber-400/[0.05] p-2.5 text-[10.5px] leading-relaxed text-amber-200/80">
          Explanation unavailable: {prediction.explanation_error}
        </p>
      ) : null}

      {contributions.length ? (
        <div className="mt-5 border-t border-white/[0.06] pt-4">
          <button
            type="button"
            onClick={() => setExpanded((current) => !current)}
            className="flex w-full items-center gap-2 rounded-lg text-left text-[11px] font-medium text-slate-300 transition hover:text-white"
            aria-expanded={expanded}
          >
            <BarChart3 className="h-3.5 w-3.5 text-slate-500" aria-hidden="true" />
            {expanded ? "Hide" : "Show"} all six contributions
            <span className="ml-auto text-[10px] text-slate-500">{prediction.contribution_scale ?? "log-odds"}</span>
          </button>
          {expanded ? (
            <ol className="mt-3 space-y-2">
              {contributions.map((factor) => (
                <ContributionRow key={`all-${factor.feature}`} factor={factor} maxAbs={maxAbs} />
              ))}
            </ol>
          ) : null}
        </div>
      ) : null}

      <p className="mt-auto pt-4 text-[10px] leading-relaxed text-slate-500">
        Contributions explain the model output on a {prediction.contribution_scale ?? "log-odds"} scale. They
        describe associations learned from history, not proven causes of defects.
      </p>
    </section>
  );
}
