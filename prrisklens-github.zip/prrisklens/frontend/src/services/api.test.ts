import { afterEach, describe, expect, it, vi } from "vitest";
import { ApiError, API_BASE, api } from "./api";

function jsonResponse(status: number, payload: unknown) {
  return {
    ok: status >= 200 && status < 300,
    status,
    text: async () => JSON.stringify(payload),
  } as Response;
}

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe("api client", () => {
  it("requests health with credentials omitted", async () => {
    const fetchMock = vi.fn().mockResolvedValue(jsonResponse(200, { status: "ok", model_available: false }));
    vi.stubGlobal("fetch", fetchMock);

    const result = await api.health();

    expect(result.status).toBe("ok");
    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(url).toBe(`${API_BASE}/health`);
    expect(init.credentials).toBe("omit");
    expect(init.method).toBe("GET");
  });

  it("requests the GitHub quota snapshot", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      jsonResponse(200, {
        authenticated: true,
        mode: "authenticated",
        token_configured: true,
        expected_hourly_limit: 5000,
        rate_limit: { limit: 5000, remaining: 4999 },
        error: null,
        time: "2026-11-01T10:00:00Z",
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    const result = await api.rateLimit();

    expect(result.rate_limit?.remaining).toBe(4999);
    const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(url).toBe(`${API_BASE}/github-rate-limit`);
    expect(init.method).toBe("GET");
    expect(init.credentials).toBe("omit");
  });

  it("posts manual features as JSON", async () => {
    const fetchMock = vi.fn().mockResolvedValue(jsonResponse(200, { status: "ok", risk_score: 12 }));
    vi.stubGlobal("fetch", fetchMock);
    const features = {
      files_changed: 3,
      lines_added: 10,
      lines_deleted: 4,
      previous_author_commits: 20,
      prior_bug_fixes_in_touched_files: 1,
      commit_hour: 9,
    };

    const result = await api.predict(features);

    expect(result.risk_score).toBe(12);
    const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(url).toBe(`${API_BASE}/predict`);
    expect(init.method).toBe("POST");
    expect(JSON.parse(String(init.body))).toEqual(features);
  });

  it("maps the structured error envelope to ApiError", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        jsonResponse(503, {
          error: { code: "model_unavailable", message: "Train the model first.", details: { training_required: true } },
        }),
      ),
    );

    await expect(api.predict({} as never)).rejects.toMatchObject({
      name: "ApiError",
      code: "model_unavailable",
      status: 503,
      message: "Train the model first.",
      details: { training_required: true },
    });
  });

  it("reports network failures without leaking internals", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("fetch failed")));

    const error = await api.health().catch((caught: unknown) => caught);
    expect(error).toBeInstanceOf(ApiError);
    expect((error as ApiError).code).toBe("network_error");
    expect((error as ApiError).message).toContain(API_BASE);
  });

  it("rejects non-JSON success responses", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        text: async () => "<html></html>",
      } as Response),
    );

    await expect(api.modelInfo()).rejects.toMatchObject({ code: "invalid_response" });
  });

  it("uses a sanitized fallback for unstructured failures", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({ ok: false, status: 502, text: async () => "bad gateway" } as Response),
    );

    await expect(api.analyzeUrl("https://github.com/o/r/pull/1")).rejects.toMatchObject({
      code: "api_error",
      status: 502,
    });
  });
});
