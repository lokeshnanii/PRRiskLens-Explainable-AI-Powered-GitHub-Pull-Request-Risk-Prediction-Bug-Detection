import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import type { Prediction } from "../types/analysis";
import RiskSummary from "./RiskSummary";

const THRESHOLDS = { low_max: 35, high_min: 70 };

function basePrediction(overrides: Partial<Prediction>): Prediction {
  return {
    status: "ok",
    factors: [],
    all_contributions: [],
    warnings: [],
    ...overrides,
  };
}

describe("RiskSummary", () => {
  it("shows an explicit no-model state instead of a score", () => {
    render(
      <RiskSummary
        prediction={basePrediction({
          status: "unavailable",
          message: "No trained risk model is available, so no score was produced.",
          reason: "No trained model artifact found.",
        })}
        thresholds={THRESHOLDS}
      />,
    );

    expect(screen.getByText(/No model/)).toBeInTheDocument();
    expect(screen.getByText(/no score was produced/i)).toBeInTheDocument();
    expect(screen.queryByText(/risk index/i)).toBeInTheDocument();
    expect(screen.getByText(/python backend\/train.py/)).toBeInTheDocument();
    expect(screen.queryByText(/High risk band/)).not.toBeInTheDocument();
  });

  it("renders the score, band and interpretation for an available model", () => {
    render(
      <RiskSummary
        prediction={basePrediction({
          risk_score: 82.4,
          risk_category: "High",
          model_version: "xgb-test",
          model_type: "xgboost",
          shap_available: true,
          score_interpretation: "Ranking index, not a calibrated probability.",
          model_output_note: "Raw classifier output.",
        })}
        thresholds={THRESHOLDS}
      />,
    );

    expect(screen.getByText("82.4")).toBeInTheDocument();
    expect(screen.getByText(/High risk band/)).toBeInTheDocument();
    expect(screen.getByText(/xgb-test/)).toBeInTheDocument();
    expect(screen.getByText(/Ranking index, not a calibrated probability/)).toBeInTheDocument();
    expect(screen.getByText(/Raw classifier output/)).toBeInTheDocument();
  });

  it("shows the completeness matrix and warnings", () => {
    render(
      <RiskSummary
        prediction={basePrediction({
          risk_score: 20,
          risk_category: "Low",
          model_version: "lr-test",
          model_type: "logistic",
          shap_available: true,
        })}
        thresholds={THRESHOLDS}
        completeness={{
          features: "partial",
          diff: "complete",
          code_analysis: "complete",
          prediction: "available",
          overall: "partial",
        }}
        warnings={["History window was full for 2 files."]}
      />,
    );

    expect(screen.getByText("partial")).toBeInTheDocument();
    expect(screen.getByText(/1 analysis warning/)).toBeInTheDocument();
    expect(screen.getByText(/History window was full/)).toBeInTheDocument();
  });
});
