import { ClipboardCheck, FileCode2 } from "lucide-react";
import type { ChecklistItem, Severity } from "../types/analysis";
import { SEVERITY_ORDER, SEVERITY_TONE } from "../lib/format";

interface ReviewChecklistProps {
  items: ChecklistItem[];
}

export default function ReviewChecklist({ items }: ReviewChecklistProps) {
  const ordered = [...items].sort(
    (left, right) => SEVERITY_ORDER[left.priority as Severity] - SEVERITY_ORDER[right.priority as Severity],
  );

  return (
    <section className="glass-panel p-5 sm:p-6" aria-labelledby="review-checklist-title">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h2 id="review-checklist-title" className="flex items-center gap-2 text-base font-semibold text-white">
            <ClipboardCheck className="h-4 w-4 text-aqua-400" aria-hidden="true" />
            Review checklist
          </h2>
          <p className="mt-1 text-[11.5px] leading-relaxed text-slate-400">
            Concrete review actions derived from this change. These are prompts, not findings or
            required approvals.
          </p>
        </div>
        <span className="chip">{ordered.length} items</span>
      </div>

      {ordered.length ? (
        <ol className="mt-4 space-y-2">
          {ordered.map((item, index) => {
            const tone = SEVERITY_TONE[item.priority as Severity] ?? SEVERITY_TONE.info;
            return (
              <li key={item.id} className="rounded-xl border border-white/[0.07] bg-white/[0.018] p-3">
                <div className="flex items-start gap-2.5">
                  <span className="mt-0.5 font-mono text-[10px] text-slate-500">{String(index + 1).padStart(2, "0")}</span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-[12.5px] font-medium text-slate-100">{item.title}</p>
                      <span className={`rounded-md border px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide ${tone.chip}`}>
                        {tone.label}
                      </span>
                    </div>
                    <p className="mt-1 text-[11px] leading-relaxed text-slate-400">{item.rationale}</p>
                    {item.files.length ? (
                      <ul className="mt-1.5 space-y-0.5">
                        {item.files.map((file) => (
                          <li key={file} className="flex items-center gap-1 truncate font-mono text-[10px] text-slate-500">
                            <FileCode2 className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                            {file}
                          </li>
                        ))}
                      </ul>
                    ) : null}
                  </div>
                </div>
              </li>
            );
          })}
        </ol>
      ) : (
        <p className="mt-4 rounded-lg border border-dashed border-white/10 p-5 text-center text-[12px] text-slate-400">
          No checklist items were generated.
        </p>
      )}
    </section>
  );
}
