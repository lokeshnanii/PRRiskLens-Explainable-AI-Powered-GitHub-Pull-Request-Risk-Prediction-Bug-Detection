"""Shared domain rules used by mining, training, inference and the API.

Keeping the feature schema, label heuristic and risk bands here guarantees the
training pipeline and the live predictor agree on the exact same semantics.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Any, Mapping

# Order is part of the API and model contract. Never reorder without retraining.
FEATURES: tuple[str, ...] = (
    "files_changed",
    "lines_added",
    "lines_deleted",
    "previous_author_commits",
    "prior_bug_fixes_in_touched_files",
    "commit_hour",
)
FEATURE_SCHEMA_VERSION = "1.0.0"
TIMEZONE_CONVENTION = "UTC"

DEFAULT_LOW_RISK_THRESHOLD = 35.0
DEFAULT_HIGH_RISK_THRESHOLD = 70.0

RISK_CATEGORIES = ("Low", "Medium", "High")

FEATURE_LABELS: dict[str, str] = {
    "files_changed": "Files changed",
    "lines_added": "Lines added",
    "lines_deleted": "Lines deleted",
    "previous_author_commits": "Author's prior commits",
    "prior_bug_fixes_in_touched_files": "Prior bug fixes in touched files",
    "commit_hour": "Commit hour (UTC)",
}

FEATURE_DESCRIPTIONS: dict[str, str] = {
    "files_changed": "Distinct files touched by the change.",
    "lines_added": "Lines added across all changed files.",
    "lines_deleted": "Lines removed across all changed files.",
    "previous_author_commits": (
        "Commits by the same author strictly before the analyzed change, "
        "using GitHub metadata available at analysis time."
    ),
    "prior_bug_fixes_in_touched_files": (
        "Heuristically detected bug-fix commits touching any of the changed "
        "files, strictly before the analyzed change and limited to the "
        "inspected history window."
    ),
    "commit_hour": "Authored hour in UTC (0-23).",
}

SCORE_INTERPRETATION = (
    "The 0-100 score is a normalized risk-ranking index derived from the "
    "classifier output. It is not a calibrated probability that this change "
    "contains a bug."
)


class FeatureValidationError(ValueError):
    """Raised when feature values violate the shared schema."""

    def __init__(self, errors: Mapping[str, str]):
        self.errors = dict(errors)
        super().__init__("; ".join(f"{key}: {value}" for key, value in self.errors.items()))


def validate_features(values: Mapping[str, Any], *, allow_extra: bool = False) -> dict[str, int]:
    """Validate and return features in canonical order.

    Counts must be true non-negative integers (booleans and floats are
    rejected), and ``commit_hour`` must be within 0-23.
    """

    if not isinstance(values, Mapping):
        raise FeatureValidationError({"__root__": "features must be an object"})

    errors: dict[str, str] = {}
    for name in FEATURES:
        if name not in values:
            errors[name] = "is required"
    for name in values:
        if name not in FEATURES and not allow_extra:
            errors[str(name)] = "is not a recognised feature"

    cleaned: dict[str, int] = {}
    for name in FEATURES:
        if name not in values:
            continue
        raw = values[name]
        if isinstance(raw, bool) or not isinstance(raw, int):
            errors[name] = "must be an integer"
            continue
        if raw < 0:
            errors[name] = "must be a non-negative integer"
            continue
        if name == "commit_hour" and raw > 23:
            errors[name] = "must be between 0 and 23"
            continue
        cleaned[name] = int(raw)

    if errors:
        raise FeatureValidationError(errors)
    return {name: cleaned[name] for name in FEATURES}


def feature_vector(values: Mapping[str, Any]) -> tuple[int, ...]:
    """Return validated feature values as a tuple in schema order."""

    cleaned = validate_features(values)
    return tuple(cleaned[name] for name in FEATURES)


def risk_category(
    score: float,
    low_threshold: float = DEFAULT_LOW_RISK_THRESHOLD,
    high_threshold: float = DEFAULT_HIGH_RISK_THRESHOLD,
) -> str:
    """Map a 0-100 score to Low/Medium/High using configurable bands."""

    value = float(score)
    if not math.isfinite(value):
        raise ValueError("Risk score must be finite")
    if not (0 <= value <= 100):
        raise ValueError("Risk score must be between 0 and 100")
    if value < low_threshold:
        return "Low"
    if value < high_threshold:
        return "Medium"
    return "High"


# ---------------------------------------------------------------------------
# Bug-fix message heuristic
# ---------------------------------------------------------------------------

_STRONG_BUG_RE = re.compile(
    r"\b(bugs?|bugfix(?:es)?|defects?|regressions?|crash(?:es|ed|ing)?|hotfix|"
    r"failure(?:s)?|incorrect(?:ly)?\s+behaviou?r|broken)\b",
    re.IGNORECASE,
)
_WEAK_BUG_RE = re.compile(r"\b(fix(?:es|ed|ing)?|patches?|patched)\b", re.IGNORECASE)
_NON_BUG_RE = re.compile(
    r"\b(typos?|docs?|documentation|readme|comments?|format(?:ting)?|lint(?:ing)?|"
    r"whitespace|style|changelog|version|release|bump|dependenc(?:y|ies)|"
    r"refactor(?:ing)?)\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class BugFixSignal:
    """Result of the message heuristic, including the evidence used."""

    is_candidate: bool
    terms: tuple[str, ...]
    excluded: bool
    reason: str


def detect_bug_fix(message: str | None) -> BugFixSignal:
    """Heuristically classify a commit message as a bug-fix candidate.

    Strong terms (bug, defect, regression, crash, ...) win outright. A weak
    term such as "fix" or "patch" is only accepted when no documentation/style
    marker is present ("fix typo" is therefore excluded). This is a heuristic,
    never proof that a commit fixed a bug.
    """

    text = (message or "").strip()
    if not text:
        return BugFixSignal(False, (), False, "empty commit message")

    strong = tuple(sorted({m.group(0).lower() for m in _STRONG_BUG_RE.finditer(text)}))
    weak = tuple(sorted({m.group(0).lower() for m in _WEAK_BUG_RE.finditer(text)}))
    non_bug = tuple(sorted({m.group(0).lower() for m in _NON_BUG_RE.finditer(text)}))

    if strong:
        terms = tuple(dict.fromkeys(strong + weak))
        return BugFixSignal(True, terms, False, f"bug-related terms: {', '.join(terms)}")

    if weak:
        if non_bug:
            return BugFixSignal(
                False,
                weak,
                True,
                f"weak fix term(s) {', '.join(weak)} alongside non-bug term(s) {', '.join(non_bug)}",
            )
        return BugFixSignal(True, weak, False, f"fix-related terms: {', '.join(weak)}")

    return BugFixSignal(False, (), False, "no bug-fix terms detected")
