import { useId, useMemo, useState } from "react";
import { AlertCircle, ArrowRight, Eraser, GitBranch, Link2, Loader2 } from "lucide-react";
import { parseGitHubUrl } from "../lib/githubUrl";

interface AnalysisFormProps {
  onSubmit: (url: string) => void;
  onClear: () => void;
  loading: boolean;
}

export default function AnalysisForm({ onSubmit, onClear, loading }: AnalysisFormProps) {
  const [value, setValue] = useState("");
  const [touched, setTouched] = useState(false);
  const inputId = useId();
  const helpId = useId();
  const errorId = useId();

  const parsed = useMemo(() => parseGitHubUrl(value), [value]);
  const error = touched && value.trim() !== "" && !parsed.ok ? parsed.error : null;

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setTouched(true);
    if (!parsed.ok) {
      document.getElementById(inputId)?.focus();
      return;
    }
    onSubmit(parsed.canonical);
  }

  function handleClear() {
    setValue("");
    setTouched(false);
    onClear();
    document.getElementById(inputId)?.focus();
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3" noValidate>
      <div className="flex items-center justify-between gap-3">
        <label htmlFor={inputId} className="section-label">
          GitHub pull request or commit
        </label>
        <span className="text-[11px] text-slate-500">github.com only</span>
      </div>

      <div className="flex flex-col gap-2 sm:flex-row">
        <div className="relative flex-1">
          <Link2
            className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500"
            aria-hidden="true"
          />
          <input
            id={inputId}
            name="github-url"
            type="url"
            inputMode="url"
            autoComplete="url"
            spellCheck={false}
            value={value}
            onChange={(event) => setValue(event.target.value)}
            onBlur={() => setTouched(true)}
            placeholder="https://github.com/owner/repository/pull/123"
            className={`field !pl-10 font-mono text-[13px] ${
              error ? "!border-rose-400/50 focus:!ring-rose-400/20" : ""
            }`}
            aria-invalid={Boolean(error)}
            aria-describedby={error ? `${helpId} ${errorId}` : helpId}
            disabled={loading}
          />
        </div>
        <div className="flex gap-2">
          <button type="submit" disabled={loading || !value.trim()} className="btn-primary flex-1 sm:flex-none">
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                Analyzing
              </>
            ) : (
              <>
                Analyze
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </>
            )}
          </button>
          <button
            type="button"
            onClick={handleClear}
            disabled={loading || (!value && !touched)}
            className="btn-ghost"
            aria-label="Clear the URL and results"
          >
            <Eraser className="h-4 w-4" aria-hidden="true" />
            <span className="hidden sm:inline">Clear</span>
          </button>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
        <p id={helpId} className="text-slate-500">
          Supported: <span className="font-mono text-slate-400">/pull/NUMBER</span> or{" "}
          <span className="font-mono text-slate-400">/commit/SHA</span>. Press Enter to submit.
        </p>
        {parsed.ok ? (
          <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/20 bg-emerald-400/[0.07] px-2.5 py-1 text-emerald-300">
            <GitBranch className="h-3 w-3" aria-hidden="true" />
            {parsed.preview}
          </span>
        ) : null}
      </div>

      {error ? (
        <p id={errorId} role="alert" className="flex items-start gap-2 text-[12px] text-rose-300">
          <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          {error}
        </p>
      ) : null}
    </form>
  );
}
