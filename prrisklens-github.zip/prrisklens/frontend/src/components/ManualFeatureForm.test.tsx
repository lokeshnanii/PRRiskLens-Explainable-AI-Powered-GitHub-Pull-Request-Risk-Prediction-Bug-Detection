import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import ManualFeatureForm from "./ManualFeatureForm";

function fill(values: Record<string, string>) {
  const labels: Record<string, RegExp> = {
    files_changed: /Files changed/i,
    lines_added: /Lines added/i,
    lines_deleted: /Lines deleted/i,
    previous_author_commits: /Author's prior commits/i,
    prior_bug_fixes_in_touched_files: /Prior bug fixes in touched files/i,
    commit_hour: /Commit hour/i,
  };
  for (const [name, value] of Object.entries(values)) {
    fireEvent.change(screen.getByLabelText(labels[name]), { target: { value } });
  }
}

describe("ManualFeatureForm", () => {
  it("requires all six features", () => {
    const onSubmit = vi.fn();
    render(<ManualFeatureForm onSubmit={onSubmit} loading={false} modelAvailable />);

    fireEvent.click(screen.getByRole("button", { name: /predict risk/i }));

    expect(onSubmit).not.toHaveBeenCalled();
    expect(screen.getAllByText("Required")).toHaveLength(6);
  });

  it("rejects a commit hour outside 0-23", () => {
    const onSubmit = vi.fn();
    render(<ManualFeatureForm onSubmit={onSubmit} loading={false} modelAvailable />);

    fill({
      files_changed: "2",
      lines_added: "20",
      lines_deleted: "5",
      previous_author_commits: "40",
      prior_bug_fixes_in_touched_files: "1",
      commit_hour: "24",
    });
    fireEvent.click(screen.getByRole("button", { name: /predict risk/i }));

    expect(onSubmit).not.toHaveBeenCalled();
    expect(screen.getByText(/Must be between 0 and 23/i)).toBeInTheDocument();
  });

  it("submits validated integer values", () => {
    const onSubmit = vi.fn();
    render(<ManualFeatureForm onSubmit={onSubmit} loading={false} modelAvailable />);

    fill({
      files_changed: "2",
      lines_added: "20",
      lines_deleted: "5",
      previous_author_commits: "40",
      prior_bug_fixes_in_touched_files: "1",
      commit_hour: "23",
    });
    fireEvent.click(screen.getByRole("button", { name: /predict risk/i }));

    expect(onSubmit).toHaveBeenCalledWith({
      files_changed: 2,
      lines_added: 20,
      lines_deleted: 5,
      previous_author_commits: 40,
      prior_bug_fixes_in_touched_files: 1,
      commit_hour: 23,
    });
  });

  it("warns honestly when no model is deployed", () => {
    render(<ManualFeatureForm onSubmit={vi.fn()} loading={false} modelAvailable={false} />);

    expect(screen.getByText(/reports no trained model/i)).toBeInTheDocument();
  });
});
