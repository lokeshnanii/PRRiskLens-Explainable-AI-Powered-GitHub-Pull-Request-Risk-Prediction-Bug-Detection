import { useId, useRef, useState } from "react";
import { AlertTriangle, Calculator, Loader2, RotateCcw } from "lucide-react";
import type { FeatureValues } from "../types/analysis";

interface ManualFeatureFormProps {
  onSubmit: (values: FeatureValues) => void;
  loading: boolean;
  modelAvailable: boolean;
}

const FIELDS: {
  name: keyof FeatureValues;
  label: string;
  description: string;
  hint: string;
  placeholder: string;
}[] = [
  {
    name: "files_changed",
    label: "Files changed",
    description: "Distinct files touched by the change.",
    hint: "≥ 0",
    placeholder: "3",
  },
  {
    name: "lines_added",
    label: "Lines added",
    description: "Lines added across all changed files.",
    hint: "≥ 0",
    placeholder: "120",
  },
  {
    name: "lines_deleted",
    label: "Lines deleted",
    description: "Lines removed across all changed files.",
    hint: "≥ 0",
    placeholder: "40",
  },
  {
    name: "previous_author_commits",
    label: "Author's prior commits",
    description: "Commits by the same author strictly before this change.",
    hint: "≥ 0",
    placeholder: "25",
  },
  {
    name: "prior_bug_fixes_in_touched_files",
    label: "Prior bug fixes in touched files",
    description: "Earlier heuristic bug-fix commits touching any changed file.",
    hint: "≥ 0",
    placeholder: "2",
  },
  {
    name: "commit_hour",
    label: "Commit hour (UTC)",
    description: "Authored hour of the earliest commit, in UTC.",
    hint: "0–23",
    placeholder: "14",
  },
];

const EMPTY: Record<keyof FeatureValues, string> = {
  files_changed: "",
  lines_added: "",
  lines_deleted: "",
  previous_author_commits: "",
  prior_bug_fixes_in_touched_files: "",
  commit_hour: "",
};

function validate(name: keyof FeatureValues, raw: string): string | null {
  const value = raw.trim();
  if (!value) return "Required";
  if (!/^\d+$/.test(value)) return "Enter a whole number";
  const number = Number(value);
  if (!Number.isSafeInteger(number)) return "Number is too large";
  if (name === "commit_hour" && number > 23) return "Must be between 0 and 23";
  return null;
}

export default function ManualFeatureForm({ onSubmit, loading, modelAvailable }: ManualFeatureFormProps) {
  const [values, setValues] = useState<Record<keyof FeatureValues, string>>(EMPTY);
  const [errors, setErrors] = useState<Partial<Record<keyof FeatureValues, string>>>({});
  const [touched, setTouched] = useState<Partial<Record<keyof FeatureValues, boolean>>>({});
  const prefix = useId();
  const formRef = useRef<HTMLFormElement>(null);

  function fieldId(name: string) {
    return `${prefix}-${name}`;
  }

  function update(name: keyof FeatureValues, raw: string) {
    setValues((current) => ({ ...current, [name]: raw }));
    if (touched[name]) {
      setErrors((current) => ({ ...current, [name]: validate(name, raw) ?? undefined }));
    }
  }

  function blur(name: keyof FeatureValues) {
    setTouched((current) => ({ ...current, [name]: true }));
    setErrors((current) => ({ ...current, [name]: validate(name, values[name]) ?? undefined }));
  }

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const nextErrors: Partial<Record<keyof FeatureValues, string>> = {};
    for (const field of FIELDS) {
      const message = validate(field.name, values[field.name]);
      if (message) nextErrors[field.name] = message;
    }
    setErrors(nextErrors);
    setTouched(Object.fromEntries(FIELDS.map((field) => [field.name, true])));

    const firstInvalid = FIELDS.find((field) => nextErrors[field.name]);
    if (firstInvalid) {
      document.getElementById(fieldId(firstInvalid.name))?.focus();
      return;
    }

    onSubmit({
      files_changed: Number(values.files_changed),
      lines_added: Number(values.lines_added),
      lines_deleted: Number(values.lines_deleted),
      previous_author_commits: Number(values.previous_author_commits),
      prior_bug_fixes_in_touched_files: Number(values.prior_bug_fixes_in_touched_files),
      commit_hour: Number(values.commit_hour),
    });
  }

  function reset() {
    setValues(EMPTY);
    setErrors({});
    setTouched({});
    formRef.current?.querySelector<HTMLInputElement>("input")?.focus();
  }

  return (
    <form ref={formRef} onSubmit={handleSubmit} className="space-y-4" noValidate>
      <div>
        <p className="text-[12px] leading-relaxed text-slate-400">
          Score a change without fetching GitHub. Enter the same six features the training pipeline
          uses; validation matches the backend schema exactly.
        </p>
        {!modelAvailable ? (
          <p className="mt-2 flex items-start gap-2 rounded-lg border border-amber-400/20 bg-amber-400/[0.05] p-2.5 text-[11px] leading-relaxed text-amber-100/80">
            <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
            The backend currently reports no trained model. Submitting will return an explicit
            model-unavailable response instead of a fabricated score.
          </p>
        ) : null}
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {FIELDS.map((field) => {
          const error = errors[field.name];
          const inputId = fieldId(field.name);
          const descriptionId = `${inputId}-description`;
          const errorId = `${inputId}-error`;
          return (
            <div key={field.name} className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
              <div className="flex items-baseline justify-between gap-2">
                <label htmlFor={inputId} className="text-[11px] font-semibold text-slate-200">
                  {field.label}
                </label>
                <span className="font-mono text-[9.5px] text-slate-500">{field.hint}</span>
              </div>
              <input
                id={inputId}
                name={field.name}
                type="number"
                inputMode="numeric"
                min={0}
                max={field.name === "commit_hour" ? 23 : undefined}
                step={1}
                value={values[field.name]}
                onChange={(event) => update(field.name, event.target.value)}
                onBlur={() => blur(field.name)}
                placeholder={field.placeholder}
                className={`field mt-2 !px-3 !py-2 font-mono text-[13px] ${
                  error ? "!border-rose-400/50" : ""
                }`}
                aria-invalid={Boolean(error)}
                aria-describedby={error ? `${descriptionId} ${errorId}` : descriptionId}
                disabled={loading}
              />
              <p id={descriptionId} className="mt-1.5 text-[10px] leading-relaxed text-slate-500">
                {field.description}
              </p>
              {error ? (
                <p id={errorId} className="mt-1 text-[10px] font-medium text-rose-300">
                  {error}
                </p>
              ) : null}
            </div>
          );
        })}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <button type="submit" disabled={loading} className="btn-primary">
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              Scoring
            </>
          ) : (
            <>
              <Calculator className="h-4 w-4" aria-hidden="true" />
              Predict risk
            </>
          )}
        </button>
        <button type="button" onClick={reset} disabled={loading} className="btn-ghost">
          <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
          Reset
        </button>
        <p className="text-[10.5px] leading-relaxed text-slate-500">
          Values are sent only to the PRRiskLens API. No GitHub request is made.
        </p>
      </div>
    </form>
  );
}
