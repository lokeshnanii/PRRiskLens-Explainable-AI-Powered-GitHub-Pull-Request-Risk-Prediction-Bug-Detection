"""GitHub token loading and authenticated-limit configuration tests."""

from __future__ import annotations

import pytest

from config import Settings, _parse_github_token, get_settings


@pytest.mark.parametrize(
    "value",
    [
        None,
        "",
        "   ",
        "your_github_personal_access_token",
        "YOUR_GITHUB_TOKEN",
        "your_token_here",
        "<your_token_here>",
        "replace_me",
        "changeme",
    ],
)
def test_placeholders_are_treated_as_unset(value):
    assert _parse_github_token(value) is None


@pytest.mark.parametrize(
    "value, expected",
    [
        ("ghp_example123", "ghp_example123"),
        ("  ghp_example123  ", "ghp_example123"),
        ('"ghp_example123"', "ghp_example123"),
        ("Bearer ghp_example123", "ghp_example123"),
        ("token ghp_example123", "ghp_example123"),
    ],
)
def test_token_whitespace_quotes_and_scheme_are_normalized(value, expected):
    assert _parse_github_token(value) == expected


def test_authenticated_settings_report_five_thousand_requests():
    settings = Settings(github_token="ghp_example123")
    assert settings.github_authenticated is True
    assert settings.github_auth_mode == "authenticated"
    assert settings.github_expected_hourly_limit == 5000


def test_unauthenticated_settings_report_sixty_requests():
    settings = Settings(github_token="your_github_personal_access_token")
    assert settings.github_authenticated is False
    assert settings.github_auth_mode == "unauthenticated"
    assert settings.github_expected_hourly_limit == 60


def test_settings_repr_never_contains_the_token():
    settings = Settings(github_token="ghp_super_secret_value")
    assert "ghp_super_secret_value" not in repr(settings)


def test_get_settings_reads_token_from_environment(monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "ghp_from_environment")
    settings = get_settings()
    assert settings.github_authenticated is True
    assert settings.github_token == "ghp_from_environment"


def test_get_settings_ignores_placeholder_environment_value(monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "your_github_personal_access_token")
    settings = get_settings()
    assert settings.github_authenticated is False
    assert settings.github_expected_hourly_limit == 60
