"""Deterministic, diff-based potential bug detection.

This module is deliberately independent from the machine-learning model: it
inspects the actual changed lines reported by GitHub and reports suspicious
patterns with real evidence. Matches are labelled ``potential`` or
``unverified``; nothing here claims a finding is a confirmed production bug.

The detectors are heuristics, not a vulnerability scanner. They suppress
obvious false positives (comments, placeholders, parameterised SQL) but still
require human review.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from typing import Iterable, Literal, Sequence

from gh import ChangedFile

Severity = Literal["high", "medium", "low", "info"]
SEVERITY_ORDER: dict[str, int] = {"high": 0, "medium": 1, "low": 2, "info": 3}

DOC_EXTENSIONS = {
    ".md",
    ".rst",
    ".txt",
    ".adoc",
    ".asciidoc",
    ".html",
    ".htm",
}
SOURCE_EXTENSIONS = {
    ".py",
    ".pyx",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".mjs",
    ".cjs",
    ".java",
    ".kt",
    ".go",
    ".rb",
    ".php",
    ".rs",
    ".c",
    ".h",
    ".cc",
    ".cpp",
    ".hpp",
    ".cs",
    ".swift",
    ".scala",
    ".sh",
    ".bash",
    ".sql",
}
TEST_PATH_RE = re.compile(
    r"(^|/)(tests?|__tests__|spec|specs)(/|$)"
    r"|(^|/)test_[^/]+\.py$"
    r"|_test\.py$"
    r"|\.(test|spec)\.[cm]?[jt]sx?$"
    r"|_test\.go$",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Patch parsing
# ---------------------------------------------------------------------------


@dataclass
class DiffLine:
    kind: Literal["add", "del", "context"]
    old_no: int | None
    new_no: int | None
    text: str


@dataclass
class Hunk:
    header: str
    old_start: int
    new_start: int
    lines: list[DiffLine] = field(default_factory=list)

    @property
    def added(self) -> list[DiffLine]:
        return [line for line in self.lines if line.kind == "add"]

    @property
    def removed(self) -> list[DiffLine]:
        return [line for line in self.lines if line.kind == "del"]


@dataclass
class ParsedPatch:
    hunks: list[Hunk]
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.error is None and bool(self.hunks)


_HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(.*)$")


def parse_patch(patch: str | None) -> ParsedPatch:
    """Parse a unified diff hunk body into line-numbered added/removed lines."""

    if patch is None or not patch.strip():
        return ParsedPatch([], "no patch content")
    hunks: list[Hunk] = []
    current: Hunk | None = None
    old_no = new_no = 0
    for raw_line in patch.splitlines():
        header = _HUNK_RE.match(raw_line)
        if header:
            old_no = int(header.group(1))
            new_no = int(header.group(3))
            current = Hunk(raw_line, old_no, new_no)
            hunks.append(current)
            continue
        if current is None:
            # diff --git / index / --- / +++ preamble before the first hunk
            continue
        if raw_line.startswith("\\"):
            continue  # "No newline at end of file"
        if raw_line.startswith("+"):
            current.lines.append(DiffLine("add", None, new_no, raw_line[1:]))
            new_no += 1
        elif raw_line.startswith("-"):
            current.lines.append(DiffLine("del", old_no, None, raw_line[1:]))
            old_no += 1
        elif raw_line.startswith(" ") or raw_line == "":
            current.lines.append(DiffLine("context", old_no, new_no, raw_line[1:]))
            old_no += 1
            new_no += 1
    if not hunks:
        return ParsedPatch([], "no parseable hunks")
    return ParsedPatch(hunks)


@dataclass
class FileContext:
    filename: str
    status: str
    patch: str | None
    hunks: list[Hunk] = field(default_factory=list)
    parse_error: str | None = None

    @property
    def extension(self) -> str:
        lowered = self.filename.lower()
        dot = lowered.rfind(".")
        return lowered[dot:] if dot >= 0 else ""

    @property
    def is_test(self) -> bool:
        return bool(TEST_PATH_RE.search(self.filename))

    @property
    def is_doc(self) -> bool:
        return self.extension in DOC_EXTENSIONS or self.filename.lower().endswith((".md", ".rst"))

    @property
    def is_source(self) -> bool:
        return self.extension in SOURCE_EXTENSIONS

    @property
    def added(self) -> list[DiffLine]:
        return [line for hunk in self.hunks for line in hunk.added]

    @property
    def removed(self) -> list[DiffLine]:
        return [line for hunk in self.hunks for line in hunk.removed]

    @property
    def added_text(self) -> str:
        return "\n".join(line.text for line in self.added)

    @property
    def removed_text(self) -> str:
        return "\n".join(line.text for line in self.removed)


# ---------------------------------------------------------------------------
# Findings
# ---------------------------------------------------------------------------


@dataclass
class Finding:
    detector: str
    detector_name: str
    title: str
    severity: Severity
    confidence: Literal["high", "medium", "low"]
    file: str
    line: int | None
    side: Literal["new", "old"]
    evidence: str
    explanation: str
    why_risky: str
    remediation: str
    detection_method: str
    verification: Literal["potential", "unverified", "tool_confirmed"] = "potential"
    line_end: int | None = None
    removed_evidence: str | None = None

    @property
    def id(self) -> str:
        digest = hashlib.sha256(
            f"{self.detector}|{self.file}|{self.side}|{self.line}|{self.evidence}".encode("utf-8")
        ).hexdigest()[:12]
        return f"{self.detector}-{digest}"

    def to_dict(self) -> dict[str, object]:
        return {
            "id": self.id,
            "detector": self.detector,
            "detector_name": self.detector_name,
            "title": self.title,
            "severity": self.severity,
            "confidence": self.confidence,
            "verification": self.verification,
            "file": self.file,
            "line": self.line,
            "line_end": self.line_end,
            "side": self.side,
            "evidence": self.evidence,
            "removed_evidence": self.removed_evidence,
            "explanation": self.explanation,
            "why_risky": self.why_risky,
            "remediation": self.remediation,
            "detection_method": self.detection_method,
        }


def _snippet(text: str, limit: int = 400) -> str:
    stripped = text.strip()
    return stripped[:limit] + ("…" if len(stripped) > limit else "")


def _is_comment_line(text: str) -> bool:
    stripped = text.strip()
    return stripped.startswith(("#", "//", "/*", "*", "--", ";;"))


def _make(
    *,
    ctx: FileContext,
    detector: str,
    detector_name: str,
    title: str,
    severity: Severity,
    confidence: Literal["high", "medium", "low"],
    line: DiffLine | None,
    side: Literal["new", "old"],
    evidence: str,
    explanation: str,
    why_risky: str,
    remediation: str,
    method: str,
    verification: Literal["potential", "unverified", "tool_confirmed"] = "potential",
    removed_evidence: str | None = None,
) -> Finding:
    number = None
    if line is not None:
        number = line.new_no if side == "new" else line.old_no
    return Finding(
        detector=detector,
        detector_name=detector_name,
        title=title,
        severity=severity,
        confidence=confidence,
        file=ctx.filename,
        line=number,
        side=side,
        evidence=_snippet(evidence),
        explanation=explanation,
        why_risky=why_risky,
        remediation=remediation,
        detection_method=method,
        verification=verification,
        removed_evidence=_snippet(removed_evidence) if removed_evidence else None,
    )


# ---------------------------------------------------------------------------
# Detectors
# ---------------------------------------------------------------------------

_SECRET_ASSIGN_RE = re.compile(
    r"(?i)\b(api[_-]?key|secret|password|passwd|pwd|token|access[_-]?key|private[_-]?key|auth[_-]?key)"
    r"\b\s*[:=]\s*([\"'])(?P<value>[^\"'\n]{6,})\2"
)
_SECRET_TOKEN_RE = re.compile(
    r"\b(AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|"
    r"sk-[A-Za-z0-9]{16,}|xox[baprs]-[A-Za-z0-9-]{10,})\b"
)
_PLACEHOLDER_RE = re.compile(
    r"(?i)(your[_-]|example|placeholder|changeme|change[_-]me|x{4,}|\*{3,}|dummy|fake|sample|"
    r"<[^>]+>|\$\{|{{|os\.getenv|process\.env|import\.meta\.env|getenv\()"
)


def detect_hardcoded_secrets(ctx: FileContext) -> list[Finding]:
    findings: list[Finding] = []
    for line in ctx.added:
        text = line.text
        if not text.strip() or _is_comment_line(text) or ctx.is_doc:
            continue
        match = _SECRET_ASSIGN_RE.search(text)
        token = _SECRET_TOKEN_RE.search(text)
        if not match and not token:
            continue
        if match and _PLACEHOLDER_RE.search(match.group("value")):
            continue
        severity: Severity = "medium" if ctx.is_test else "high"
        findings.append(
            _make(
                ctx=ctx,
                detector="hardcoded_secret",
                detector_name="Hard-coded credential",
                title="Possible hard-coded credential or API key",
                severity=severity,
                confidence="medium",
                line=line,
                side="new",
                evidence=text,
                explanation=(
                    "An added line assigns a literal value to a credential-like name"
                    + (" inside a test file." if ctx.is_test else ".")
                ),
                why_risky=(
                    "Literals committed to a repository can leak through history, forks and "
                    "build logs, and are difficult to rotate safely."
                ),
                remediation=(
                    "Remove the literal, rotate the credential, and load it from an environment "
                    "variable or secret manager. Never expose it to the browser bundle."
                ),
                method="regular expression over added lines with placeholder filtering",
            )
        )
    return findings


_SQL_KEYWORD_RE = re.compile(
    r"(?i)\b(select|insert\s+into|update\s+\w+\s+set|delete\s+from|truncate|drop\s+table|exec(?:ute)?)\b"
)
_EXEC_CALL_RE = re.compile(r"(?i)\b(execute|executemany|raw|query|exec|read_sql|extra)\s*\(")
_SQL_ASSIGN_RE = re.compile(r"(?i)\b(q|query|sql|statement|stmt|cmd)\s*=\s*")


def _sql_interpolation(text: str) -> str | None:
    if not _SQL_KEYWORD_RE.search(text):
        return None
    if re.search(r"\bf[\"']", text):
        return "an f-string"
    if ".format(" in text:
        return "str.format"
    if "${" in text:
        return "a template literal"
    if re.search(r"[\"']\s*%\s*[\(\w]", text):
        return "the % operator"
    if re.search(r"[\"']\s*\+", text) or re.search(r"\+\s*[\"']", text):
        return "string concatenation"
    return None


def detect_sql_injection(ctx: FileContext) -> list[Finding]:
    if ctx.is_test:
        return []
    findings: list[Finding] = []
    for hunk in ctx.hunks:
        hunk_text = "\n".join(item.text for item in hunk.lines)
        executed_in_hunk = bool(_EXEC_CALL_RE.search(hunk_text))
        for line in hunk.added:
            text = line.text
            if not text.strip() or _is_comment_line(text):
                continue
            interpolation = _sql_interpolation(text)
            if not interpolation:
                continue
            executed = bool(_EXEC_CALL_RE.search(text)) or executed_in_hunk
            if not executed and not _SQL_ASSIGN_RE.search(text):
                # e.g. logging an f-string that merely mentions SELECT
                continue
            if executed:
                title = "SQL query built with " + interpolation
                severity: Severity = "high"
                confidence: Literal["high", "medium", "low"] = "medium"
                explanation = (
                    "An added line builds a SQL statement with "
                    f"{interpolation} in a query-execution context."
                )
            else:
                title = "SQL statement assembled with " + interpolation
                severity = "medium"
                confidence = "low"
                explanation = (
                    "An added line assembles a SQL statement with "
                    f"{interpolation}; no execution call was found in this hunk."
                )
            findings.append(
                _make(
                    ctx=ctx,
                    detector="sql_injection",
                    detector_name="Potential SQL injection",
                    title=title,
                    severity=severity,
                    confidence=confidence,
                    line=line,
                    side="new",
                    evidence=text,
                    explanation=explanation,
                    why_risky=(
                        "If any interpolated value is influenced by a user or external system, an "
                        "attacker may alter the query to read or modify unintended data."
                    ),
                    remediation=(
                        "Use the database driver's parameterised queries (placeholders plus a "
                        "parameter tuple) or an ORM query builder; never concatenate untrusted input."
                    ),
                    method="regular expression plus SQL-keyword and parameterisation heuristic",
                )
            )
    return findings


_SHELL_CALL_RE = re.compile(
    r"(?i)\b(os\.system|os\.popen|subprocess\.(?:run|Popen|call|check_output|check_call))\s*\("
)


def _has_interpolation(text: str) -> bool:
    return bool(
        re.search(r"\bf[\"']", text)
        or ".format(" in text
        or "${" in text
        or re.search(r"[\"']\s*\+", text)
        or re.search(r"%\s*[\(\w]", text)
    )


def detect_command_injection(ctx: FileContext) -> list[Finding]:
    if ctx.is_test:
        return []
    findings: list[Finding] = []
    for line in ctx.added:
        text = line.text
        if not text.strip() or _is_comment_line(text):
            continue
        shell_true = "shell=True" in text.replace(" ", "")
        shell_call = _SHELL_CALL_RE.search(text)
        if not shell_true and not shell_call:
            continue
        dynamic = _has_interpolation(text)
        if shell_true or dynamic:
            title = "Shell command execution with dynamic input"
            severity: Severity = "high"
            confidence: Literal["high", "medium", "low"] = "medium" if dynamic else "low"
            explanation = (
                "An added line runs a process through a shell"
                + (" with interpolated content." if dynamic else " (shell=True).")
            )
        else:
            title = "Shell command execution added"
            severity = "medium"
            confidence = "low"
            explanation = "An added line invokes an operating-system shell or command runner."
        findings.append(
            _make(
                ctx=ctx,
                detector="command_injection",
                detector_name="Potential command injection",
                title=title,
                severity=severity,
                confidence=confidence,
                line=line,
                side="new",
                evidence=text,
                explanation=explanation,
                why_risky=(
                    "Shell commands that include external values can execute unintended "
                    "commands; shell=True also widens the attack surface of otherwise safe calls."
                ),
                remediation=(
                    "Pass an argument list without a shell, validate/allow-list inputs, and use "
                    "subprocess APIs with explicit timeouts."
                ),
                method="regular expression over added lines",
            )
        )
    return findings


_VALIDATION_PATTERNS = [
    re.compile(r"\braise\s+(?:ValueError|TypeError|AssertionError|Invalid\w*)\b"),
    re.compile(r"\bif\s+not\s+[^:]+:"),
    re.compile(r"\bisinstance\s*\("),
    re.compile(r"\b(?:abort|HTTPException)\s*\(\s*(?:status_code\s*=\s*)?4\d\d\b"),
    re.compile(r"\.validate\s*\("),
    re.compile(r"\bassert\s+[^=]"),
    re.compile(r"\bre\.(?:match|fullmatch|search)\s*\("),
    re.compile(r"\bif\s+[^:]*\blen\s*\([^)]*\)\s*[<>=]"),
    re.compile(r"\bthrow\s+new\s+\w*Error\s*\("),
    re.compile(r"\breturn\s+[^;]*\b4\d\d\b"),
]


def _validation_hits(lines: Iterable[DiffLine]) -> list[DiffLine]:
    hits = []
    for line in lines:
        if _is_comment_line(line.text):
            continue
        if any(pattern.search(line.text) for pattern in _VALIDATION_PATTERNS):
            hits.append(line)
    return hits


def detect_removed_validation(ctx: FileContext) -> list[Finding]:
    if ctx.is_test or ctx.is_doc or not ctx.is_source:
        return []
    removed_hits = _validation_hits(ctx.removed)
    added_hits = _validation_hits(ctx.added)
    if not removed_hits or len(removed_hits) <= len(added_hits):
        return []
    findings: list[Finding] = []
    for line in removed_hits[:2]:
        findings.append(
            _make(
                ctx=ctx,
                detector="removed_validation",
                detector_name="Removed input validation",
                title="Validation or guard likely removed",
                severity="medium",
                confidence="low",
                line=line,
                side="old",
                evidence=line.text,
                explanation=(
                    f"This change removes {len(removed_hits)} validation-like line(s) while "
                    f"adding {len(added_hits)}. The removed line above was the most direct signal."
                ),
                why_risky=(
                    "Removing checks can allow malformed, missing, or hostile input to reach code "
                    "that assumed the value had already been validated."
                ),
                remediation=(
                    "Confirm the removed check is enforced by a caller or schema. If not, restore "
                    "validation and add a regression test for the invalid input."
                ),
                method="heuristic comparison of validation-like added vs removed lines",
                verification="unverified",
            )
        )
    return findings


_BROAD_EXCEPT_RE = re.compile(
    r"^\s*except\s*(?:Exception|BaseException)?\s*(?:as\s+\w+)?\s*:\s*(?:#.*)?$"
)
_JS_CATCH_RE = re.compile(r"\bcatch\s*(?:\([^)]*\))?\s*\{")
_SUPPRESSIONS = {"pass", "continue", "return", "return none", "{}", "}"}


def detect_broad_exception(ctx: FileContext) -> list[Finding]:
    findings: list[Finding] = []
    for hunk in ctx.hunks:
        for index, line in enumerate(hunk.lines):
            if line.kind != "add":
                continue
            text = line.text
            if _is_comment_line(text):
                continue
            is_broad = bool(_BROAD_EXCEPT_RE.match(text))
            is_js = bool(_JS_CATCH_RE.search(text)) and ctx.extension in {".js", ".jsx", ".ts", ".tsx"}
            if not (is_broad or is_js):
                continue
            following = [
                item.text.strip().lower()
                for item in hunk.lines[index + 1 : index + 4]
                if item.text.strip()
            ]
            suppressed = bool(following and following[0].rstrip(":") in _SUPPRESSIONS)
            if _JS_CATCH_RE.search(text) and text.rstrip().endswith("{}"):
                suppressed = True
            title = "Overly broad exception handling" if is_broad else "Empty or broad catch block"
            severity: Severity = "medium"
            findings.append(
                _make(
                    ctx=ctx,
                    detector="broad_exception",
                    detector_name="Broad exception handling",
                    title=title,
                    severity=severity,
                    confidence="high" if is_broad else "medium",
                    line=line,
                    side="new",
                    evidence=text,
                    explanation=(
                        "An added block catches a broad class of errors"
                        + (" and appears to suppress them." if suppressed else ".")
                    ),
                    why_risky=(
                        "Broad handlers can hide programming errors, mask partial failures, and "
                        "turn a loud failure into silent data corruption."
                    ),
                    remediation=(
                        "Catch the narrowest exception types, log with context, and re-raise or "
                        "return an explicit error instead of swallowing it."
                    ),
                    method="syntax-oriented regular expression with body inspection",
                )
            )
    return findings


_CMP_RE = re.compile(
    r"(?P<left>[A-Za-z_][\w\.\[\]\"'()]*)\s*(?P<op><=|>=|==|!=|<|>)\s*"
    r"(?P<right>[A-Za-z0-9_\.\[\]\"'()]+)"
)


def _normalise_cmp(value: str) -> str:
    return re.sub(r"\s+", "", value)


def detect_boundary_change(ctx: FileContext) -> list[Finding]:
    if ctx.is_test or ctx.is_doc:
        return []
    findings: list[Finding] = []
    for hunk in ctx.hunks:
        added_pairs = [(line, _CMP_RE.search(line.text)) for line in hunk.added]
        for removed in hunk.removed:
            old_match = _CMP_RE.search(removed.text)
            if not old_match:
                continue
            for added, new_match in added_pairs:
                if not new_match:
                    continue
                if old_match.group("op") == new_match.group("op"):
                    continue
                if _normalise_cmp(old_match.group("left")) != _normalise_cmp(new_match.group("left")):
                    continue
                if _normalise_cmp(old_match.group("right")) != _normalise_cmp(new_match.group("right")):
                    continue
                findings.append(
                    _make(
                        ctx=ctx,
                        detector="boundary_change",
                        detector_name="Boundary condition change",
                        title=f"Comparison operator changed from {old_match.group('op')} to {new_match.group('op')}",
                        severity="medium",
                        confidence="medium",
                        line=added,
                        side="new",
                        evidence=added.text,
                        explanation=(
                            "An added comparison uses the same operands as a removed comparison "
                            f"but changes the operator from {old_match.group('op')} to "
                            f"{new_match.group('op')}."
                        ),
                        why_risky=(
                            "Inclusive/exclusive boundary changes frequently introduce off-by-one "
                            "errors in ranges, pagination, permissions, and loops."
                        ),
                        remediation=(
                            "Confirm the intended boundary and add tests for the value exactly at "
                            "the boundary on both sides."
                        ),
                        method="paired added/removed comparison heuristic",
                    )
                )
                break
    return findings


_UNSAFE_DESERIALIZATION_RE = re.compile(
    r"\b(pickle\.loads?|cPickle\.loads?|dill\.loads?|marshal\.loads?|yaml\.(?:unsafe_)?load|torch\.load)\s*\("
)


def detect_unsafe_deserialization(ctx: FileContext) -> list[Finding]:
    findings: list[Finding] = []
    for line in ctx.added:
        text = line.text
        if not text.strip() or _is_comment_line(text):
            continue
        match = _UNSAFE_DESERIALIZATION_RE.search(text)
        if not match:
            continue
        call = match.group(1)
        if call.startswith("yaml") and "SafeLoader" in text:
            continue
        severity: Severity = "medium" if call.startswith("torch") else "high"
        findings.append(
            _make(
                ctx=ctx,
                detector="unsafe_deserialization",
                detector_name="Unsafe deserialization",
                title=f"Potentially unsafe {call} call",
                severity=severity,
                confidence="medium",
                line=line,
                side="new",
                evidence=text,
                explanation=(
                    "An added line deserialises data using a format that can execute code or "
                    "instantiate arbitrary objects when the input is untrusted."
                ),
                why_risky=(
                    "Deserialising untrusted payloads with these APIs can lead to remote code "
                    "execution or object-injection attacks."
                ),
                remediation=(
                    "Prefer safe formats such as JSON or yaml.safe_load, and validate the input "
                    "and its provenance before deserialising."
                ),
                method="regular expression over added lines",
            )
        )
    return findings


_NONE_GUARD_RE = re.compile(
    r"(?i)(?:if|elif|while|assert)\s+(?P<expr>[^:;]+?)\s+(?:is\s+not|is|==|!=)\s+None\b"
)
_JS_NULL_GUARD_RE = re.compile(
    r"(?i)if\s*\(\s*(?P<expr>[\w\.\[\]\"']+)\s*(?:===|!==|==|!=)\s*null"
)


def detect_missing_none_handling(ctx: FileContext) -> list[Finding]:
    if ctx.is_test or ctx.is_doc:
        return []
    findings: list[Finding] = []
    for line in ctx.removed:
        if _is_comment_line(line.text):
            continue
        match = _NONE_GUARD_RE.search(line.text) or _JS_NULL_GUARD_RE.search(line.text)
        if not match:
            continue
        expr = match.group("expr").strip()
        if not expr:
            continue
        added_text = ctx.added_text
        still_guarded = (
            f"{expr} is None" in added_text
            or f"{expr} is not None" in added_text
            or f"{expr} === null" in added_text
            or f"{expr} !== null" in added_text
            or "?." in added_text
            or "??" in added_text
        )
        if still_guarded:
            continue
        findings.append(
            _make(
                ctx=ctx,
                detector="missing_none_handling",
                detector_name="Optional value handling",
                title="None/null guard appears to be removed",
                severity="medium",
                confidence="low",
                line=line,
                side="old",
                evidence=line.text,
                explanation=(
                    "A guard that checked an optional value before use was removed and no "
                    "equivalent guard or optional chaining was added in this file."
                ),
                why_risky=(
                    "If the value can still be absent, downstream attribute access or arithmetic "
                    "may raise or produce silently wrong results."
                ),
                remediation=(
                    "Keep an explicit check, use optional chaining/default values, or prove at the "
                    "call site that the value is always present."
                ),
                method="removed-guard heuristic with added-guard search",
                verification="unverified",
            )
        )
        if len(findings) >= 2:
            break
    return findings


_TEMP_MKTEMP_RE = re.compile(r"\btempfile\.mktemp\s*\(")
_CHMOD_777_RE = re.compile(r"\bchmod\s*\([^)]*0o?777\b")
_OPEN_ASSIGN_RE = re.compile(r"^\s*[A-Za-z_]\w*\s*=\s*open\s*\(")


def detect_risky_resources(ctx: FileContext) -> list[Finding]:
    findings: list[Finding] = []
    for line in ctx.added:
        text = line.text
        if not text.strip() or _is_comment_line(text):
            continue
        if _TEMP_MKTEMP_RE.search(text):
            findings.append(
                _make(
                    ctx=ctx,
                    detector="risky_resource",
                    detector_name="Risky resource handling",
                    title="Insecure temporary file creation",
                    severity="medium",
                    confidence="high",
                    line=line,
                    side="new",
                    evidence=text,
                    explanation="An added line creates a temporary file name with tempfile.mktemp.",
                    why_risky=(
                        "tempfile.mktemp returns a name without creating the file atomically, which "
                        "creates a race condition and possible symlink attack."
                    ),
                    remediation="Use tempfile.mkstemp/NamedTemporaryFile or a TemporaryDirectory.",
                    method="regular expression over added lines",
                )
            )
        elif _CHMOD_777_RE.search(text):
            findings.append(
                _make(
                    ctx=ctx,
                    detector="risky_resource",
                    detector_name="Risky resource handling",
                    title="World-writable permissions",
                    severity="medium",
                    confidence="high",
                    line=line,
                    side="new",
                    evidence=text,
                    explanation="An added line grants world-writable permissions (0777).",
                    why_risky="World-writable files or directories can be modified by other local users.",
                    remediation="Use the narrowest permissions required and prefer a restrictive umask.",
                    method="regular expression over added lines",
                )
            )
        elif _OPEN_ASSIGN_RE.match(text) and "with " not in text:
            findings.append(
                _make(
                    ctx=ctx,
                    detector="risky_resource",
                    detector_name="Risky resource handling",
                    title="File opened without a context manager",
                    severity="low",
                    confidence="low",
                    line=line,
                    side="new",
                    evidence=text,
                    explanation="An added line assigns an open file without a with-block.",
                    why_risky=(
                        "If an exception occurs before close() the descriptor may leak, and cleanup "
                        "is easy to forget on later edits."
                    ),
                    remediation="Use a with statement (or try/finally) so the file is always closed.",
                    method="regular expression over added lines",
                    verification="unverified",
                )
            )
    return findings


_REMOVED_TEST_CONTENT_RE = re.compile(
    r"^\s*(?:def\s+test_|assert\b|self\.assert\w+|assert_\w+|expect\s*\(|it\s*\(|test\s*\()"
)
_SKIPPED_TEST_RE = re.compile(
    r"(?i)(pytest\.mark\.skip|unittest\.skip|@skip\b|it\.skip\s*\(|test\.skip\s*\(|xit\s*\(|\.only\s*\()"
)


def detect_weakened_tests(ctx: FileContext) -> list[Finding]:
    if not ctx.is_test:
        return []
    findings: list[Finding] = []
    if ctx.status == "removed":
        first = next((line for line in ctx.removed if line.text.strip()), None)
        return [
            _make(
                ctx=ctx,
                detector="weakened_tests",
                detector_name="Deleted or weakened tests",
                title="Test file deleted",
                severity="high",
                confidence="high",
                line=first,
                side="old",
                evidence=first.text if first else ctx.filename,
                explanation="This change deletes an entire test file.",
                why_risky="Removing tests removes the safety net for the affected behavior.",
                remediation=(
                    "Confirm the tests are genuinely obsolete; otherwise restore them or replace "
                    "them with equivalent coverage before merging."
                ),
                method="file status inspection",
                verification="potential",
            )
        ]

    removed_hits = [
        line
        for line in ctx.removed
        if _REMOVED_TEST_CONTENT_RE.search(line.text) and not _is_comment_line(line.text)
    ]
    added_hits = [
        line
        for line in ctx.added
        if _REMOVED_TEST_CONTENT_RE.search(line.text) and not _is_comment_line(line.text)
    ]
    if removed_hits and len(removed_hits) > len(added_hits):
        for line in removed_hits[:2]:
            findings.append(
                _make(
                    ctx=ctx,
                    detector="weakened_tests",
                    detector_name="Deleted or weakened tests",
                    title="Test coverage or assertions removed",
                    severity="medium",
                    confidence="medium",
                    line=line,
                    side="old",
                    evidence=line.text,
                    explanation=(
                        f"This test change removes {len(removed_hits)} test/assertion line(s) "
                        f"while adding {len(added_hits)}."
                    ),
                    why_risky=(
                        "Deleting assertions or tests can make a failing behavior look healthy and "
                        "remove regression protection."
                    ),
                    remediation=(
                        "Restore or replace the removed coverage, or document why the behavior no "
                        "longer needs a test."
                    ),
                    method="added/removed test-line comparison",
                )
            )
    for line in ctx.added:
        if _SKIPPED_TEST_RE.search(line.text) and not _is_comment_line(line.text):
            findings.append(
                _make(
                    ctx=ctx,
                    detector="weakened_tests",
                    detector_name="Deleted or weakened tests",
                    title="Test skipped or narrowed",
                    severity="medium",
                    confidence="medium",
                    line=line,
                    side="new",
                    evidence=line.text,
                    explanation="An added line skips or focuses tests.",
                    why_risky=(
                        "Skipped tests silently reduce coverage; focused tests can hide failures in "
                        "the rest of the suite."
                    ),
                    remediation="Remove the skip/only marker or link it to a tracked issue with an expiry.",
                    method="regular expression over added lines",
                )
            )
    return findings


_AUTH_CHECK_RE = re.compile(
    r"(?i)(@login_required|@requires?_auth\w*|@permission_required|@role_required|"
    r"@jwt_required|@auth\w*\.\w+|is_authenticated|check_permission|authorize\s*\(|"
    r"require_role|ensure_authenticated|require_login|csrf\.protect)"
)


def detect_auth_regression(ctx: FileContext) -> list[Finding]:
    if ctx.is_test or ctx.is_doc or not ctx.is_source or ctx.status == "removed":
        return []
    added_text = ctx.added_text
    if _AUTH_CHECK_RE.search(added_text):
        return []
    findings: list[Finding] = []
    for line in ctx.removed:
        if _is_comment_line(line.text):
            continue
        if not _AUTH_CHECK_RE.search(line.text):
            continue
        findings.append(
            _make(
                ctx=ctx,
                detector="auth_regression",
                detector_name="Authorization check regression",
                title="Authorization check appears to be removed",
                severity="high",
                confidence="medium",
                line=line,
                side="old",
                evidence=line.text,
                explanation=(
                    "A removed line contains an authentication/authorization check and no "
                    "replacement check was added in this file."
                ),
                why_risky=(
                    "If the protection is not enforced elsewhere, an endpoint or operation may "
                    "become accessible to unauthorized callers."
                ),
                remediation=(
                    "Verify the check is enforced by middleware or a parent handler; otherwise "
                    "restore it and add a negative authorization test."
                ),
                method="removed auth-pattern heuristic with file-level replacement search",
                verification="potential",
            )
        )
        if len(findings) >= 2:
            break
    return findings


_DEF_RE = re.compile(r"^\s*(?:async\s+)?def\s+(?P<name>[A-Za-z_]\w*)\s*\((?P<params>.*)\)")
_CLASS_RE = re.compile(r"^\s*class\s+(?P<name>[A-Za-z_]\w*)\b")
_ROUTE_RE = re.compile(
    r"^\s*@(?:app|router|bp|blueprint|api)\.(?:route|get|post|put|patch|delete|websocket)\s*\("
)


def detect_breaking_api_change(ctx: FileContext) -> list[Finding]:
    if ctx.is_test or ctx.is_doc or not ctx.is_source or ctx.status == "removed":
        return []
    findings: list[Finding] = []
    added_defs: dict[str, DiffLine] = {}
    for line in ctx.added:
        match = _DEF_RE.match(line.text)
        if match and not match.group("name").startswith("_"):
            added_defs[match.group("name")] = line
    added_classes = {
        match.group("name")
        for line in ctx.added
        if (match := _CLASS_RE.match(line.text)) and not match.group("name").startswith("_")
    }

    for line in ctx.removed:
        if _is_comment_line(line.text):
            continue
        def_match = _DEF_RE.match(line.text)
        if def_match:
            name = def_match.group("name")
            if name.startswith("_"):
                continue
            if name not in added_defs:
                findings.append(
                    _make(
                        ctx=ctx,
                        detector="breaking_api_change",
                        detector_name="Potentially breaking API change",
                        title=f"Public function '{name}' removed",
                        severity="medium",
                        confidence="low",
                        line=line,
                        side="old",
                        evidence=line.text,
                        explanation=(
                            f"The public function {name} was removed and no definition with that "
                            "name was added in this file."
                        ),
                        why_risky=(
                            "Callers outside the changed diff may still import or call it, causing "
                            "AttributeError/ImportError or runtime failures after deployment."
                        ),
                        remediation=(
                            "Search the codebase and public API for callers, keep a deprecated shim "
                            "if needed, and update documentation/changelog."
                        ),
                        method="definition comparison across the changed file",
                        verification="unverified",
                    )
                )
                continue
            new_line = added_defs[name]
            old_params = _normalise_cmp(def_match.group("params"))
            new_match = _DEF_RE.match(new_line.text)
            if new_match and old_params != _normalise_cmp(new_match.group("params")):
                findings.append(
                    _make(
                        ctx=ctx,
                        detector="breaking_api_change",
                        detector_name="Potentially breaking API change",
                        title=f"Signature of public function '{name}' changed",
                        severity="medium",
                        confidence="low",
                        line=new_line,
                        side="new",
                        evidence=new_line.text,
                        explanation=f"The parameters of the public function {name} changed.",
                        why_risky=(
                            "Existing positional/keyword callers may fail or silently pass values "
                            "to the wrong parameter."
                        ),
                        remediation=(
                            "Check call sites, prefer backward-compatible parameters, and update "
                            "tests and documentation."
                        ),
                        method="definition comparison across the changed file",
                        verification="unverified",
                        removed_evidence=line.text,
                    )
                )
                continue
        class_match = _CLASS_RE.match(line.text)
        if class_match:
            name = class_match.group("name")
            if name.startswith("_") or name in added_classes:
                continue
            findings.append(
                _make(
                    ctx=ctx,
                    detector="breaking_api_change",
                    detector_name="Potentially breaking API change",
                    title=f"Public class '{name}' removed",
                    severity="medium",
                    confidence="low",
                    line=line,
                    side="old",
                    evidence=line.text,
                    explanation=f"The public class {name} was removed from this module.",
                    why_risky="External imports or subclasses may break after deployment.",
                    remediation="Check importers, provide a compatibility alias, or document the breaking change.",
                    method="class definition comparison",
                    verification="unverified",
                )
            )

    if not any(_ROUTE_RE.match(line.text) for line in ctx.added):
        for line in ctx.removed[:50]:
            if _ROUTE_RE.match(line.text):
                findings.append(
                    _make(
                        ctx=ctx,
                        detector="breaking_api_change",
                        detector_name="Potentially breaking API change",
                        title="HTTP route removed without replacement",
                        severity="medium",
                        confidence="low",
                        line=line,
                        side="old",
                        evidence=line.text,
                        explanation="An HTTP route decorator was removed and none was added in this file.",
                        why_risky="Clients calling the old endpoint will receive 404/405 responses.",
                        remediation="Confirm the endpoint is intentionally retired and update clients/docs.",
                        method="route decorator comparison",
                        verification="unverified",
                    )
                )

    unique: dict[str, Finding] = {}
    for finding in findings:
        unique.setdefault(finding.id, finding)
    return list(unique.values())


DETECTORS = [
    ("hardcoded_secret", "Hard-coded credentials", detect_hardcoded_secrets),
    ("sql_injection", "Potential SQL injection", detect_sql_injection),
    ("command_injection", "Potential command injection", detect_command_injection),
    ("removed_validation", "Removed input validation", detect_removed_validation),
    ("broad_exception", "Broad exception handling", detect_broad_exception),
    ("boundary_change", "Boundary condition changes", detect_boundary_change),
    ("unsafe_deserialization", "Unsafe deserialization", detect_unsafe_deserialization),
    ("missing_none_handling", "Optional value handling", detect_missing_none_handling),
    ("risky_resource", "Risky resource handling", detect_risky_resources),
    ("weakened_tests", "Deleted or weakened tests", detect_weakened_tests),
    ("auth_regression", "Authorization regressions", detect_auth_regression),
    ("breaking_api_change", "Breaking API changes", detect_breaking_api_change),
]


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------


@dataclass
class CodeAnalysis:
    status: Literal["complete", "partial", "unavailable"]
    findings: list[Finding]
    summary: dict[str, object]
    coverage: dict[str, object]
    message: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "status": self.status,
            "findings": [finding.to_dict() for finding in self.findings],
            "summary": self.summary,
            "coverage": self.coverage,
            "message": self.message,
        }


def analyze_file(ctx: FileContext) -> list[Finding]:
    if ctx.is_doc or not ctx.is_source:
        return []
    findings: list[Finding] = []
    for _, _, detector in DETECTORS:
        try:
            findings.extend(detector(ctx))
        except Exception:  # a broken detector must not break the whole analysis
            continue
    unique: dict[str, Finding] = {}
    for finding in findings:
        unique.setdefault(finding.id, finding)
    ordered = sorted(
        unique.values(),
        key=lambda item: (SEVERITY_ORDER.get(item.severity, 9), item.file, item.line or 0),
    )
    return ordered[:20]


def analyze_changes(
    files: Sequence[ChangedFile], *, max_findings: int = 150
) -> CodeAnalysis:
    contexts: list[FileContext] = []
    parse_errors: list[dict[str, str]] = []
    no_patch: list[str] = []
    analyzed = 0

    for changed in files:
        ctx = FileContext(changed.filename, changed.status, changed.patch)
        if changed.patch is None:
            no_patch.append(changed.filename)
            contexts.append(ctx)
            continue
        parsed = parse_patch(changed.patch)
        ctx.hunks = parsed.hunks
        ctx.parse_error = parsed.error
        if not parsed.ok:
            parse_errors.append({"file": changed.filename, "reason": parsed.error or "unknown"})
        else:
            analyzed += 1
        contexts.append(ctx)

    findings: list[Finding] = []
    for ctx in contexts:
        if ctx.parse_error or not ctx.hunks:
            continue
        findings.extend(analyze_file(ctx))

    truncated = False
    if len(findings) > max_findings:
        findings = findings[:max_findings]
        truncated = True

    by_severity: dict[str, int] = {"high": 0, "medium": 0, "low": 0, "info": 0}
    by_detector: dict[str, int] = {}
    for finding in findings:
        by_severity[finding.severity] = by_severity.get(finding.severity, 0) + 1
        by_detector[finding.detector] = by_detector.get(finding.detector, 0) + 1

    files_with_findings = len({finding.file for finding in findings})
    if not files:
        status: Literal["complete", "partial", "unavailable"] = "unavailable"
        message = "No changed files were returned by GitHub, so code analysis could not run."
    elif analyzed == 0:
        status = "unavailable"
        message = (
            "No textual patches were available, so line-level code analysis could not run. "
            "Binary or oversized files are not analysed."
        )
    elif analyzed < len(files):
        status = "partial"
        message = (
            f"{len(files) - analyzed} file(s) had no usable patch; findings cover only the "
            "files with textual diffs."
        )
    else:
        status = "complete"
        message = None

    coverage = {
        "files_received": len(files),
        "files_with_patch": analyzed,
        "files_without_patch": no_patch,
        "parse_errors": parse_errors,
        "files_analyzed": analyzed,
        "files_with_findings": files_with_findings,
        "findings_truncated": truncated,
        "verification_note": (
            "Detections are deterministic pattern matches labelled potential/unverified. "
            "No external scanner or test execution was used, so none are tool-confirmed."
        ),
    }
    summary = {
        "total": len(findings),
        "by_severity": by_severity,
        "by_detector": by_detector,
        "files_with_findings": files_with_findings,
        "detectors_run": len(DETECTORS),
    }
    return CodeAnalysis(status=status, findings=findings, summary=summary, coverage=coverage, message=message)
