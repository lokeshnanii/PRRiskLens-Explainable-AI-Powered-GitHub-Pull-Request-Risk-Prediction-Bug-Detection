import { Github, ShieldAlert } from "lucide-react";
import { DISCLAIMER } from "../lib/format";
import { API_BASE } from "../services/api";

export default function Footer() {
  const repoUrl = import.meta.env.VITE_GITHUB_REPO_URL;

  return (
    <footer className="mt-20 border-t border-white/[0.06] bg-ink-950/60">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 lg:grid-cols-[1.5fr_1fr] lg:px-8">
        <div>
          <div className="flex items-center gap-2 text-sm font-semibold text-white">
            <ShieldAlert className="h-4 w-4 text-amber-300" aria-hidden="true" />
            Important limitations
          </div>
          <p className="mt-3 max-w-3xl text-[12px] leading-relaxed text-slate-400">{DISCLAIMER}</p>
          <p className="mt-4 text-[11px] leading-relaxed text-slate-500">
            The model is trained only on repositories selected for mining. SZZ labels and the bug-fix
            message heuristic are approximations; neither identifies every defect. Code findings are
            deterministic pattern matches that require human verification. Pull request code is never
            executed.
          </p>
        </div>
        <div className="space-y-3 text-[12px] text-slate-400 lg:text-right">
          <p>
            Backend: <span className="font-mono text-slate-300">{API_BASE}</span>
          </p>
          <p>
            Stack: React · TypeScript · Vite · Tailwind · FastAPI · XGBoost · SHAP · PyDriller
          </p>
          <div className="flex flex-wrap gap-3 lg:justify-end">
            <a href="#analyze" className="transition hover:text-white">
              Analyze
            </a>
            <a href="#methodology" className="transition hover:text-white">
              Methodology
            </a>
            <a href={`${API_BASE}/docs`} target="_blank" rel="noreferrer noopener" className="transition hover:text-white">
              API docs
            </a>
            {repoUrl ? (
              <a
                href={repoUrl}
                target="_blank"
                rel="noreferrer noopener"
                className="inline-flex items-center gap-1.5 transition hover:text-white"
              >
                <Github className="h-3.5 w-3.5" aria-hidden="true" />
                Source
              </a>
            ) : null}
          </div>
          <p className="pt-2 text-[11px] text-slate-600">
            Not affiliated with GitHub. No GitHub token ever reaches this browser application.
          </p>
        </div>
      </div>
    </footer>
  );
}
