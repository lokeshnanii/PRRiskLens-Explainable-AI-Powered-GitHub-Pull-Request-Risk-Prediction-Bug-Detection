"""Runtime configuration loaded from environment variables.

Secrets live here and never leave the backend process. The frontend only ever
talks to this API; it never receives the GitHub token.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlsplit

from dotenv import load_dotenv

from core import (
    DEFAULT_HIGH_RISK_THRESHOLD,
    DEFAULT_LOW_RISK_THRESHOLD,
)

BACKEND_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BACKEND_DIR.parent

# Load a repository-root .env in local development. Existing process
# environment variables always win over values from the file.
load_dotenv(PROJECT_ROOT / ".env", override=False)


# Literal values shipped in documentation/examples that must never be sent to
# GitHub as if they were real credentials.
_TOKEN_PLACEHOLDERS = frozenset(
    {
        "your_github_personal_access_token",
        "your_github_token",
        "your_token_here",
        "insert_token_here",
        "paste_token_here",
        "replace_me",
        "changeme",
        "token_here",
        "github_token",
        "xxx",
    }
)


def _env_str(name: str, default: str | None = None) -> str | None:
    value = os.getenv(name)
    if value is None:
        return default
    value = value.strip()
    return value or default


def _parse_github_token(raw: str | None) -> str | None:
    """Normalize a token and reject documented placeholders.

    A placeholder is treated exactly like an unset token so the backend falls
    back to unauthenticated requests instead of sending a bogus credential.
    The value itself is never logged.
    """

    if raw is None:
        return None
    token = raw.strip().strip("\"'<>").strip()
    if not token:
        return None
    lowered = token.lower()
    if lowered in _TOKEN_PLACEHOLDERS or lowered.startswith(("your_github", "your_token")):
        return None
    if lowered.startswith("bearer "):
        token = token[7:].strip()
    elif lowered.startswith("token "):
        token = token[6:].strip()
    return token or None


def _env_int(name: str, default: int) -> int:
    raw = _env_str(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer, got {raw!r}") from exc


def _env_float(name: str, default: float) -> float:
    raw = _env_str(name)
    if raw is None:
        return default
    try:
        return float(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be a number, got {raw!r}") from exc


def _env_origins(raw: str | None) -> tuple[str, ...]:
    if not raw:
        return (
            "http://localhost:5173",
            "http://127.0.0.1:5173",
            "http://localhost:4173",
            "http://127.0.0.1:4173",
        )
    origins = tuple(item.strip().rstrip("/") for item in raw.split(",") if item.strip())
    for origin in origins:
        parts = urlsplit(origin)
        if parts.scheme not in {"http", "https"} or not parts.hostname:
            raise RuntimeError(f"Invalid CORS origin in FRONTEND_ORIGINS: {origin!r}")
    return origins


def _validate_api_url(url: str) -> str:
    parts = urlsplit(url)
    if parts.scheme != "https" or not parts.hostname or parts.username or parts.password:
        raise RuntimeError("GITHUB_API_URL must be an https:// URL without credentials")
    return url.rstrip("/")


@dataclass(frozen=True)
class Settings:
    """Immutable application settings.

    Tests construct this directly; production builds it with ``get_settings``.
    """

    github_token: str | None = field(default=None, repr=False)
    github_api_url: str = "https://api.github.com"
    frontend_origins: tuple[str, ...] = (
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:4173",
        "http://127.0.0.1:4173",
    )
    request_timeout_seconds: float = 15.0
    models_dir: Path = BACKEND_DIR / "models"
    data_dir: Path = BACKEND_DIR / "data"
    # Limits protect the API and GitHub quota.
    max_files: int = 300
    max_patch_chars: int = 40_000
    max_history_files: int = 5
    history_commits_per_file: int = 30
    max_commit_history: int = 2_000
    rate_limit_per_minute: int = 60
    max_request_bytes: int = 64 * 1024
    low_risk_threshold: float = DEFAULT_LOW_RISK_THRESHOLD
    high_risk_threshold: float = DEFAULT_HIGH_RISK_THRESHOLD

    def __post_init__(self) -> None:
        object.__setattr__(self, "github_token", _parse_github_token(self.github_token))
        object.__setattr__(self, "github_api_url", _validate_api_url(self.github_api_url))
        if not (0 <= self.low_risk_threshold < self.high_risk_threshold <= 100):
            raise ValueError("Risk thresholds must satisfy 0 <= low < high <= 100")
        if self.request_timeout_seconds <= 0:
            raise ValueError("request_timeout_seconds must be positive")

    @property
    def risk_thresholds(self) -> dict[str, float]:
        return {
            "low_max": self.low_risk_threshold,
            "high_min": self.high_risk_threshold,
        }

    @property
    def github_authenticated(self) -> bool:
        return bool(self.github_token)

    @property
    def github_auth_mode(self) -> str:
        return "authenticated" if self.github_authenticated else "unauthenticated"

    @property
    def github_expected_hourly_limit(self) -> int:
        # GitHub's documented primary limits for REST requests per hour.
        return 5000 if self.github_authenticated else 60


def get_settings() -> Settings:
    """Build settings from the environment on each call (cheap and testable)."""

    origins = _env_origins(_env_str("FRONTEND_ORIGINS"))
    settings = Settings(
        github_token=_parse_github_token(_env_str("GITHUB_TOKEN")),
        github_api_url=_env_str("GITHUB_API_URL", "https://api.github.com") or "https://api.github.com",
        frontend_origins=origins,
        request_timeout_seconds=_env_float("GITHUB_TIMEOUT_SECONDS", 15.0),
        models_dir=Path(_env_str("MODELS_DIR", str(BACKEND_DIR / "models")) or "models").resolve(),
        data_dir=Path(_env_str("DATA_DIR", str(BACKEND_DIR / "data")) or "data").resolve(),
        max_files=_env_int("MAX_FILES", 300),
        max_patch_chars=_env_int("MAX_PATCH_CHARS", 40_000),
        max_history_files=_env_int("MAX_HISTORY_FILES", 5),
        history_commits_per_file=_env_int("HISTORY_COMMITS_PER_FILE", 30),
        max_commit_history=_env_int("MAX_COMMIT_HISTORY", 2_000),
        rate_limit_per_minute=_env_int("RATE_LIMIT_PER_MINUTE", 60),
        max_request_bytes=_env_int("MAX_REQUEST_BYTES", 64 * 1024),
        low_risk_threshold=_env_float("LOW_RISK_THRESHOLD", DEFAULT_LOW_RISK_THRESHOLD),
        high_risk_threshold=_env_float("HIGH_RISK_THRESHOLD", DEFAULT_HIGH_RISK_THRESHOLD),
    )
    return settings
