"""Shared helpers for the offline mining pipeline."""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

_SLUG_RE = re.compile(r"^([A-Za-z0-9](?:[A-Za-z0-9-]{0,38}))/([A-Za-z0-9._-]{1,100})$")


def split_slug(slug: str) -> tuple[str, str]:
    match = _SLUG_RE.match(slug)
    if not match or match.group(2).endswith(".git"):
        raise ValueError(f"Invalid repository slug: {slug!r} (expected OWNER/REPO)")
    return match.group(1), match.group(2)


def repo_path_for(slug: str, clone_dir: Path) -> Path:
    owner, repo = split_slug(slug)
    return clone_dir / f"{owner}__{repo}"


def ensure_clone(slug: str, clone_dir: Path, *, timeout: int = 1800) -> Path:
    """Clone a public repository once and reuse the local copy afterwards.

    Cloned repositories live under the ignored data directory. A failed clone
    leaves no partially extracted directory behind.
    """

    target = repo_path_for(slug, clone_dir)
    if (target / ".git").exists():
        return target
    if target.exists():
        raise RuntimeError(
            f"{target} exists but is not a git clone. Move it aside or delete it, then retry."
        )

    clone_dir.mkdir(parents=True, exist_ok=True)
    temp_dir = Path(tempfile.mkdtemp(prefix="prrisklens-clone-", dir=str(clone_dir)))
    try:
        completed = subprocess.run(
            ["git", "clone", "--quiet", f"https://github.com/{slug}.git", str(temp_dir / "repo")],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        if completed.returncode != 0:
            stderr = (completed.stderr or "").strip()
            raise RuntimeError(f"git clone failed for {slug}: {stderr[:500]}")
        os.replace(temp_dir / "repo", target)
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
    return target
