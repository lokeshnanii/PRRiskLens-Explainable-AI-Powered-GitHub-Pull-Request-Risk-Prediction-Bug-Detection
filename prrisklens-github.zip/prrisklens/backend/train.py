"""Train and evaluate the six-feature bug-risk models.

Two candidates are trained on a chronological 70/30 split:
1. Logistic regression with balanced class weights (interpretable baseline).
2. XGBoost with ``scale_pos_weight`` derived from the training split only.

All preprocessing is fit on the training partition. The test partition is only
touched for the final evaluation. ``results.json`` is written from that real
evaluation; no metric is invented.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import tempfile
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    confusion_matrix,
    roc_auc_score,
)
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

from config import BACKEND_DIR
from core import (
    DEFAULT_HIGH_RISK_THRESHOLD,
    DEFAULT_LOW_RISK_THRESHOLD,
    FEATURES,
    FEATURE_SCHEMA_VERSION,
)


class InsufficientDataError(RuntimeError):
    def __init__(self, diagnostics: list[str], summary: dict[str, Any]):
        self.diagnostics = diagnostics
        self.summary = summary
        super().__init__("; ".join(diagnostics))


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(
        "w", delete=False, dir=str(path.parent), suffix=".tmp", encoding="utf-8"
    )
    try:
        json.dump(payload, handle, indent=2, allow_nan=False)
        handle.flush()
        os.fsync(handle.fileno())
    finally:
        handle.close()
    os.replace(handle.name, path)


def _dump_artifact(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(delete=False, dir=str(path.parent), suffix=".tmp")
    handle.close()
    try:
        joblib.dump(payload, handle.name)
        os.replace(handle.name, path)
    finally:
        if os.path.exists(handle.name):
            os.unlink(handle.name)


@dataclass
class SplitResult:
    train: pd.DataFrame
    test: pd.DataFrame
    note: str
    train_range: dict[str, str | None]
    test_range: dict[str, str | None]


def _range(frame: pd.DataFrame) -> dict[str, str | None]:
    if frame.empty:
        return {"start": None, "end": None}
    return {"start": str(frame["author_date"].min()), "end": str(frame["author_date"].max())}


def chronological_split(frame: pd.DataFrame, train_fraction: float = 0.7) -> SplitResult:
    """Split oldest rows into train and newest rows into test.

    Equal-timestamp commits are kept together and assigned to the training side
    of the boundary so no two commits with identical timestamps straddle the
    split. If that leaves no test rows, a deterministic index split is used and
    the fallback is documented in the returned note.
    """

    if not (0 < train_fraction < 1):
        raise ValueError("train_fraction must be between 0 and 1")
    if len(frame) < 2:
        raise ValueError("At least two rows are required for a chronological split")
    ordered = frame.copy()
    ordered["_ts"] = pd.to_datetime(ordered["author_date"], utc=True)
    ordered = ordered.sort_values(["_ts", "sha"], kind="mergesort").reset_index(drop=True)
    split_index = max(1, min(len(ordered) - 1, int(len(ordered) * train_fraction)))
    boundary_ts = ordered.loc[split_index, "_ts"]
    test_start = split_index
    while test_start < len(ordered) and ordered.loc[test_start, "_ts"] == boundary_ts:
        test_start += 1
    note = (
        "Oldest rows form the training set; equal-timestamp commits at the boundary "
        "are kept in training so the test set is strictly later."
    )
    if test_start >= len(ordered):
        test_start = split_index
        note = (
            "All rows at the split boundary share one timestamp; fell back to a "
            "deterministic index split. Treat results with extra caution."
        )
    train = ordered.iloc[:test_start].drop(columns=["_ts"]).reset_index(drop=True)
    test = ordered.iloc[test_start:].drop(columns=["_ts"]).reset_index(drop=True)
    return SplitResult(
        train=train,
        test=test,
        note=note,
        train_range=_range(train),
        test_range=_range(test),
    )


def evaluate_predictions(
    y_true: np.ndarray,
    scores: np.ndarray,
    *,
    threshold: float = 0.5,
    top_fraction: float = 0.1,
) -> dict[str, Any]:
    """Compute the required metrics; undefined values are null with notes."""

    y = np.asarray(y_true, dtype=int)
    s = np.asarray(scores, dtype=float)
    if y.shape != s.shape:
        raise ValueError("y_true and scores must have the same shape")
    if not np.all(np.isfinite(s)):
        raise ValueError("Model produced non-finite scores")
    positives = int(y.sum())
    n = int(len(y))
    notes: list[str] = []

    roc_auc = None
    if positives and positives < n:
        roc_auc = float(roc_auc_score(y, s))
    else:
        notes.append("ROC-AUC is undefined because the test set does not contain both classes.")
    pr_auc = float(average_precision_score(y, s)) if positives else None
    if pr_auc is None:
        notes.append("PR-AUC (average precision) is undefined without positive test examples.")

    predictions = (s >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, predictions, labels=[0, 1]).ravel()
    tn, fp, fn, tp = int(tn), int(fp), int(fn), int(tp)
    precision = tp / (tp + fp) if (tp + fp) > 0 else None
    recall = tp / (tp + fn) if (tp + fn) > 0 else None
    if precision is None:
        notes.append("Precision is undefined because no test commit exceeded the threshold.")
    if recall is None:
        notes.append("Recall is undefined because the test set has no positive examples.")
    if precision is not None and recall is not None:
        f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
    else:
        f1 = None

    top_count = max(1, int(math.ceil(top_fraction * n))) if n else 0
    if positives and top_count:
        order = np.argsort(-s, kind="mergesort")[:top_count]
        captured = int(y[order].sum())
        capture = captured / positives
    else:
        captured = 0 if positives == 0 else None
        capture = None
    if capture is None:
        notes.append("Top-10% bug capture is undefined without positive test examples.")

    return {
        "test_size": n,
        "positive_test_examples": positives,
        "positive_label_rate": round(positives / n, 6) if n else None,
        "roc_auc": round(roc_auc, 6) if roc_auc is not None else None,
        "pr_auc_average_precision": round(pr_auc, 6) if pr_auc is not None else None,
        "threshold": threshold,
        "confusion_matrix": {"tn": tn, "fp": fp, "fn": fn, "tp": tp},
        "precision": round(precision, 6) if precision is not None else None,
        "recall": round(recall, 6) if recall is not None else None,
        "f1": round(f1, 6) if f1 is not None else None,
        "top_10_percent_capture": {
            "fraction": top_fraction,
            "ranked_count": top_count,
            "positives_captured": captured,
            "positives_total": positives,
            "capture_rate": round(capture, 6) if capture is not None else None,
        },
        "notes": notes,
    }


def _dataset_summary(frame: pd.DataFrame, split: SplitResult) -> dict[str, Any]:
    positives = int(frame["label"].sum())
    def block(part: pd.DataFrame) -> dict[str, Any]:
        part_positives = int(part["label"].sum()) if len(part) else 0
        return {
            "rows": int(len(part)),
            "positives": part_positives,
            "positive_rate": round(part_positives / len(part), 6) if len(part) else None,
        }
    return {
        "rows": int(len(frame)),
        "positives": positives,
        "positive_rate": round(positives / len(frame), 6) if len(frame) else None,
        "repositories": sorted(frame["repo"].unique().tolist()) if len(frame) else [],
        "date_range": _range(frame),
        "train": {**block(split.train), **split.train_range},
        "test": {**block(split.test), **split.test_range},
    }


def _validate_training_frame(frame: pd.DataFrame) -> None:
    missing = [column for column in (*FEATURES, "label", "author_date", "sha") if column not in frame]
    if missing:
        raise ValueError(f"Training data is missing columns: {', '.join(missing)}")
    if len(frame) == 0:
        raise ValueError("Training data is empty")
    for column in FEATURES:
        values = pd.to_numeric(frame[column], errors="coerce")
        if values.isna().any():
            raise ValueError(f"Feature {column} contains missing or non-numeric values")
        if (values < 0).any():
            raise ValueError(f"Feature {column} contains negative values")
        if column == "commit_hour" and (values > 23).any():
            raise ValueError("commit_hour contains values outside 0-23")
    labels = pd.to_numeric(frame["label"], errors="coerce")
    if labels.isna().any() or not labels.isin([0, 1]).all():
        raise ValueError("Labels must be binary integers")


def _package_versions() -> dict[str, str]:
    import sklearn
    import xgboost

    return {
        "python": sys.version.split()[0],
        "pandas": pd.__version__,
        "numpy": np.__version__,
        "scikit-learn": sklearn.__version__,
        "xgboost": xgboost.__version__,
        "joblib": joblib.__version__,
    }


def train_and_evaluate(
    frame: pd.DataFrame,
    *,
    models_dir: Path,
    results_path: Path,
    train_fraction: float = 0.7,
    threshold: float = 0.5,
    min_rows: int = 100,
    min_train_positives: int = 10,
    min_test_positives: int = 3,
    random_state: int = 42,
) -> dict[str, Any]:
    _validate_training_frame(frame)
    split = chronological_split(frame, train_fraction)
    summary = _dataset_summary(frame, split)
    train_positives = int(split.train["label"].sum())
    test_positives = int(split.test["label"].sum())

    diagnostics: list[str] = []
    if len(frame) < min_rows:
        diagnostics.append(f"Only {len(frame)} rows; at least {min_rows} are required.")
    if train_positives < min_train_positives:
        diagnostics.append(
            f"Training partition has {train_positives} positive labels; at least "
            f"{min_train_positives} are required."
        )
    if test_positives < min_test_positives:
        diagnostics.append(
            f"Test partition has {test_positives} positive labels; at least "
            f"{min_test_positives} are required."
        )
    if diagnostics:
        _write_json(
            results_path,
            {
                "status": "insufficient_data",
                "generated_at": _iso(_utc_now()),
                "diagnostics": diagnostics,
                "dataset": summary,
                "config": {
                    "train_fraction": train_fraction,
                    "threshold": threshold,
                    "min_rows": min_rows,
                    "min_train_positives": min_train_positives,
                    "min_test_positives": min_test_positives,
                },
                "note": "Training stopped deliberately; no model artifact or metrics were produced.",
            },
        )
        raise InsufficientDataError(diagnostics, summary)

    feature_columns = list(FEATURES)
    X_train = split.train[feature_columns].to_numpy(dtype=float)
    y_train = split.train["label"].to_numpy(dtype=int)
    X_test = split.test[feature_columns].to_numpy(dtype=float)
    y_test = split.test["label"].to_numpy(dtype=int)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    logistic = LogisticRegression(
        max_iter=3000,
        class_weight="balanced",
        solver="liblinear",
        random_state=random_state,
    )
    logistic.fit(X_train_scaled, y_train)

    negatives = int((y_train == 0).sum())
    positives = int((y_train == 1).sum())
    scale_pos_weight = negatives / positives if positives else 1.0
    xgboost = XGBClassifier(
        n_estimators=300,
        max_depth=3,
        learning_rate=0.08,
        subsample=0.9,
        colsample_bytree=0.9,
        scale_pos_weight=scale_pos_weight,
        eval_metric="logloss",
        tree_method="hist",
        random_state=random_state,
        n_jobs=2,
    )
    xgboost.fit(X_train, y_train, verbose=False)

    logistic_scores = logistic.predict_proba(X_test_scaled)[:, 1]
    xgboost_scores = xgboost.predict_proba(X_test)[:, 1]
    metrics = {
        "logistic_regression": evaluate_predictions(y_test, logistic_scores, threshold=threshold),
        "xgboost": evaluate_predictions(y_test, xgboost_scores, threshold=threshold),
    }

    xgb_auc = metrics["xgboost"]["roc_auc"]
    lr_auc = metrics["logistic_regression"]["roc_auc"]
    if xgb_auc is not None and lr_auc is not None:
        if xgb_auc >= lr_auc:
            selected = "xgboost"
            selection_reason = (
                f"XGBoost had the higher test ROC-AUC ({xgb_auc:.4f} vs {lr_auc:.4f}); it is "
                "the main candidate. This single test-set comparison is not independent model selection."
            )
        else:
            selected = "logistic_regression"
            selection_reason = (
                f"Logistic regression had the higher test ROC-AUC ({lr_auc:.4f} vs {xgb_auc:.4f}); "
                "it was selected despite XGBoost being the primary candidate."
            )
    else:
        selected = "xgboost" if xgb_auc is not None else "logistic_regression"
        selection_reason = (
            "ROC-AUC was undefined for at least one candidate; selected the model with a "
            "defined ROC-AUC, preferring XGBoost on ties."
        )

    trained_at = _utc_now()
    run_id = uuid.uuid4().hex[:8]
    xgb_version = f"xgboost-{trained_at:%Y%m%dT%H%M%SZ}-{run_id}"
    lr_version = f"logistic-{trained_at:%Y%m%dT%H%M%SZ}-{run_id}"
    common = {
        "features": feature_columns,
        "feature_schema_version": FEATURE_SCHEMA_VERSION,
        "trained_at": _iso(trained_at),
        "threshold": threshold,
        "risk_thresholds": {
            "low_max": DEFAULT_LOW_RISK_THRESHOLD,
            "high_min": DEFAULT_HIGH_RISK_THRESHOLD,
        },
        "training_rows": int(len(X_train)),
    }
    xgb_bundle = {
        **common,
        "kind": "xgboost",
        "model_version": xgb_version,
        "model": xgboost,
        "explanation": {"method": "shap.TreeExplainer"},
        "scale_pos_weight": scale_pos_weight,
    }
    lr_bundle = {
        **common,
        "kind": "logistic",
        "model_version": lr_version,
        "scaler": scaler,
        "model": logistic,
        "explanation": {"method": "shap.LinearExplainer"},
    }

    models_dir.mkdir(parents=True, exist_ok=True)
    _dump_artifact(models_dir / "xgboost_model.joblib", xgb_bundle)
    _dump_artifact(models_dir / "logreg_model.joblib", lr_bundle)
    selected_bundle = xgb_bundle if selected == "xgboost" else lr_bundle
    _dump_artifact(models_dir / "model.joblib", selected_bundle)

    rng = np.random.RandomState(random_state)
    sample_size = min(200, len(X_train))
    background = X_train[rng.choice(len(X_train), size=sample_size, replace=False)]
    joblib.dump(background, models_dir / "background.joblib")

    training_config = {
        "split": "chronological 70/30 with equal-timestamp groups kept together",
        "train_fraction": train_fraction,
        "threshold": threshold,
        "random_state": random_state,
        "min_rows": min_rows,
        "min_train_positives": min_train_positives,
        "min_test_positives": min_test_positives,
        "logistic_regression": {
            "solver": "liblinear",
            "class_weight": "balanced",
            "max_iter": 3000,
            "scaling": "StandardScaler fit on training rows only",
        },
        "xgboost": {
            "n_estimators": 300,
            "max_depth": 3,
            "learning_rate": 0.08,
            "subsample": 0.9,
            "colsample_bytree": 0.9,
            "scale_pos_weight": round(scale_pos_weight, 6),
            "tree_method": "hist",
        },
        "background_rows": int(sample_size),
    }
    metadata = {
        "model_version": selected_bundle["model_version"],
        "model_type": selected,
        "trained_at": _iso(trained_at),
        "features": feature_columns,
        "feature_schema_version": FEATURE_SCHEMA_VERSION,
        "threshold": threshold,
        "risk_thresholds": common["risk_thresholds"],
        "training_config": training_config,
        "dataset": summary,
        "metrics": metrics[selected],
        "all_metrics": metrics,
        "selection_reason": selection_reason,
        "explanation": {
            "available": True,
            "method": "shap",
            "background_rows": int(sample_size),
        },
        "versions": _package_versions(),
    }
    _write_json(models_dir / "metadata.json", metadata)

    results = {
        "status": "ok",
        "generated_at": _iso(_utc_now()),
        "run_id": run_id,
        "dataset": summary,
        "split": {
            "method": "chronological",
            "train_fraction": train_fraction,
            "note": split.note,
        },
        "models": {
            "logistic_regression": {
                "model_version": lr_version,
                "metrics": metrics["logistic_regression"],
            },
            "xgboost": {
                "model_version": xgb_version,
                "metrics": metrics["xgboost"],
            },
        },
        "selected_model": selected,
        "selection_reason": selection_reason,
        "config": training_config,
        "feature_schema_version": FEATURE_SCHEMA_VERSION,
        "versions": metadata["versions"],
        "notes": [
            "Metrics come from a single chronological hold-out set; they are estimates, not guarantees.",
            "SZZ labels are approximate and can contain false positives and negatives.",
            "Selecting a model by test ROC-AUC is a decision rule, not an unbiased performance estimate.",
            "Top-10% capture is the share of positive test commits inside the highest-scored 10%.",
            "The risk score is a ranking index derived from the classifier output, not a calibrated probability.",
        ],
    }
    _write_json(results_path, results)
    return results


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Train PRRiskLens bug-risk models")
    parser.add_argument(
        "--data", default=str(BACKEND_DIR / "data" / "processed" / "features.csv")
    )
    parser.add_argument("--models-dir", default=str(BACKEND_DIR / "models"))
    parser.add_argument("--results", default=None)
    parser.add_argument("--train-fraction", type=float, default=0.7)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--min-rows", type=int, default=100)
    parser.add_argument("--min-train-positives", type=int, default=10)
    parser.add_argument("--min-test-positives", type=int, default=3)
    parser.add_argument("--random-state", type=int, default=42)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    data_path = Path(args.data)
    models_dir = Path(args.models_dir)
    results_path = Path(args.results) if args.results else models_dir / "results.json"
    if not data_path.exists():
        print(
            f"Training data not found: {data_path}\n"
            "Run mine.py, szz.py and dataset.py first (see README).",
            file=sys.stderr,
        )
        return 1
    frame = pd.read_csv(data_path)
    try:
        results = train_and_evaluate(
            frame,
            models_dir=models_dir,
            results_path=results_path,
            train_fraction=args.train_fraction,
            threshold=args.threshold,
            min_rows=args.min_rows,
            min_train_positives=args.min_train_positives,
            min_test_positives=args.min_test_positives,
            random_state=args.random_state,
        )
    except InsufficientDataError as exc:
        print("Training stopped: insufficient data.", file=sys.stderr)
        for item in exc.diagnostics:
            print(f" - {item}", file=sys.stderr)
        print(f"Diagnostics written to {results_path}", file=sys.stderr)
        return 2
    except ValueError as exc:
        print(f"Training data validation failed: {exc}", file=sys.stderr)
        return 1

    selected = results["selected_model"]
    metrics = results["models"][selected]["metrics"]
    print(f"Selected model: {selected} ({results['selection_reason']})")
    print(
        "Test metrics: "
        f"ROC-AUC={metrics['roc_auc']} PR-AUC={metrics['pr_auc_average_precision']} "
        f"top10={metrics['top_10_percent_capture']['capture_rate']} "
        f"test_size={metrics['test_size']}"
    )
    print(f"Model artifacts: {models_dir}")
    print(f"Results: {results_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
