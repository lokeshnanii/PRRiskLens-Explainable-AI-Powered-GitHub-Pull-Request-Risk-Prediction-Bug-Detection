"""Historical commit mining with PyDriller.

Raw output is intentionally separate from training data: this script only
collects commit metadata and file-level statistics. SZZ labelling and feature
engineering happen in later stages.

Usage examples:
    python mine.py --pilot
    python mine.py --repos pallets/flask psf/requests --limit 800
    python mine.py --repos pallets/click --limit 2000 --since 2022-01-01

Cloned repositories are stored under the ignored data/repos directory and are
never committed.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from config import BACKEND_DIR
from core import detect_bug_fix
from repo_utils import ensure_clone, repo_path_for, split_slug

DEFAULT_REPOS = ("pallets/flask", "psf/requests", "pallets/click", "pallets/jinja")
COLUMNS = [
    "repo",
    "sha",
    "author_name",
    "author_email",
    "author_date",
    "committer_date",
    "message",
    "parents",
    "files_changed",
    "lines_added",
    "lines_deleted",
    "file_paths",
    "is_merge",
    "bug_fix_candidate",
    "error",
]


def _iso(value: Any) -> str:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    return ""


def _parse_since(raw: str | None) -> datetime | None:
    if not raw:
        return None
    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("--since must be an ISO date, e.g. 2020-01-01") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _load_existing(path: Path) -> tuple[set[tuple[str, str]], dict[str, int]]:
    seen: set[tuple[str, str]] = set()
    counts: dict[str, int] = {}
    if not path.exists():
        return seen, counts
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            repo = row.get("repo")
            sha = row.get("sha")
            if not repo or not sha:
                continue
            key = (repo, sha)
            if key not in seen:
                seen.add(key)
                counts[repo] = counts.get(repo, 0) + 1
    return seen, counts


def _write_error(path: Path, repo: str, sha: str | None, stage: str, message: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    exists = path.exists() and path.stat().st_size > 0
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        if not exists:
            writer.writerow(["repo", "sha", "stage", "error", "occurred_at"])
        writer.writerow([repo, sha or "", stage, message[:1000], _iso(datetime.now(timezone.utc))])


def _commit_row(repo: str, commit: Any) -> dict[str, str] | None:
    if commit.merge:
        return None
    try:
        files = list(commit.modified_files)
    except Exception as exc:  # PyDriller can fail on unusual diffs
        raise RuntimeError(f"could not read modified files: {exc}") from exc
    paths = sorted({mod.new_path or mod.old_path for mod in files if (mod.new_path or mod.old_path)})
    if not paths:
        return None
    lines_added = sum(int(mod.added_lines or 0) for mod in files)
    lines_deleted = sum(int(mod.deleted_lines or 0) for mod in files)
    message = commit.msg or ""
    author_email = (commit.author.email or "").strip().lower() if commit.author else ""
    author_name = (commit.author.name or "").strip() if commit.author else ""
    row = {
        "repo": repo,
        "sha": commit.hash,
        "author_name": author_name,
        "author_email": author_email,
        "author_date": _iso(commit.author_date),
        "committer_date": _iso(commit.committer_date),
        "message": message[:10_000],
        "parents": json.dumps(commit.parents or []),
        "files_changed": str(len(paths)),
        "lines_added": str(lines_added),
        "lines_deleted": str(lines_deleted),
        "file_paths": json.dumps(paths),
        "is_merge": "false",
        "bug_fix_candidate": "true" if detect_bug_fix(message).is_candidate else "false",
        "error": "",
    }
    return row


def mine_repos(
    repos: Iterable[str],
    *,
    out_path: Path,
    errors_path: Path,
    status_path: Path,
    clone_dir: Path,
    limit: int | None,
    since: datetime | None,
    resume: bool = True,
    mode: str = "custom",
) -> dict[str, Any]:
    try:
        from pydriller import Repository  # imported lazily for a clear error message
    except ImportError as exc:
        raise RuntimeError("PyDriller is not installed. Run: pip install -r requirements.txt") from exc

    out_path.parent.mkdir(parents=True, exist_ok=True)
    errors_path.parent.mkdir(parents=True, exist_ok=True)
    status_path.parent.mkdir(parents=True, exist_ok=True)

    seen, existing_counts = _load_existing(out_path) if resume else (set(), {})
    file_has_rows = resume and out_path.exists() and out_path.stat().st_size > 0
    output = out_path.open("a" if resume else "w", newline="", encoding="utf-8")
    writer = csv.DictWriter(output, fieldnames=COLUMNS, extrasaction="ignore")
    if not file_has_rows:
        writer.writeheader()
    output.flush()

    status: dict[str, Any] = {
        "started_at": _iso(datetime.now(timezone.utc)),
        "mode": mode,
        "limit_per_repo": limit,
        "since": _iso(since) if since else None,
        "output": str(out_path),
        "repos": [],
    }
    any_success = False

    try:
        for slug in repos:
            repo_start = time.monotonic()
            entry: dict[str, Any] = {
                "repo": slug,
                "status": "pending",
                "commits_scanned": 0,
                "existing_rows": 0,
                "rows_written": 0,
                "skipped_resume": 0,
                "skipped_merge": 0,
                "skipped_empty": 0,
                "skipped_before_since": 0,
                "errors": 0,
                "truncated_by_limit": False,
                "skipped_existing_limit": False,
            }
            try:
                split_slug(slug)
                existing_for_repo = existing_counts.get(slug, 0)
                entry["existing_rows"] = existing_for_repo
                if limit is not None and existing_for_repo >= limit:
                    entry["status"] = "ok"
                    entry["truncated_by_limit"] = True
                    entry["skipped_existing_limit"] = True
                    any_success = True
                    continue
                clone_path = ensure_clone(slug, clone_dir)
                entry["clone_path"] = str(clone_path)
                entry["status"] = "running"
                repository = Repository(path_to_repo=str(clone_path))
                for commit in repository.traverse_commits():
                    entry["commits_scanned"] += 1
                    if since and commit.author_date and commit.author_date < since:
                        entry["skipped_before_since"] += 1
                        continue
                    key = (slug, commit.hash)
                    if key in seen:
                        entry["skipped_resume"] += 1
                        continue
                    if commit.merge:
                        entry["skipped_merge"] += 1
                        continue
                    try:
                        row = _commit_row(slug, commit)
                    except Exception as exc:
                        entry["errors"] += 1
                        _write_error(errors_path, slug, commit.hash, "extract", str(exc))
                        continue
                    if row is None:
                        entry["skipped_empty"] += 1
                        continue
                    writer.writerow(row)
                    seen.add(key)
                    entry["rows_written"] += 1
                    if entry["rows_written"] % 50 == 0:
                        output.flush()
                    if (
                        limit is not None
                        and existing_for_repo + entry["rows_written"] >= limit
                    ):
                        entry["truncated_by_limit"] = True
                        break
                output.flush()
                entry["status"] = "ok"
                any_success = True
            except Exception as exc:
                entry["status"] = "failed"
                entry["failure"] = str(exc)[:1000]
                _write_error(errors_path, slug, None, "repository", str(exc))
                traceback.print_exc()
            finally:
                entry["duration_seconds"] = round(time.monotonic() - repo_start, 2)
                status["repos"].append(entry)
                print(
                    f"[{slug}] {entry['status']} rows={entry['rows_written']} "
                    f"scanned={entry['commits_scanned']} errors={entry['errors']}"
                )
    finally:
        output.close()

    status["finished_at"] = _iso(datetime.now(timezone.utc))
    status["total_rows_written"] = sum(int(item["rows_written"]) for item in status["repos"])
    status["repositories_ok"] = sum(1 for item in status["repos"] if item["status"] == "ok")
    status_path.write_text(json.dumps(status, indent=2), encoding="utf-8")
    status["any_success"] = any_success
    return status


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Mine GitHub commit history with PyDriller")
    parser.add_argument("--repos", nargs="+", default=list(DEFAULT_REPOS), help="OWNER/REPO slugs")
    parser.add_argument("--pilot", action="store_true", help="Small reproducible mining run")
    parser.add_argument("--limit", type=int, default=None, help="Max stored commits per repository, including resumed rows")
    parser.add_argument("--since", type=str, default=None, help="Only commits on/after this ISO date")
    parser.add_argument("--out", type=str, default=None, help="Raw commit CSV output")
    parser.add_argument("--errors-out", type=str, default=None)
    parser.add_argument("--status-out", type=str, default=None)
    parser.add_argument("--clone-dir", type=str, default=str(BACKEND_DIR / "data" / "repos"))
    parser.add_argument("--no-resume", action="store_true", help="Ignore existing rows (rewrites header)")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    since = _parse_since(args.since)
    limit = args.limit
    if args.pilot and limit is None:
        limit = 300
    mode = "pilot" if args.pilot else "full"

    raw_dir = BACKEND_DIR / "data" / "raw"
    out_path = Path(args.out) if args.out else raw_dir / ("commits_pilot.csv" if args.pilot else "commits.csv")
    errors_path = Path(args.errors_out) if args.errors_out else out_path.with_name(
        out_path.stem + "_errors.csv"
    )
    status_path = Path(args.status_out) if args.status_out else out_path.with_name(
        out_path.stem + "_status.json"
    )

    try:
        status = mine_repos(
            args.repos,
            out_path=out_path,
            errors_path=errors_path,
            status_path=status_path,
            clone_dir=Path(args.clone_dir),
            limit=limit,
            since=since,
            resume=not args.no_resume,
            mode=mode,
        )
    except RuntimeError as exc:
        print(f"Mining setup failed: {exc}", file=sys.stderr)
        return 1

    print(json.dumps({k: status[k] for k in ("total_rows_written", "repositories_ok")}, indent=2))
    print(f"Raw commits: {out_path}")
    print(f"Status: {status_path}")
    return 0 if status.get("any_success") else 1


if __name__ == "__main__":
    raise SystemExit(main())
