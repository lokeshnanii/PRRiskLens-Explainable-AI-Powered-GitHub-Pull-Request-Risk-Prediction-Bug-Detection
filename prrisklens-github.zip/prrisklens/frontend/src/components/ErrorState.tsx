import { AlertTriangle, KeyRound, RefreshCw, ServerCrash, TimerOff } from "lucide-react";
import { formatNumber } from "../lib/format";
import { ApiError } from "../services/api";

interface ErrorStateProps {
  error: unknown;
  onRetry?: () => void;
}

function describe(error: unknown): { code: string; message: string; details: Record<string, unknown> } {
  if (error instanceof ApiError) {
    return { code: error.code, message: error.message, details: error.details };
  }
  if (error instanceof Error) {
    return { code: "unexpected_error", message: error.message, details: {} };
  }
  return { code: "unexpected_error", message: "An unexpected error occurred.", details: {} };
}

function hintFor(code: string, details: Record<string, unknown>): string | undefined {
  if (code === "github_rate_limited") {
    if (details.kind === "secondary") {
      return "GitHub's secondary (abuse) rate limit was triggered. Wait for the retry window, then try again.";
    }
    if (details.authenticated === true) {
      return "The authenticated GitHub quota for the backend token is exhausted. The header shows the remaining quota and reset time; retry after the reset.";
    }
    if (details.authenticated === false) {
      return "Unauthenticated GitHub requests are limited to 60 per hour. Set GITHUB_TOKEN in the repository-root .env (backend only) to use 5,000 per hour, or wait for the reset time.";
    }
  }
  if (code === "github_unauthorized") {
    if (details.authenticated === false) {
      return "GitHub required authentication and no GITHUB_TOKEN is configured. Set one in the repository-root .env; it stays on the backend.";
    }
    return "The backend's GitHub token was rejected. Verify GITHUB_TOKEN is valid, not expired, and not revoked. The token is never sent to the browser.";
  }
  return hints[code];
}

const hints: Record<string, string> = {
  github_rate_limited:
    "The GitHub API quota for this backend is exhausted. Wait for the reset time shown below, then retry.",
  github_unauthorized:
    "The backend's GitHub token was rejected. Verify GITHUB_TOKEN is valid, not expired, and not revoked.",
  github_not_found:
    "The repository, pull request or commit was not found, or it is private and the backend has no token with access.",
  github_forbidden:
    "GitHub denied access. A token with the right scope may be required for this repository.",
  github_timeout: "GitHub did not respond in time. Retry in a moment.",
  github_unreachable: "The backend could not reach the GitHub API. Check its network access.",
  model_unavailable:
    "No trained model artifact is deployed. Run mine.py, szz.py, dataset.py and train.py to enable risk scoring.",
  request_too_large: "The request was rejected by the backend size limit.",
  network_error: "Start the FastAPI backend and confirm VITE_API_BASE_URL points at it.",
  request_timeout: "The analysis took too long. Try a smaller pull request.",
};

export default function ErrorState({ error, onRetry }: ErrorStateProps) {
  const { code, message, details } = describe(error);
  const hint = hintFor(code, details);
  const limit = typeof details.limit === "number" ? details.limit : null;
  const remaining = typeof details.remaining === "number" ? details.remaining : null;
  const retryAfter =
    typeof details.retry_after_seconds === "number" ? details.retry_after_seconds : null;

  return (
    <div className="glass-panel border-rose-400/20 bg-rose-500/[0.04] p-6" role="alert">
      <div className="flex items-start gap-3">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-rose-400/25 bg-rose-500/10 text-rose-300">
          {code === "request_timeout" ? (
            <TimerOff className="h-4 w-4" aria-hidden="true" />
          ) : code.startsWith("github_") ? (
            <ServerCrash className="h-4 w-4" aria-hidden="true" />
          ) : (
            <AlertTriangle className="h-4 w-4" aria-hidden="true" />
          )}
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-rose-100">Analysis could not complete</p>
          <p className="mt-1 break-words text-[13px] leading-relaxed text-rose-100/80">{message}</p>
          {hint ? (
            <p className="mt-3 flex items-start gap-2 rounded-lg border border-white/10 bg-ink-950/40 p-3 text-[12px] leading-relaxed text-slate-300">
              {code === "github_rate_limited" || code === "github_unauthorized" ? (
                <KeyRound className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-300" aria-hidden="true" />
              ) : (
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-slate-400" aria-hidden="true" />
              )}
              {hint}
            </p>
          ) : null}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="rounded-md border border-white/10 bg-ink-950/50 px-2 py-1 font-mono text-[10px] text-slate-400">
              {code}
            </span>
            {code.startsWith("github_") && typeof details.authenticated === "boolean" ? (
              <span className="rounded-md border border-white/10 bg-ink-950/50 px-2 py-1 text-[10px] text-slate-400">
                {details.authenticated ? "authenticated" : "unauthenticated"}
              </span>
            ) : null}
            {limit !== null && remaining !== null ? (
              <span className="text-[11px] text-slate-400">
                GitHub quota: {formatNumber(remaining)}/{formatNumber(limit)} remaining
              </span>
            ) : null}
            {typeof details.reset_at === "string" ? (
              <span className="text-[11px] text-slate-400">GitHub reset: {details.reset_at}</span>
            ) : null}
            {retryAfter !== null ? (
              <span className="text-[11px] text-slate-400">Retry after {retryAfter}s</span>
            ) : null}
            {onRetry ? (
              <button type="button" onClick={onRetry} className="btn-ghost ml-auto !px-3 !py-1.5 !text-[11px]">
                <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                Retry
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
