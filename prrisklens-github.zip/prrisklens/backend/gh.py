"""GitHub REST API integration.

Security notes:
* The only repository hosts accepted are github.com pull request / commit URLs
  parsed by :func:`parse_github_url`.
* Requests are constructed from the validated owner/repo and sent exclusively
  to the configured API host. Arbitrary user URLs are never fetched (SSRF
  protection).
* The optional token is read from the backend environment, attached only to
  outbound GitHub requests, and never echoed in errors or responses.
"""

from __future__ import annotations

import re
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Literal, Mapping, Sequence
from urllib.parse import quote, urlsplit

import requests

_OWNER_RE = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$")
_REPO_RE = re.compile(r"^[A-Za-z0-9._-]{1,100}$")
_SHA_RE = re.compile(r"^[0-9a-fA-F]{7,40}$")
_PR_NUMBER_RE = re.compile(r"^[1-9][0-9]{0,9}$")
_PAGE_RE = re.compile(r"[?&]page=(\d+)[^>]*>;\s*rel=\"last\"")

GITHUB_HOSTS = frozenset({"github.com", "www.github.com"})
MAX_URL_LENGTH = 500


class GitHubError(Exception):
    """Structured GitHub/HTTP failure safe to surface to API clients."""

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int = 502,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        self.code = code
        self.message = message
        self.status_code = status_code
        self.details = dict(details or {})
        super().__init__(message)


class InvalidGitHubURLError(GitHubError):
    def __init__(self, message: str) -> None:
        super().__init__("invalid_github_url", message, status_code=422)


@dataclass(frozen=True)
class GitHubRef:
    kind: Literal["pull", "commit"]
    owner: str
    repo: str
    number: int | None
    sha: str | None
    canonical_url: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "owner": self.owner,
            "repo": self.repo,
            "number": self.number,
            "sha": self.sha,
            "url": self.canonical_url,
        }


def parse_github_url(raw: str) -> GitHubRef:
    """Validate a github.com pull request or commit URL.

    Rejects credentials, ports, query strings, fragments, encoded paths,
    non-GitHub hosts, unsupported resources and malformed paths.
    """

    if not isinstance(raw, str) or not raw.strip():
        raise InvalidGitHubURLError("Enter a GitHub pull request or commit URL.")
    candidate = raw.strip()
    if len(candidate) > MAX_URL_LENGTH:
        raise InvalidGitHubURLError("URL is too long.")

    parts = urlsplit(candidate)
    if parts.scheme.lower() not in {"http", "https"}:
        raise InvalidGitHubURLError("URL must start with http:// or https://.")
    if parts.username or parts.password:
        raise InvalidGitHubURLError("URLs with embedded credentials are not allowed.")
    try:
        _ = parts.port  # noqa: F841 - accessing an invalid port raises ValueError
    except ValueError as exc:
        raise InvalidGitHubURLError("URL contains an invalid port.") from exc
    if parts.port is not None:
        raise InvalidGitHubURLError("URLs with explicit ports are not supported.")
    if (parts.hostname or "").lower() not in GITHUB_HOSTS:
        raise InvalidGitHubURLError("Only github.com URLs are supported.")
    if parts.query or parts.fragment:
        raise InvalidGitHubURLError("URL must not contain query strings or fragments.")
    if "%" in parts.path:
        raise InvalidGitHubURLError("Encoded URL paths are not supported.")

    segments = [segment for segment in parts.path.strip("/").split("/")]
    if len(segments) != 4:
        raise InvalidGitHubURLError(
            "Expected https://github.com/OWNER/REPOSITORY/pull/NUMBER "
            "or https://github.com/OWNER/REPOSITORY/commit/SHA."
        )

    owner, repo, resource, tail = segments
    if not _OWNER_RE.match(owner):
        raise InvalidGitHubURLError("Invalid GitHub owner name.")
    if not _REPO_RE.match(repo) or repo.endswith(".git"):
        raise InvalidGitHubURLError("Invalid GitHub repository name.")

    if resource == "pull":
        if not _PR_NUMBER_RE.match(tail):
            raise InvalidGitHubURLError("Pull request numbers must be positive integers.")
        canonical = f"https://github.com/{owner}/{repo}/pull/{int(tail)}"
        return GitHubRef("pull", owner, repo, int(tail), None, canonical)

    if resource == "commit":
        if not _SHA_RE.match(tail):
            raise InvalidGitHubURLError("Commit URLs must contain a 7-40 character hexadecimal SHA.")
        sha = tail.lower()
        canonical = f"https://github.com/{owner}/{repo}/commit/{sha}"
        return GitHubRef("commit", owner, repo, None, sha, canonical)

    raise InvalidGitHubURLError("Only pull request and commit URLs are supported.")


# ---------------------------------------------------------------------------
# Normalized metadata
# ---------------------------------------------------------------------------


def _iso(value: datetime | None) -> str | None:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z") if value else None


def _parse_iso(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _header(headers: Mapping[str, str], name: str) -> str | None:
    lowered = name.lower()
    for key, value in headers.items():
        if key.lower() == lowered:
            return value
    return None


def _utc_param(value: datetime) -> str:
    return value.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _optional_int(value: Any) -> int | None:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed >= 0 else None


def _epoch_to_datetime(value: Any) -> datetime | None:
    seconds = _optional_int(value)
    if seconds is None or seconds <= 0:
        return None
    try:
        return datetime.fromtimestamp(seconds, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None


@dataclass(frozen=True)
class RateLimitSnapshot:
    """Last observed GitHub primary-rate-limit state.

    Values come from GitHub's response headers (or ``/rate_limit``) and are
    never inferred when the header is missing.
    """

    authenticated: bool
    limit: int | None = None
    remaining: int | None = None
    used: int | None = None
    reset_at: datetime | None = None
    observed_at: datetime | None = None
    source: str = "response_headers"
    resource: str = "core"

    @property
    def near_limit(self) -> bool:
        if self.remaining is None or not self.limit:
            return False
        return self.remaining <= max(10, int(self.limit * 0.1))

    def to_dict(self) -> dict[str, Any]:
        return {
            "authenticated": self.authenticated,
            "mode": "authenticated" if self.authenticated else "unauthenticated",
            "resource": self.resource,
            "limit": self.limit,
            "remaining": self.remaining,
            "used": self.used,
            "reset_at": _iso(self.reset_at),
            "observed_at": _iso(self.observed_at),
            "source": self.source,
            "near_limit": self.near_limit,
        }


def _rate_limit_from_headers(
    headers: Mapping[str, str],
    authenticated: bool,
    *,
    source: str = "response_headers",
    now: datetime | None = None,
) -> RateLimitSnapshot | None:
    limit = _optional_int(_header(headers, "x-ratelimit-limit"))
    remaining = _optional_int(_header(headers, "x-ratelimit-remaining"))
    used = _optional_int(_header(headers, "x-ratelimit-used"))
    reset_at = _epoch_to_datetime(_header(headers, "x-ratelimit-reset"))
    if limit is None and remaining is None and reset_at is None:
        return None
    if used is None and limit is not None and remaining is not None:
        used = max(0, limit - remaining)
    return RateLimitSnapshot(
        authenticated=authenticated,
        limit=limit,
        remaining=remaining,
        used=used,
        reset_at=reset_at,
        observed_at=now or datetime.now(tz=timezone.utc),
        source=source,
    )


def _rate_limit_from_payload(
    core: Mapping[str, Any],
    authenticated: bool,
    *,
    now: datetime | None = None,
) -> RateLimitSnapshot | None:
    limit = _optional_int(core.get("limit"))
    remaining = _optional_int(core.get("remaining"))
    used = _optional_int(core.get("used"))
    reset_at = _epoch_to_datetime(core.get("reset"))
    if limit is None and remaining is None and reset_at is None:
        return None
    if used is None and limit is not None and remaining is not None:
        used = max(0, limit - remaining)
    return RateLimitSnapshot(
        authenticated=authenticated,
        limit=limit,
        remaining=remaining,
        used=used,
        reset_at=reset_at,
        observed_at=now or datetime.now(tz=timezone.utc),
        source="rate_limit_endpoint",
    )


def _response_message(response: Any) -> str | None:
    try:
        payload = response.json()
    except (ValueError, TypeError):
        return None
    if isinstance(payload, dict) and isinstance(payload.get("message"), str):
        return payload["message"][:300]
    return None


@dataclass
class ChangedFile:
    filename: str
    status: str
    additions: int
    deletions: int
    changes: int
    patch: str | None
    previous_filename: str | None = None

    def to_dict(self, max_patch_chars: int) -> dict[str, Any]:
        patch = self.patch
        truncated = False
        if patch is not None and len(patch) > max_patch_chars:
            patch = patch[:max_patch_chars]
            truncated = True
        return {
            "filename": self.filename,
            "status": self.status,
            "additions": self.additions,
            "deletions": self.deletions,
            "changes": self.changes,
            "previous_filename": self.previous_filename,
            "patch_available": self.patch is not None,
            "patch": patch,
            "patch_truncated": truncated,
        }


@dataclass
class CommitMeta:
    sha: str
    message: str
    author_name: str | None
    author_login: str | None
    authored_at: datetime | None
    parents: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "sha": self.sha,
            "message": self.message[:2000],
            "author_name": self.author_name,
            "author_login": self.author_login,
            "authored_at": _iso(self.authored_at),
            "parents": self.parents,
        }


@dataclass
class ReviewSummary:
    total: int
    states: dict[str, int]

    def to_dict(self) -> dict[str, Any]:
        return {"total": self.total, "states": self.states}


@dataclass
class CheckSummary:
    available: bool
    check_runs_total: int | None
    conclusions: dict[str, int]
    status_state: str | None
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "available": self.available,
            "check_runs_total": self.check_runs_total,
            "conclusions": self.conclusions,
            "status_state": self.status_state,
            "warnings": self.warnings,
        }


@dataclass
class ChangeSnapshot:
    kind: Literal["pull_request", "commit"]
    owner: str
    repo: str
    url: str
    title: str
    description: str | None
    author_login: str | None
    author_name: str | None
    sha: str
    number: int | None
    state: str | None
    merged: bool | None
    base_sha: str | None
    parent_shas: list[str]
    created_at: datetime
    updated_at: datetime | None
    files: list[ChangedFile]
    total_additions: int
    total_deletions: int
    total_files: int
    commits: list[CommitMeta]
    reviews: ReviewSummary | None
    checks: CheckSummary | None
    warnings: list[str] = field(default_factory=list)
    files_truncated: bool = False
    patches_missing: int = 0
    timestamps_fallback: bool = False

    @property
    def earliest_commit_at(self) -> datetime:
        authored = [c.authored_at for c in self.commits if c.authored_at is not None]
        return min(authored) if authored else self.created_at

    @property
    def analyzed_shas(self) -> set[str]:
        shas = {self.sha.lower()}
        shas.update(commit.sha.lower() for commit in self.commits)
        return {sha for sha in shas if sha}

    def to_dict(self, max_patch_chars: int) -> dict[str, Any]:
        checks = self.checks.to_dict() if self.checks else None
        return {
            "kind": self.kind,
            "repository": {
                "owner": self.owner,
                "repo": self.repo,
                "full_name": f"{self.owner}/{self.repo}",
                "url": f"https://github.com/{self.owner}/{self.repo}",
            },
            "title": self.title,
            "description": self.description,
            "author_login": self.author_login,
            "author_name": self.author_name,
            "sha": self.sha,
            "number": self.number,
            "state": self.state,
            "merged": self.merged,
            "base_sha": self.base_sha,
            "parent_shas": self.parent_shas,
            "created_at": _iso(self.created_at),
            "updated_at": _iso(self.updated_at),
            "additions": self.total_additions,
            "deletions": self.total_deletions,
            "files_changed": self.total_files,
            "reviews": self.reviews.to_dict() if self.reviews else None,
            "checks": checks,
            "files": [file.to_dict(max_patch_chars) for file in self.files],
            "commits": [commit.to_dict() for commit in self.commits],
            "warnings": list(self.warnings),
            "files_truncated": self.files_truncated,
            "patches_missing": self.patches_missing,
            "diff_complete": not self.files_truncated,
        }


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class GitHubClient:
    def __init__(
        self,
        token: str | None = None,
        *,
        api_url: str = "https://api.github.com",
        timeout: float = 15.0,
        session: Any | None = None,
        max_files: int = 300,
        max_commits: int = 250,
        max_retries: int = 1,
    ) -> None:
        if not api_url.startswith("https://"):
            raise ValueError("GitHub API URL must use https")
        self.token = token
        self.api_url = api_url.rstrip("/")
        self.timeout = timeout
        self.session = session or requests.Session()
        self.max_files = max_files
        self.max_commits = max_commits
        self.max_retries = max_retries
        self._rate_limit: RateLimitSnapshot | None = None
        self._rate_limit_lock = threading.Lock()

    @property
    def authenticated(self) -> bool:
        return bool(self.token)

    def rate_limit(self) -> RateLimitSnapshot | None:
        """Return the most recent primary-rate-limit snapshot, if observed."""

        with self._rate_limit_lock:
            return self._rate_limit

    def _record_rate_limit(self, headers: Mapping[str, str]) -> RateLimitSnapshot | None:
        snapshot = _rate_limit_from_headers(headers, self.authenticated)
        if snapshot is None:
            return None
        with self._rate_limit_lock:
            self._rate_limit = snapshot
        return snapshot

    def _auth_details(self) -> dict[str, Any]:
        return {
            "authenticated": self.authenticated,
            "mode": "authenticated" if self.authenticated else "unauthenticated",
            "token_configured": self.authenticated,
        }

    # -- low level HTTP ----------------------------------------------------

    def _get(
        self,
        path: str,
        params: Mapping[str, Any] | None = None,
        *,
        accept: str | None = None,
    ) -> tuple[Any, Mapping[str, str]]:
        if not path.startswith("/"):
            raise ValueError("GitHub API paths must be absolute")
        url = f"{self.api_url}{path}"
        headers = {
            "Accept": accept or "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "PRRiskLens/1.0",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        for attempt in range(self.max_retries + 1):
            try:
                response = self.session.get(
                    url, params=dict(params or {}), headers=headers, timeout=self.timeout
                )
            except requests.Timeout as exc:
                raise GitHubError(
                    "github_timeout",
                    "GitHub API request timed out. Try again shortly.",
                    status_code=504,
                ) from exc
            except requests.RequestException as exc:
                raise GitHubError(
                    "github_unreachable",
                    "Could not reach the GitHub API.",
                    status_code=502,
                ) from exc

            status = int(getattr(response, "status_code", 0))
            response_headers = getattr(response, "headers", {}) or {}
            snapshot = self._record_rate_limit(response_headers)

            if status == 200:
                try:
                    payload = response.json()
                except ValueError as exc:
                    raise GitHubError(
                        "malformed_github_response",
                        "GitHub returned a response that was not valid JSON.",
                        status_code=502,
                    ) from exc
                if not isinstance(payload, (dict, list)):
                    raise GitHubError(
                        "malformed_github_response",
                        "GitHub returned an unexpected response shape.",
                        status_code=502,
                    )
                return payload, response_headers

            if status == 404:
                message = (
                    "The repository, pull request, or commit was not found or is not "
                    "accessible with the configured GitHub token."
                    if self.authenticated
                    else "The repository, pull request, or commit was not found or is not "
                    "accessible. Private repositories require a configured GITHUB_TOKEN."
                )
                raise GitHubError(
                    "github_not_found", message, status_code=404, details=self._auth_details()
                )
            if status in (403, 429):
                details = self._auth_details()
                if snapshot is not None:
                    details.update(snapshot.to_dict())
                details["expected_hourly_limit"] = 5000 if self.authenticated else 60
                retry_after = _optional_int(_header(response_headers, "retry-after"))
                if retry_after is not None:
                    details["retry_after_seconds"] = retry_after

                github_message = (_response_message(response) or "").lower()
                primary_exhausted = (
                    status == 429
                    or _header(response_headers, "x-ratelimit-remaining") == "0"
                )
                secondary = (
                    not primary_exhausted
                    and ("secondary rate limit" in github_message or retry_after is not None)
                )

                if primary_exhausted or secondary:
                    reset_at = snapshot.reset_at if snapshot else None
                    details["kind"] = "primary" if primary_exhausted else "secondary"
                    if primary_exhausted:
                        message = (
                            "GitHub API rate limit exceeded for the authenticated token."
                            if self.authenticated
                            else "GitHub API rate limit exceeded for unauthenticated requests. "
                            "Configure GITHUB_TOKEN on the backend to raise the limit to "
                            "5,000 requests per hour."
                        )
                        message += (
                            f" Try again after {_iso(reset_at)}."
                            if reset_at
                            else " Try again later."
                        )
                    else:
                        message = "GitHub secondary rate limit triggered."
                        message += (
                            f" Retry after {retry_after} seconds."
                            if retry_after is not None
                            else " Wait a moment before retrying."
                        )
                    raise GitHubError(
                        "github_rate_limited",
                        message,
                        status_code=429,
                        details=details,
                    )

                message = (
                    "GitHub denied access to this resource for the configured token. "
                    "Verify the token has the required scope for this repository."
                    if self.authenticated
                    else "GitHub denied access to this resource. Configure a token with the "
                    "appropriate scope for private repositories."
                )
                details["kind"] = "forbidden"
                raise GitHubError(
                    "github_forbidden", message, status_code=403, details=details
                )
            if status == 401:
                message = (
                    "GitHub rejected the configured GITHUB_TOKEN (401). Verify that the token "
                    "is valid, has not expired, and has not been revoked."
                    if self.authenticated
                    else "GitHub requires authentication for this request (401), but no "
                    "GITHUB_TOKEN is configured on the backend."
                )
                details = self._auth_details()
                github_message = _response_message(response)
                if github_message:
                    details["github_message"] = github_message
                raise GitHubError(
                    "github_unauthorized", message, status_code=502, details=details
                )
            if 500 <= status < 600:
                if attempt < self.max_retries:
                    time.sleep(0.4 * (attempt + 1))
                    continue
                raise GitHubError(
                    "github_upstream_error",
                    "GitHub is currently unavailable. Try again later.",
                    status_code=502,
                )
            raise GitHubError(
                "github_error",
                f"GitHub returned an unexpected status ({status}).",
                status_code=502,
            )

        raise GitHubError("github_error", "GitHub request failed.", status_code=502)

    def _paginate(
        self,
        path: str,
        params: Mapping[str, Any] | None,
        max_items: int,
        *,
        per_page: int = 100,
    ) -> tuple[list[dict[str, Any]], bool]:
        items: list[dict[str, Any]] = []
        truncated = False
        page = 1
        while len(items) < max_items:
            payload, _ = self._get(
                path, {**dict(params or {}), "per_page": per_page, "page": page}
            )
            if not isinstance(payload, list):
                raise GitHubError(
                    "malformed_github_response",
                    "GitHub returned an unexpected pagination payload.",
                    status_code=502,
                )
            batch = [item for item in payload if isinstance(item, dict)]
            items.extend(batch)
            if len(payload) < per_page:
                break
            page += 1
            if len(items) >= max_items:
                truncated = True
                break
        if len(items) > max_items:
            items = items[:max_items]
            truncated = True
        return items, truncated

    def _optional(
        self,
        path: str,
        params: Mapping[str, Any],
        label: str,
        warnings: list[str],
    ) -> Any | None:
        try:
            payload, _ = self._get(path, params)
            return payload
        except GitHubError as exc:
            warnings.append(f"{label} unavailable: {exc.message}")
            return None

    # -- public fetch ------------------------------------------------------

    def fetch_rate_limit(self) -> RateLimitSnapshot:
        """Read the current primary rate-limit state.

        ``GET /rate_limit`` does not count against the primary limit. Values are
        taken from ``resources.core`` when present, otherwise from response
        headers. Nothing is inferred when GitHub omits both.
        """

        payload, headers = self._get("/rate_limit")
        snapshot = self._record_rate_limit(headers)
        if isinstance(payload, dict):
            resources = payload.get("resources")
            core = resources.get("core") if isinstance(resources, dict) else None
            if not isinstance(core, dict):
                core = payload.get("rate") if isinstance(payload.get("rate"), dict) else None
            if isinstance(core, dict):
                parsed = _rate_limit_from_payload(core, self.authenticated)
                if parsed is not None:
                    with self._rate_limit_lock:
                        self._rate_limit = parsed
                    return parsed
        if snapshot is None:
            snapshot = RateLimitSnapshot(
                authenticated=self.authenticated,
                observed_at=datetime.now(tz=timezone.utc),
                source="rate_limit_endpoint",
            )
        return snapshot

    def fetch(self, ref: GitHubRef) -> ChangeSnapshot:
        if ref.kind == "pull":
            return self._fetch_pull(ref)
        return self._fetch_commit(ref)

    def _fetch_pull(self, ref: GitHubRef) -> ChangeSnapshot:
        warnings: list[str] = []
        base = f"/repos/{ref.owner}/{ref.repo}"
        meta, _ = self._get(f"{base}/pulls/{ref.number}")
        if not isinstance(meta, dict):
            raise GitHubError(
                "malformed_github_response",
                "GitHub returned an unexpected pull request payload.",
                status_code=502,
            )

        files_raw, files_truncated = self._paginate(
            f"{base}/pulls/{ref.number}/files", None, self.max_files
        )
        commits_raw, commits_truncated = self._paginate(
            f"{base}/pulls/{ref.number}/commits", None, self.max_commits
        )
        if commits_truncated:
            warnings.append(
                f"Only the first {self.max_commits} pull request commits were inspected."
            )

        files = [self._normalize_file(item) for item in files_raw]
        commits = [self._normalize_commit(item) for item in commits_raw]
        head_sha = (meta.get("head") or {}).get("sha") or ""
        base_sha = (meta.get("base") or {}).get("sha")
        author_login = (meta.get("user") or {}).get("login")
        created_at = _parse_iso(meta.get("created_at"))
        if created_at is None:
            # Extremely defensive: GitHub always returns created_at for PRs.
            created_at = datetime.now(tz=timezone.utc)
            warnings.append("Pull request creation time was unavailable; using request time.")

        total_files = _as_int(meta.get("changed_files"), len(files))
        total_additions = _as_int(meta.get("additions"), sum(f.additions for f in files))
        total_deletions = _as_int(meta.get("deletions"), sum(f.deletions for f in files))

        if len(files) < total_files:
            files_truncated = True
        if files_truncated:
            warnings.append(
                f"Only {len(files)} of {total_files} changed files were retrieved; "
                "the GitHub file limit was reached."
            )
        patches_missing = sum(1 for item in files if item.patch is None)
        if patches_missing:
            warnings.append(
                f"{patches_missing} file(s) have no textual patch (binary or oversized); "
                "line-level analysis cannot cover them."
            )
        if not files:
            warnings.append("GitHub returned no changed files for this pull request.")

        reviews_raw = self._optional(
            f"{base}/pulls/{ref.number}/reviews", {"per_page": 100}, "Review status", warnings
        )
        reviews = self._summarize_reviews(reviews_raw) if reviews_raw is not None else None
        checks = self._fetch_checks(base, head_sha, warnings) if head_sha else None

        return ChangeSnapshot(
            kind="pull_request",
            owner=ref.owner,
            repo=ref.repo,
            url=ref.canonical_url,
            title=str(meta.get("title") or "")[:500],
            description=(str(meta.get("body"))[:8000] if meta.get("body") else None),
            author_login=author_login,
            author_name=author_login,
            sha=head_sha,
            number=ref.number,
            state=meta.get("state"),
            merged=meta.get("merged"),
            base_sha=base_sha,
            parent_shas=[],
            created_at=created_at,
            updated_at=_parse_iso(meta.get("updated_at")),
            files=files,
            total_additions=total_additions,
            total_deletions=total_deletions,
            total_files=total_files,
            commits=commits,
            reviews=reviews,
            checks=checks,
            warnings=warnings,
            files_truncated=files_truncated,
            patches_missing=patches_missing,
        )

    def _fetch_commit(self, ref: GitHubRef) -> ChangeSnapshot:
        warnings: list[str] = []
        base = f"/repos/{ref.owner}/{ref.repo}"
        meta, _ = self._get(f"{base}/commits/{ref.sha}")
        if not isinstance(meta, dict):
            raise GitHubError(
                "malformed_github_response",
                "GitHub returned an unexpected commit payload.",
                status_code=502,
            )

        commit_detail = meta.get("commit") or {}
        author_detail = commit_detail.get("author") or {}
        message = str(commit_detail.get("message") or "")
        sha = str(meta.get("sha") or ref.sha or "").lower()
        if not sha:
            raise GitHubError(
                "malformed_github_response",
                "GitHub did not return a commit SHA.",
                status_code=502,
            )
        authored_at = _parse_iso(author_detail.get("date"))
        if authored_at is None:
            authored_at = _parse_iso((commit_detail.get("committer") or {}).get("date"))
        timestamps_fallback = False
        if authored_at is None:
            authored_at = datetime.now(tz=timezone.utc)
            timestamps_fallback = True
            warnings.append("Commit timestamp was unavailable; using request time.")

        parents = [
            str(parent.get("sha")).lower()
            for parent in (meta.get("parents") or [])
            if isinstance(parent, dict) and parent.get("sha")
        ]
        files_raw = meta.get("files") or []
        if not isinstance(files_raw, list):
            files_raw = []
        files = [self._normalize_file(item) for item in files_raw if isinstance(item, dict)]
        files_truncated = len(files_raw) >= 300
        if files_truncated:
            warnings.append(
                "GitHub caps commit file listings at 300; this commit may have more files."
            )
        patches_missing = sum(1 for item in files if item.patch is None)
        if patches_missing:
            warnings.append(
                f"{patches_missing} file(s) have no textual patch (binary or oversized); "
                "line-level analysis cannot cover them."
            )
        if not files:
            warnings.append("GitHub returned no changed files for this commit.")

        login = (meta.get("author") or {}).get("login")
        name = (author_detail.get("name") if isinstance(author_detail, dict) else None) or login
        additions = _as_int(meta.get("stats", {}).get("additions"), sum(f.additions for f in files))
        deletions = _as_int(meta.get("stats", {}).get("deletions"), sum(f.deletions for f in files))
        total_files = len(files)
        title, _, rest = message.partition("\n")

        checks = self._fetch_checks(base, sha, warnings)
        commit_meta = CommitMeta(
            sha=sha,
            message=message,
            author_name=name,
            author_login=login,
            authored_at=authored_at,
            parents=parents,
        )

        return ChangeSnapshot(
            kind="commit",
            owner=ref.owner,
            repo=ref.repo,
            url=ref.canonical_url,
            title=title.strip()[:500] or f"Commit {sha[:7]}",
            description=rest.strip()[:8000] or None,
            author_login=login,
            author_name=name,
            sha=sha,
            number=None,
            state=None,
            merged=None,
            base_sha=parents[0] if parents else None,
            parent_shas=parents,
            created_at=authored_at,
            updated_at=_parse_iso((commit_detail.get("committer") or {}).get("date")),
            files=files,
            total_additions=additions,
            total_deletions=deletions,
            total_files=total_files,
            commits=[commit_meta],
            reviews=None,
            checks=checks,
            warnings=warnings,
            files_truncated=files_truncated,
            patches_missing=patches_missing,
            timestamps_fallback=timestamps_fallback,
        )

    # -- helpers -----------------------------------------------------------

    def _normalize_file(self, item: Mapping[str, Any]) -> ChangedFile:
        patch = item.get("patch")
        return ChangedFile(
            filename=str(item.get("filename") or ""),
            status=str(item.get("status") or "modified"),
            additions=_as_int(item.get("additions")),
            deletions=_as_int(item.get("deletions")),
            changes=_as_int(item.get("changes")),
            patch=patch if isinstance(patch, str) else None,
            previous_filename=item.get("previous_filename"),
        )

    def _normalize_commit(self, item: Mapping[str, Any]) -> CommitMeta:
        detail = item.get("commit") or {}
        author_detail = detail.get("author") or {}
        user = item.get("author") or {}
        return CommitMeta(
            sha=str(item.get("sha") or "").lower(),
            message=str(detail.get("message") or ""),
            author_name=author_detail.get("name") or user.get("login"),
            author_login=user.get("login"),
            authored_at=_parse_iso(author_detail.get("date")),
            parents=[
                str(parent.get("sha")).lower()
                for parent in (item.get("parents") or [])
                if isinstance(parent, dict) and parent.get("sha")
            ],
        )

    def _summarize_reviews(self, payload: Any) -> ReviewSummary:
        if not isinstance(payload, list):
            return ReviewSummary(total=0, states={})
        states: dict[str, int] = {}
        for review in payload:
            if not isinstance(review, dict):
                continue
            state = str(review.get("state") or "unknown").lower()
            states[state] = states.get(state, 0) + 1
        return ReviewSummary(total=len(payload), states=states)

    def _fetch_checks(self, base: str, sha: str, warnings: list[str]) -> CheckSummary | None:
        check_payload = self._optional(
            f"{base}/commits/{sha}/check-runs", {"per_page": 100}, "Check runs", warnings
        )
        status_payload = self._optional(
            f"{base}/commits/{sha}/status", {}, "Commit status", warnings
        )
        if check_payload is None and status_payload is None:
            return None

        conclusions: dict[str, int] = {}
        total: int | None = None
        if isinstance(check_payload, dict):
            total = _as_int(check_payload.get("total_count"), 0)
            for run in check_payload.get("check_runs") or []:
                if not isinstance(run, dict):
                    continue
                conclusion = str(run.get("conclusion") or run.get("status") or "unknown").lower()
                conclusions[conclusion] = conclusions.get(conclusion, 0) + 1
        status_state = None
        if isinstance(status_payload, dict):
            status_state = status_payload.get("state")
        return CheckSummary(
            available=True,
            check_runs_total=total,
            conclusions=conclusions,
            status_state=status_state,
        )

    # -- history helpers used by feature extraction ------------------------

    def count_commits_before(
        self,
        owner: str,
        repo: str,
        author_login: str,
        cutoff: datetime,
        *,
        cap: int = 5000,
    ) -> tuple[int, bool]:
        """Count commits by an author strictly before ``cutoff``.

        GitHub's ``until`` filter is coarse (second precision), so the cutoff is
        reduced by one second. The count comes from the pagination Link header;
        if that header is absent the current page length is used.
        """

        until = _utc_param(cutoff.astimezone(timezone.utc) - timedelta(seconds=1))
        payload, headers = self._get(
            f"/repos/{owner}/{repo}/commits",
            {"author": author_login, "until": until, "per_page": 1},
        )
        if not isinstance(payload, list):
            raise GitHubError(
                "malformed_github_response",
                "GitHub returned an unexpected commit list payload.",
                status_code=502,
            )
        link = _header(headers, "link") or ""
        last_page: int | None = None
        for part in link.split(","):
            match = _PAGE_RE.search(part)
            if match:
                last_page = int(match.group(1))
                break
        count = last_page if last_page is not None else len(payload)
        capped = count > cap
        return min(count, cap), capped

    def list_file_commits_before(
        self,
        owner: str,
        repo: str,
        path: str,
        cutoff: datetime,
        *,
        per_page: int = 30,
    ) -> list[dict[str, Any]]:
        until = _utc_param(cutoff.astimezone(timezone.utc) - timedelta(seconds=1))
        payload, _ = self._get(
            f"/repos/{owner}/{repo}/commits",
            {"path": quote(path, safe=""), "until": until, "per_page": per_page},
        )
        if not isinstance(payload, list):
            return []
        return [item for item in payload if isinstance(item, dict)]
