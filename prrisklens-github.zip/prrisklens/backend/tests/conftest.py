"""Shared fixtures and synthetic GitHub data for the backend test suite.

Nothing in this module talks to the real GitHub API. GitHub responses are
constructed in memory so tests are deterministic and run offline.
"""

from __future__ import annotations

import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import pytest

BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:  # allow ``pytest`` from the repo root too
    sys.path.insert(0, str(BACKEND_DIR))

from config import Settings  # noqa: E402
from gh import (  # noqa: E402
    ChangedFile,
    ChangeSnapshot,
    CheckSummary,
    CommitMeta,
    GitHubError,
    RateLimitSnapshot,
    ReviewSummary,
)

HEAD_SHA = "c" * 40
BASE_SHA = "b" * 40
FIRST_COMMIT_SHA = "d" * 40


def utc(year: int, month: int, day: int, hour: int = 0, minute: int = 0) -> datetime:
    return datetime(year, month, day, hour, minute, tzinfo=timezone.utc)


def iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def make_file(
    filename: str,
    patch: str | None,
    *,
    status: str = "modified",
    additions: int = 10,
    deletions: int = 2,
) -> ChangedFile:
    return ChangedFile(
        filename=filename,
        status=status,
        additions=additions,
        deletions=deletions,
        changes=additions + deletions,
        patch=patch,
    )


PR_FILES: list[ChangedFile] = [
    make_file(
        "app/db.py",
        """@@ -1,3 +1,5 @@
 import sqlite3
-def get_user(conn, name):
-    return conn.execute("SELECT * FROM users WHERE name = ?", (name,)).fetchone()
+def get_user(conn, name):
+    query = f"SELECT * FROM users WHERE name = '{name}'"
+    return conn.execute(query).fetchone()
""",
        additions=3,
        deletions=2,
    ),
    make_file(
        "config/settings.py",
        """@@ -1,2 +1,3 @@
 DEBUG = False
+API_KEY = "sk-live1234567890abcdefghij"
""",
        additions=1,
        deletions=0,
    ),
    make_file(
        "tests/test_db.py",
        """@@ -1,4 +1,2 @@
 def test_get_user():
-    assert get_user(conn, "ada")["name"] == "ada"
-    assert get_user(conn, "bob")["name"] == "bob"
+    get_user(conn, "ada")
""",
        additions=1,
        deletions=2,
    ),
]


def make_pull_snapshot(files: list[ChangedFile] | None = None) -> ChangeSnapshot:
    created = utc(2024, 5, 1, 12, 0)
    return ChangeSnapshot(
        kind="pull_request",
        owner="pallets",
        repo="flask",
        url="https://github.com/pallets/flask/pull/123",
        title="Add user lookup endpoint",
        description="Adds a database helper used by the new endpoint.",
        author_login="ada",
        author_name="Ada Lovelace",
        sha=HEAD_SHA,
        number=123,
        state="open",
        merged=False,
        base_sha=BASE_SHA,
        parent_shas=[],
        created_at=created,
        updated_at=created + timedelta(hours=3),
        files=files if files is not None else list(PR_FILES),
        total_additions=sum(item.additions for item in (files or PR_FILES)),
        total_deletions=sum(item.deletions for item in (files or PR_FILES)),
        total_files=len(files if files is not None else PR_FILES),
        commits=[
            CommitMeta(
                sha=FIRST_COMMIT_SHA,
                message="Add database helper",
                author_name="Ada Lovelace",
                author_login="ada",
                authored_at=created + timedelta(hours=1),
                parents=[BASE_SHA],
            ),
            CommitMeta(
                sha=HEAD_SHA,
                message="Wire helper into endpoint",
                author_name="Ada Lovelace",
                author_login="ada",
                authored_at=created + timedelta(hours=2),
                parents=[FIRST_COMMIT_SHA],
            ),
        ],
        reviews=ReviewSummary(total=1, states={"approved": 1}),
        checks=CheckSummary(
            available=True,
            check_runs_total=2,
            conclusions={"success": 2},
            status_state="success",
        ),
    )


class FakeGitHubClient:
    """Minimal stand-in for GitHubClient used by feature/API tests."""

    def __init__(
        self,
        snapshot: ChangeSnapshot | None = None,
        *,
        prior_author_commits: int = 12,
        file_history: list[dict[str, Any]] | None = None,
        rate_limit_snapshot: RateLimitSnapshot | None = None,
        rate_limit_error: GitHubError | None = None,
    ) -> None:
        self.snapshot = snapshot or make_pull_snapshot()
        self.prior_author_commits = prior_author_commits
        self.file_history = file_history if file_history is not None else [bug_fix_commit()]
        self.history_calls: list[tuple[str, datetime]] = []
        self.count_calls: list[datetime] = []
        self.rate_limit_snapshot = rate_limit_snapshot or RateLimitSnapshot(
            authenticated=True,
            limit=5000,
            remaining=4987,
            used=13,
            reset_at=utc(2024, 5, 1, 12, 0),
            observed_at=utc(2024, 5, 1, 11, 0),
            source="rate_limit_endpoint",
        )
        self.rate_limit_error = rate_limit_error

    def fetch(self, ref: Any) -> ChangeSnapshot:
        return self.snapshot

    def rate_limit(self) -> RateLimitSnapshot:
        return self.rate_limit_snapshot

    def fetch_rate_limit(self) -> RateLimitSnapshot:
        if self.rate_limit_error is not None:
            raise self.rate_limit_error
        return self.rate_limit_snapshot

    def count_commits_before(
        self,
        owner: str,
        repo: str,
        author_login: str,
        cutoff: datetime,
        *,
        cap: int = 5000,
    ) -> tuple[int, bool]:
        self.count_calls.append(cutoff)
        return self.prior_author_commits, False

    def list_file_commits_before(
        self,
        owner: str,
        repo: str,
        path: str,
        cutoff: datetime,
        *,
        per_page: int = 30,
    ) -> list[dict[str, Any]]:
        self.history_calls.append((path, cutoff))
        return list(self.file_history)


def bug_fix_commit(
    sha: str = "e" * 40,
    message: str = "Fix crash when the user name is empty",
    authored_at: str = "2024-04-01T10:00:00Z",
) -> dict[str, Any]:
    return {
        "sha": sha,
        "parents": [{"sha": "f" * 40}],
        "commit": {
            "author": {"date": authored_at, "name": "Grace Hopper"},
            "message": message,
        },
    }


def make_training_frame(rows: int = 90) -> pd.DataFrame:
    """Synthetic, clearly separable data used only to exercise the trainer."""

    from core import FEATURES

    base = utc(2022, 1, 1)
    records: list[dict[str, Any]] = []
    for index in range(rows):
        positive = index % 6 == 0
        records.append(
            {
                "repo": "fixture/repo",
                "sha": f"{index + 1:040x}",
                "author_date": iso(base + timedelta(days=index)),
                "label": int(positive),
                "label_provenance": "szz_candidate" if positive else "no_szz_label",
                "bug_fix_message": False,
                "files_changed": 1 + index % 7 + (6 if positive else 0),
                "lines_added": 20 + (index % 30) * 3 + (120 if positive else 0),
                "lines_deleted": 2 + index % 11 + (30 if positive else 0),
                "previous_author_commits": index % 17,
                "prior_bug_fixes_in_touched_files": index % 4 + (2 if positive else 0),
                "commit_hour": (index * 3) % 24,
            }
        )
    return pd.DataFrame(records, columns=["repo", "sha", "author_date", "label", "label_provenance", "bug_fix_message", *FEATURES])


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    return Settings(
        github_token="test-token",
        models_dir=tmp_path / "models",
        data_dir=tmp_path / "data",
        rate_limit_per_minute=1000,
    )


@pytest.fixture
def snapshot() -> ChangeSnapshot:
    return make_pull_snapshot()


@pytest.fixture
def fake_client(snapshot: ChangeSnapshot) -> FakeGitHubClient:
    return FakeGitHubClient(snapshot)


@pytest.fixture(scope="session")
def trained_models(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Train real artifacts on synthetic data once for inference/API tests."""

    from train import train_and_evaluate

    models_dir = tmp_path_factory.mktemp("models")
    frame = make_training_frame()
    train_and_evaluate(
        frame,
        models_dir=models_dir,
        results_path=models_dir / "results.json",
        min_rows=50,
        min_train_positives=5,
        min_test_positives=2,
    )
    return models_dir
