import { AlertTriangle, CheckCircle2, Gauge, Info, ShieldQuestion, Terminal } from "lucide-react";
import type { DataCompleteness, ModelInfoSummary, Prediction, Thresholds } from "../types/analysis";
import { RISK_TONE, formatDuration, riskDescription } from "../lib/format";
import RiskRing from "./RiskRing";

interface RiskSummaryProps {
  prediction: Prediction;
  thresholds: Thresholds;
  completeness?: DataCompleteness;
  warnings?: string[];
  timings?: Record<string, number>;
  modelInfo?: ModelInfoSummary;
}

const completenessTone: Record<string, string> = {
  complete: "text-emerald-300",
  partial: "text-amber-300",
  unavailable: "text-rose-300",
};

export default function RiskSummary({
  prediction,
  thresholds,
  completeness,
  warnings = [],
  timings,
  modelInfo,
}: RiskSummaryProps) {
  const tone = prediction.risk_category ? RISK_TONE[prediction.risk_category] : null;

  if (prediction.status !== "ok" || prediction.risk_score === null || prediction.risk_score === undefined) {
    return (
      <section className="glass-panel flex h-full flex-col p-5 sm:p-6" aria-labelledby="risk-summary-title">
        <div className="flex items-center justify-between gap-2">
          <h2 id="risk-summary-title" className="section-label">
            Commit risk prediction
          </h2>
          <span className="chip !border-amber-400/25 !text-amber-200">
            <ShieldQuestion className="h-3 w-3" aria-hidden="true" />
            No model
          </span>
        </div>
        <div className="mt-6 flex flex-1 flex-col items-center justify-center text-center">
          <RiskRing score={null} category={null} size={168} />
          <p className="mt-5 max-w-sm text-[13px] leading-relaxed text-slate-300">
            {prediction.message || "No trained model was available, so no risk score was produced."}
          </p>
          {prediction.reason ? <p className="mt-2 max-w-sm text-[11px] text-slate-500">{prediction.reason}</p> : null}
          <div className="mt-5 w-full rounded-xl border border-white/10 bg-ink-950/60 p-3 text-left">
            <p className="flex items-center gap-2 text-[11px] font-medium text-slate-300">
              <Terminal className="h-3.5 w-3.5 text-aqua-400" aria-hidden="true" />
              Enable historical scoring
            </p>
            <code className="mt-2 block overflow-x-auto whitespace-pre font-mono text-[10.5px] leading-relaxed text-slate-400">
              python backend/mine.py --pilot{"\n"}
              python backend/szz.py --raw backend/data/raw/commits_pilot.csv{"\n"}
              {"  "}--out backend/data/processed/labels_pilot.csv{"\n"}
              python backend/dataset.py --raw backend/data/raw/commits_pilot.csv{"\n"}
              {"  "}--labels backend/data/processed/labels_pilot.csv{"\n"}
              {"  "}--out backend/data/processed/features_pilot.csv{"\n"}
              python backend/train.py --data backend/data/processed/features_pilot.csv
            </code>
          </div>
          <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
            Code findings on this page still come from the real diff and remain useful without a model.
          </p>
        </div>
        {warnings.length ? (
          <ul className="mt-5 space-y-1.5 border-t border-white/[0.06] pt-4">
            {warnings.slice(0, 3).map((warning) => (
              <li key={warning} className="flex gap-2 text-[11px] leading-relaxed text-amber-200/80">
                <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0" aria-hidden="true" />
                {warning}
              </li>
            ))}
          </ul>
        ) : null}
      </section>
    );
  }

  const score = prediction.risk_score;
  const category = prediction.risk_category ?? "Low";

  return (
    <section className="glass-panel flex h-full flex-col p-5 sm:p-6" aria-labelledby="risk-summary-title">
      <div className="flex items-center justify-between gap-2">
        <h2 id="risk-summary-title" className="section-label">
          Commit risk prediction
        </h2>
        <span className={`chip ${tone?.chip ?? ""}`}>
          <Gauge className="h-3 w-3" aria-hidden="true" />
          {category} risk
        </span>
      </div>

      <div className="mt-5 flex flex-col items-center gap-5 sm:flex-row sm:items-center">
        <RiskRing score={score} category={category} />
        <div className="min-w-0 flex-1">
          <p className={`text-sm font-semibold ${tone?.text ?? "text-white"}`}>{category} risk band</p>
          <p className="mt-2 text-[12px] leading-relaxed text-slate-400">{riskDescription(category, thresholds)}</p>
          <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 text-[11px]">
            <div>
              <dt className="text-slate-500">Model</dt>
              <dd className="mt-0.5 truncate font-medium text-slate-200">{prediction.model_type ?? "—"}</dd>
            </div>
            <div>
              <dt className="text-slate-500">Version</dt>
              <dd className="mt-0.5 truncate font-mono text-[10px] text-slate-300" title={prediction.model_version ?? undefined}>
                {prediction.model_version ?? "—"}
              </dd>
            </div>
            <div>
              <dt className="text-slate-500">Explanation</dt>
              <dd className="mt-0.5 flex items-center gap-1 font-medium text-slate-200">
                {prediction.shap_available ? (
                  <>
                    <CheckCircle2 className="h-3 w-3 text-emerald-300" aria-hidden="true" />
                    SHAP
                  </>
                ) : (
                  <>
                    <Info className="h-3 w-3 text-amber-300" aria-hidden="true" />
                    {prediction.explanation_status ?? "unavailable"}
                  </>
                )}
              </dd>
            </div>
            <div>
              <dt className="text-slate-500">Thresholds</dt>
              <dd className="mt-0.5 font-mono text-[10px] text-slate-300">
                &lt;{thresholds.low_max} Low · ≥{thresholds.high_min} High
              </dd>
            </div>
          </dl>
        </div>
      </div>

      <p className="mt-5 rounded-lg border border-white/10 bg-white/[0.02] p-3 text-[11px] leading-relaxed text-slate-400">
        {prediction.score_interpretation}
        {prediction.model_output_note ? ` ${prediction.model_output_note}` : ""}
      </p>

      {completeness ? (
        <div className="mt-4 grid grid-cols-2 gap-2 text-[11px] sm:grid-cols-4">
          {Object.entries(completeness)
            .filter(([key]) => key !== "overall")
            .map(([key, value]) => (
              <div key={key} className="rounded-lg border border-white/[0.07] bg-white/[0.02] p-2">
                <p className="text-[9px] uppercase tracking-wider text-slate-500">{key.replace(/_/g, " ")}</p>
                <p className={`mt-1 font-medium ${completenessTone[value] ?? "text-slate-300"}`}>{value}</p>
              </div>
            ))}
        </div>
      ) : null}

      {warnings.length ? (
        <details className="group mt-4 rounded-lg border border-amber-400/15 bg-amber-400/[0.04] p-3">
          <summary className="flex cursor-pointer list-none items-center gap-2 text-[11px] font-medium text-amber-200">
            <AlertTriangle className="h-3.5 w-3.5" aria-hidden="true" />
            {warnings.length} analysis warning{warnings.length === 1 ? "" : "s"}
            <span className="ml-auto text-[10px] text-amber-200/60 group-open:hidden">show</span>
          </summary>
          <ul className="mt-2 space-y-1.5">
            {warnings.map((warning) => (
              <li key={warning} className="text-[11px] leading-relaxed text-amber-100/75">
                {warning}
              </li>
            ))}
          </ul>
        </details>
      ) : null}

      <div className="mt-auto pt-4 text-[10px] text-slate-500">
        {timings ? (
          <p className="flex flex-wrap gap-x-3 gap-y-1">
            <span>total {formatDuration(timings.total ?? 0)}</span>
            <span>fetch {formatDuration(timings.github_fetch ?? 0)}</span>
            <span>features {formatDuration(timings.feature_extraction ?? 0)}</span>
            <span>diff {formatDuration(timings.diff_analysis ?? 0)}</span>
          </p>
        ) : (
          <p>{modelInfo?.reason ? modelInfo.reason : "Manual feature prediction"}</p>
        )}
      </div>
    </section>
  );
}
