import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { DISCLAIMER } from "../lib/format";
import MethodologyPanel from "./MethodologyPanel";

describe("MethodologyPanel", () => {
  it("states that evaluation is pending when no model artifact exists", () => {
    render(<MethodologyPanel modelInfo={null} backendOnline />);

    expect(screen.getByText(/Evaluation pending — no trained model deployed/i)).toBeInTheDocument();
    expect(screen.getByText(/Placeholder metrics are never substituted/i)).toBeInTheDocument();
    expect(screen.getByText(DISCLAIMER)).toBeInTheDocument();
  });

  it("distinguishes an unreachable backend from a missing model", () => {
    render(<MethodologyPanel modelInfo={null} backendOnline={false} />);

    expect(screen.getByText(/The backend does not respond/i)).toBeInTheDocument();
    expect(screen.queryByText(/no trained model deployed/i)).not.toBeInTheDocument();
  });

  it("shows the six-feature contract", () => {
    render(<MethodologyPanel modelInfo={null} backendOnline />);

    for (const name of [
      "files_changed",
      "lines_added",
      "lines_deleted",
      "previous_author_commits",
      "prior_bug_fixes_in_touched_files",
      "commit_hour",
    ]) {
      expect(screen.getByText(name)).toBeInTheDocument();
    }
  });
});
