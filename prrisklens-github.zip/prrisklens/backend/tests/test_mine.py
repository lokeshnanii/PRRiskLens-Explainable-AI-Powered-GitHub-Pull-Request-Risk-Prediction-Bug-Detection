"""Regression tests for mining resume and per-repository limit semantics."""

from __future__ import annotations

import csv
from pathlib import Path

import pydriller
import pytest

import mine


class FakeCommit:
    def __init__(self, sha: str) -> None:
        self.hash = sha
        self.merge = False
        self.author_date = None


class FakeRepository:
    commits: list[FakeCommit] = []

    def __init__(self, path_to_repo: str) -> None:
        self.path_to_repo = path_to_repo

    def traverse_commits(self):
        return list(self.commits)


def _row(sha: str, repo: str = "fixture/repo") -> dict[str, str]:
    row = {name: "" for name in mine.COLUMNS}
    row.update({"repo": repo, "sha": sha})
    return row


def _write_rows(path: Path, rows: list[dict[str, str]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=mine.COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


@pytest.fixture
def mining_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    FakeRepository.commits = [FakeCommit("9" * 40)]
    monkeypatch.setattr(pydriller, "Repository", FakeRepository)
    monkeypatch.setattr(
        mine, "ensure_clone", lambda slug, clone_dir, **kwargs: tmp_path / "clone"
    )
    monkeypatch.setattr(mine, "_commit_row", lambda repo, commit: _row(commit.hash))
    return tmp_path


def _run(tmp_path: Path, out: Path, *, limit: int | None, resume: bool):
    return mine.mine_repos(
        ["fixture/repo"],
        out_path=out,
        errors_path=tmp_path / "errors.csv",
        status_path=tmp_path / "status.json",
        clone_dir=tmp_path / "repos",
        limit=limit,
        since=None,
        resume=resume,
        mode="pilot",
    )


def test_resume_stops_when_existing_rows_reach_limit(mining_env: Path) -> None:
    out = mining_env / "raw.csv"
    _write_rows(out, [_row("1" * 40), _row("2" * 40), _row("3" * 40)])
    FakeRepository.commits = [FakeCommit("4" * 40)]

    status = _run(mining_env, out, limit=3, resume=True)

    rows = list(csv.DictReader(out.open(newline="", encoding="utf-8")))
    assert [row["sha"] for row in rows] == ["1" * 40, "2" * 40, "3" * 40]
    repo_status = status["repos"][0]
    assert repo_status["skipped_existing_limit"] is True
    assert repo_status["truncated_by_limit"] is True
    assert repo_status["rows_written"] == 0
    assert status["total_rows_written"] == 0


def test_resume_writes_only_up_to_remaining_limit(mining_env: Path) -> None:
    out = mining_env / "raw.csv"
    _write_rows(out, [_row("1" * 40), _row("2" * 40)])
    FakeRepository.commits = [FakeCommit("2" * 40), FakeCommit("3" * 40), FakeCommit("4" * 40)]

    status = _run(mining_env, out, limit=3, resume=True)

    rows = list(csv.DictReader(out.open(newline="", encoding="utf-8")))
    assert [row["sha"] for row in rows] == ["1" * 40, "2" * 40, "3" * 40]
    repo_status = status["repos"][0]
    assert repo_status["existing_rows"] == 2
    assert repo_status["rows_written"] == 1
    assert repo_status["skipped_resume"] == 1
    assert repo_status["truncated_by_limit"] is True


def test_no_resume_truncates_existing_output(mining_env: Path) -> None:
    out = mining_env / "raw.csv"
    _write_rows(out, [_row("1" * 40), _row("2" * 40)])

    _run(mining_env, out, limit=None, resume=False)

    rows = list(csv.DictReader(out.open(newline="", encoding="utf-8")))
    assert [row["sha"] for row in rows] == ["9" * 40]
