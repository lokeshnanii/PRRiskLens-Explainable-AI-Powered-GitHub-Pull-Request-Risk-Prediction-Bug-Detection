import { useState } from "react";
import { AlertTriangle, ChevronDown, Diff, FileCode2, Files } from "lucide-react";
import type { ChangedFile, Change, Severity } from "../types/analysis";
import { SEVERITY_TONE, formatNumber, titleCase } from "../lib/format";

interface ChangedFilesProps {
  change: Change;
  files: ChangedFile[];
}

const FILE_STATUS_TONE: Record<string, string> = {
  added: "border-emerald-400/30 bg-emerald-400/10 text-emerald-200",
  removed: "border-rose-400/30 bg-rose-400/10 text-rose-200",
  modified: "border-sky-400/30 bg-sky-400/10 text-sky-200",
  renamed: "border-violet-400/30 bg-violet-400/10 text-violet-200",
  copied: "border-aqua-400/30 bg-aqua-400/10 text-aqua-200",
};

type LineKind = "add" | "del" | "hunk" | "meta" | "context";

const LINE_TONE: Record<LineKind, string> = {
  add: "bg-emerald-500/[0.08] text-emerald-200",
  del: "bg-rose-500/[0.08] text-rose-200",
  hunk: "bg-sky-500/[0.07] text-sky-300",
  meta: "text-slate-500",
  context: "text-slate-400",
};

function classify(line: string): LineKind {
  if (line.startsWith("@@")) return "hunk";
  if (line.startsWith("+++") || line.startsWith("---")) return "meta";
  if (line.startsWith("+")) return "add";
  if (line.startsWith("-")) return "del";
  return "context";
}

const PATCH_LINE_LIMIT = 400;

function PatchView({ patch, truncated }: { patch: string; truncated: boolean }) {
  const [showAll, setShowAll] = useState(false);
  const lines = patch.split("\n");
  const visible = showAll ? lines : lines.slice(0, PATCH_LINE_LIMIT);
  const hidden = lines.length - visible.length;

  return (
    <div>
      <pre className="code-surface max-h-[28rem] whitespace-pre p-3 text-[11px]" tabIndex={0} aria-label="Unified diff patch">
        <code>
          {visible.map((line, index) => (
            <span key={index} className={`block px-1 ${LINE_TONE[classify(line)]}`}>
              {line || " "}
            </span>
          ))}
        </code>
      </pre>
      {hidden > 0 ? (
        <button type="button" onClick={() => setShowAll(true)} className="mt-2 text-[11px] font-medium text-brand-300 hover:text-brand-200">
          Show {formatNumber(hidden)} more patch lines
        </button>
      ) : null}
      {truncated ? (
        <p className="mt-2 flex items-start gap-1.5 text-[10.5px] leading-relaxed text-amber-200/80">
          <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0" aria-hidden="true" />
          The backend truncated this patch at its character limit, so line-level analysis may not cover it fully.
        </p>
      ) : null}
    </div>
  );
}

function FileRow({ file }: { file: ChangedFile }) {
  const tone = FILE_STATUS_TONE[file.status] ?? "border-white/10 bg-white/[0.04] text-slate-300";
  const riskTone = file.risk_indicator !== "none" ? SEVERITY_TONE[file.risk_indicator as Severity] : null;

  return (
    <details className="group rounded-xl border border-white/[0.07] bg-white/[0.018] transition open:border-white/15 open:bg-white/[0.028]">
      <summary className="flex cursor-pointer list-none flex-wrap items-center gap-x-3 gap-y-2 p-3">
        <span className={`rounded-md border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${tone}`}>
          {titleCase(file.status)}
        </span>
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-1.5 truncate font-mono text-[12px] text-slate-200">
            <FileCode2 className="h-3.5 w-3.5 shrink-0 text-slate-500" aria-hidden="true" />
            {file.filename}
          </span>
          {file.previous_filename ? (
            <span className="mt-0.5 block truncate font-mono text-[10px] text-slate-500">
              renamed from {file.previous_filename}
            </span>
          ) : null}
        </span>
        <span className="flex shrink-0 items-center gap-2 font-mono text-[10px]">
          <span className="text-emerald-300">+{formatNumber(file.additions)}</span>
          <span className="text-rose-300">−{formatNumber(file.deletions)}</span>
        </span>
        {file.findings_count > 0 ? (
          <span className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[9.5px] font-medium ${riskTone?.chip ?? ""}`}>
            <span className={`h-1.5 w-1.5 rounded-full ${riskTone?.dot ?? "bg-slate-400"}`} aria-hidden="true" />
            {file.findings_count} finding{file.findings_count === 1 ? "" : "s"}
          </span>
        ) : null}
        <ChevronDown className="h-3.5 w-3.5 shrink-0 text-slate-500 transition group-open:rotate-180" aria-hidden="true" />
      </summary>
      <div className="border-t border-white/[0.06] p-3">
        {file.patch ? (
          <PatchView patch={file.patch} truncated={file.patch_truncated} />
        ) : (
          <p className="flex items-start gap-2 rounded-lg border border-dashed border-white/10 bg-white/[0.015] p-3 text-[11px] leading-relaxed text-slate-400">
            <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-300" aria-hidden="true" />
            No textual patch was returned for this file (binary, oversized or too large), so line-level
            findings cannot cover it. The size statistics still count toward the six model features.
          </p>
        )}
      </div>
    </details>
  );
}

export default function ChangedFiles({ change, files }: ChangedFilesProps) {
  const filesWithFindings = files.filter((file) => file.findings_count > 0).length;
  const missingPatches = files.filter((file) => !file.patch_available).length;

  return (
    <section className="glass-panel p-5 sm:p-6" aria-labelledby="changed-files-title">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 id="changed-files-title" className="flex items-center gap-2 text-base font-semibold text-white">
            <Files className="h-4 w-4 text-aqua-400" aria-hidden="true" />
            Changed files
          </h2>
          <p className="mt-1 max-w-2xl text-[11.5px] leading-relaxed text-slate-400">
            Real unified diffs from GitHub. Expand a file to inspect the patch; added lines are green,
            removed lines are red.
          </p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <span className="chip">
            <Diff className="h-3 w-3" aria-hidden="true" />
            {formatNumber(files.length)} files · +{formatNumber(change.additions)} −
            {formatNumber(change.deletions)}
          </span>
          <span className="chip">{filesWithFindings} with findings</span>
          {missingPatches ? (
            <span className="chip !border-amber-400/25 !text-amber-200">{missingPatches} without patch</span>
          ) : null}
        </div>
      </div>

      {change.files_truncated ? (
        <p className="mt-4 rounded-lg border border-amber-400/20 bg-amber-400/[0.05] p-3 text-[11px] leading-relaxed text-amber-100/80">
          GitHub returned a truncated file list, so some changed files are not shown or analyzed.
        </p>
      ) : null}

      {files.length ? (
        <div className="mt-4 space-y-2">
          {files.map((file) => (
            <FileRow key={`${file.filename}-${file.status}`} file={file} />
          ))}
        </div>
      ) : (
        <p className="mt-4 rounded-lg border border-dashed border-white/10 p-6 text-center text-[12px] text-slate-400">
          GitHub reported no changed files for this change.
        </p>
      )}
    </section>
  );
}
