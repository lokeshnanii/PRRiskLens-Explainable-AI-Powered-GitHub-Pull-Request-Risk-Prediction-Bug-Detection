import type {
  AnalysisResponse,
  ErrorEnvelope,
  FeatureValues,
  GitHubRateLimitResponse,
  HealthResponse,
  ModelInfoResponse,
  Prediction,
} from "../types/analysis";

const DEFAULT_BASE = "http://localhost:8000";

export const API_BASE = (import.meta.env.VITE_API_BASE_URL || DEFAULT_BASE).replace(/\/+$/, "");

export class ApiError extends Error {
  readonly code: string;
  readonly status: number;
  readonly details: Record<string, unknown>;

  constructor(code: string, message: string, status = 0, details: Record<string, unknown> = {}) {
    super(message);
    this.name = "ApiError";
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

interface RequestOptions {
  method?: "GET" | "POST";
  body?: unknown;
  timeoutMs?: number;
}

function isErrorEnvelope(value: unknown): value is ErrorEnvelope {
  if (!value || typeof value !== "object") return false;
  const candidate = (value as { error?: unknown }).error;
  return Boolean(candidate && typeof candidate === "object" && "message" in candidate);
}

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = "GET", body, timeoutMs = 20_000 } = options;
  const controller = new AbortController();
  let timedOut = false;
  const timer = window.setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      method,
      headers: {
        Accept: "application/json",
        ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
      credentials: "omit",
    });
  } catch (error) {
    if (timedOut) {
      throw new ApiError(
        "request_timeout",
        "The analysis request timed out. Try a smaller pull request or check that the backend is healthy.",
      );
    }
    throw new ApiError(
      "network_error",
      `Could not reach the PRRiskLens API at ${API_BASE}. Check that the FastAPI backend is running.`,
    );
  } finally {
    window.clearTimeout(timer);
  }

  const text = await response.text();
  let payload: unknown = null;
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = null;
    }
  }

  if (!response.ok) {
    if (isErrorEnvelope(payload)) {
      throw new ApiError(
        payload.error.code || "api_error",
        payload.error.message || `Request failed with status ${response.status}.`,
        response.status,
        payload.error.details ?? {},
      );
    }
    throw new ApiError(
      "api_error",
      `The API returned an unexpected ${response.status} response.`,
      response.status,
    );
  }

  if (payload === null) {
    throw new ApiError("invalid_response", "The API returned an empty or non-JSON response.", response.status);
  }
  return payload as T;
}

export const api = {
  health(): Promise<HealthResponse> {
    return request<HealthResponse>("/health", { timeoutMs: 8_000 });
  },

  modelInfo(): Promise<ModelInfoResponse> {
    return request<ModelInfoResponse>("/model-info", { timeoutMs: 12_000 });
  },

  rateLimit(): Promise<GitHubRateLimitResponse> {
    return request<GitHubRateLimitResponse>("/github-rate-limit", { timeoutMs: 12_000 });
  },

  predict(features: FeatureValues): Promise<Prediction> {
    return request<Prediction>("/predict", {
      method: "POST",
      body: features,
      timeoutMs: 30_000,
    });
  },

  analyzeUrl(url: string): Promise<AnalysisResponse> {
    return request<AnalysisResponse>("/predict_url", {
      method: "POST",
      body: { url },
      timeoutMs: 120_000,
    });
  },
};
