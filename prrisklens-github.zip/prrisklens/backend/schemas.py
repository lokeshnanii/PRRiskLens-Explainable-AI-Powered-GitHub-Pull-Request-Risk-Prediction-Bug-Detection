"""Pydantic request/response contracts for the public API."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class FeatureRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    files_changed: int = Field(strict=True, ge=0, le=10_000_000)
    lines_added: int = Field(strict=True, ge=0, le=10_000_000)
    lines_deleted: int = Field(strict=True, ge=0, le=10_000_000)
    previous_author_commits: int = Field(strict=True, ge=0, le=10_000_000)
    prior_bug_fixes_in_touched_files: int = Field(strict=True, ge=0, le=10_000_000)
    commit_hour: int = Field(strict=True, ge=0, le=23)


class PredictUrlRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    url: str = Field(min_length=1, max_length=500)


class Thresholds(BaseModel):
    low_max: float
    high_min: float


class RiskFactor(BaseModel):
    model_config = ConfigDict(extra="allow")

    feature: str
    label: str
    value: int
    contribution: float
    direction: str
    explanation: str
    contribution_note: str | None = None


class Prediction(BaseModel):
    model_config = ConfigDict(extra="allow")

    status: Literal["ok", "unavailable"]
    risk_score: float | None = None
    risk_category: Literal["Low", "Medium", "High"] | None = None
    model_version: str | None = None
    model_type: str | None = None
    model_output: float | None = None
    model_output_note: str | None = None
    input_features: dict[str, int] | None = None
    feature_order: list[str] | None = None
    factors: list[RiskFactor] = Field(default_factory=list)
    all_contributions: list[RiskFactor] = Field(default_factory=list)
    base_value: float | None = None
    shap_available: bool = False
    explanation_status: str = "unavailable"
    explanation_method: str | None = None
    explanation_note: str | None = None
    explanation_error: str | None = None
    contribution_scale: str | None = None
    thresholds: Thresholds
    score_interpretation: str
    warnings: list[str] = Field(default_factory=list)
    message: str | None = None
    reason: str | None = None
    model_training_required: bool | None = None


class AnalysisResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    analysis_id: str
    generated_at: str
    source: dict[str, Any]
    repository: dict[str, Any]
    change: dict[str, Any]
    features: dict[str, Any]
    prediction: Prediction
    code_analysis: dict[str, Any]
    changed_files: list[dict[str, Any]]
    review_checklist: list[dict[str, Any]]
    warnings: list[str]
    data_completeness: dict[str, Any]
    thresholds: Thresholds
    model_info: dict[str, Any]
    github: dict[str, Any] | None = None
    timings_ms: dict[str, float]


class GitHubAuthInfo(BaseModel):
    authenticated: bool
    mode: Literal["authenticated", "unauthenticated"]
    token_configured: bool
    expected_hourly_limit: int
    note: str | None = None


class GitHubRateLimitSnapshot(BaseModel):
    authenticated: bool
    mode: str
    resource: str | None = None
    limit: int | None = None
    remaining: int | None = None
    used: int | None = None
    reset_at: str | None = None
    observed_at: str | None = None
    source: str | None = None
    near_limit: bool = False


class GitHubRateLimitResponse(GitHubAuthInfo):
    rate_limit: GitHubRateLimitSnapshot | None = None
    error: dict[str, Any] | None = None
    time: str


class HealthResponse(BaseModel):
    status: str
    model_available: bool
    model_version: str | None
    model_type: str | None
    feature_schema_version: str
    reason: str | None
    time: str
    github: GitHubAuthInfo | None = None


class ErrorBody(BaseModel):
    code: str
    message: str
    details: dict[str, Any] = Field(default_factory=dict)


class ErrorResponse(BaseModel):
    error: ErrorBody
