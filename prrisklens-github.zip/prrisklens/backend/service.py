"""End-to-end analysis orchestration for URL-based pull request/commit review."""

from __future__ import annotations

import json
import logging
import time
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Callable, Mapping

from analysis import CodeAnalysis, Finding, SEVERITY_ORDER, analyze_changes
from config import Settings
from core import (
    FEATURE_DESCRIPTIONS,
    FEATURE_LABELS,
    FEATURES,
    SCORE_INTERPRETATION,
)
from features import extract_features
from gh import ChangeSnapshot, GitHubClient, GitHubError, parse_github_url
from inference import ModelRegistry, predict_with_bundle

logger = logging.getLogger("prrisklens.service")


def _snapshot_dict(client: Any) -> dict[str, Any] | None:
    """Read a client's last rate-limit snapshot without requiring one."""

    getter = getattr(client, "rate_limit", None)
    if not callable(getter):
        return None
    try:
        snapshot = getter()
    except Exception:  # never let quota reporting break an analysis
        logger.debug("GitHub rate-limit snapshot unavailable", exc_info=True)
        return None
    to_dict = getattr(snapshot, "to_dict", None)
    return to_dict() if callable(to_dict) else None


class ModelUnavailableError(RuntimeError):
    """Raised when a prediction is requested without a usable model artifact."""


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class AnalysisService:
    def __init__(
        self,
        settings: Settings,
        *,
        client_factory: Callable[[], GitHubClient] | None = None,
        registry: ModelRegistry | None = None,
    ) -> None:
        self.settings = settings
        self.registry = registry or ModelRegistry(settings.models_dir)
        self._client_factory = client_factory or self._default_client

    def _default_client(self) -> GitHubClient:
        return GitHubClient(
            token=self.settings.github_token,
            api_url=self.settings.github_api_url,
            timeout=self.settings.request_timeout_seconds,
            max_files=self.settings.max_files,
            max_commits=250,
        )

    # -- GitHub authentication / quota ------------------------------------

    def github_auth_info(self) -> dict[str, Any]:
        authenticated = self.settings.github_authenticated
        return {
            "authenticated": authenticated,
            "mode": self.settings.github_auth_mode,
            "token_configured": authenticated,
            "expected_hourly_limit": self.settings.github_expected_hourly_limit,
            "note": (
                "Authenticated GitHub requests use the backend token. The token is "
                "never sent to the browser."
                if authenticated
                else "No GITHUB_TOKEN is configured. GitHub allows 60 requests per hour "
                "for unauthenticated requests; set GITHUB_TOKEN in the backend .env to "
                "use 5,000 per hour."
            ),
        }

    def github_rate_limit(self) -> dict[str, Any]:
        """Live GitHub primary-rate-limit status for the dashboard."""

        info = self.github_auth_info()
        client = self._client_factory()
        rate_limit = _snapshot_dict(client)
        error: dict[str, Any] | None = None
        fetch = getattr(client, "fetch_rate_limit", None)
        try:
            if callable(fetch):
                fetched = fetch()
                to_dict = getattr(fetched, "to_dict", None)
                if callable(to_dict):
                    rate_limit = to_dict()
            if rate_limit is None:
                error = {
                    "code": "github_rate_limit_unavailable",
                    "message": "GitHub did not report rate-limit information.",
                    "details": {},
                }
        except GitHubError as exc:
            rate_limit = _snapshot_dict(client)
            error = {
                "code": exc.code,
                "message": exc.message,
                "details": dict(exc.details),
            }
        except Exception:
            logger.exception("Could not read GitHub rate limit")
            error = {
                "code": "github_rate_limit_unavailable",
                "message": "Could not read the GitHub rate limit.",
                "details": {},
            }
        return {**info, "rate_limit": rate_limit, "error": error, "time": _iso_now()}

    # -- manual feature prediction ---------------------------------------

    def predict_features(self, values: Mapping[str, Any]) -> dict[str, Any]:
        bundle = self.registry.get()
        if bundle is None:
            reason = self.registry.status()["reason"] or "No trained model is available."
            raise ModelUnavailableError(
                f"{reason} Train the model with backend/train.py before requesting predictions."
            )
        return predict_with_bundle(
            bundle,
            values,
            low_threshold=self.settings.low_risk_threshold,
            high_threshold=self.settings.high_risk_threshold,
        )

    # -- URL analysis -----------------------------------------------------

    def analyze_url(self, url: str) -> dict[str, Any]:
        started = time.perf_counter()
        ref = parse_github_url(url)
        client = self._client_factory()

        snapshot = client.fetch(ref)
        after_fetch = time.perf_counter()

        extraction = extract_features(client, snapshot, self.settings)
        after_features = time.perf_counter()

        bundle = self.registry.get()
        if bundle is not None:
            prediction = predict_with_bundle(
                bundle,
                extraction.values,
                low_threshold=self.settings.low_risk_threshold,
                high_threshold=self.settings.high_risk_threshold,
            )
        else:
            reason = self.registry.status()["reason"] or "No trained model is available."
            prediction = {
                "status": "unavailable",
                "message": (
                    "No trained risk model is available, so no score was produced. "
                    "The code findings below come from the real diff."
                ),
                "reason": reason,
                "model_training_required": True,
                "factors": [],
                "all_contributions": [],
                "shap_available": False,
                "explanation_status": "unavailable",
                "explanation_note": None,
                "explanation_error": None,
                "score_interpretation": SCORE_INTERPRETATION,
                "thresholds": self.settings.risk_thresholds,
                "warnings": [reason],
            }
        after_model = time.perf_counter()

        code = analyze_changes(snapshot.files)
        after_code = time.perf_counter()

        snapshot_dict = snapshot.to_dict(self.settings.max_patch_chars)
        repository = snapshot_dict.pop("repository")
        raw_files = snapshot_dict.pop("files")
        snapshot_warnings = snapshot_dict.pop("warnings", [])
        change = snapshot_dict

        findings_by_file: dict[str, list[Finding]] = defaultdict(list)
        for finding in code.findings:
            findings_by_file[finding.file].append(finding)
        changed_files = []
        for item in raw_files:
            related = findings_by_file.get(item["filename"], [])
            severity = None
            for finding in related:
                if severity is None or SEVERITY_ORDER[finding.severity] < SEVERITY_ORDER[severity]:
                    severity = finding.severity
            enriched = dict(item)
            enriched["findings_count"] = len(related)
            enriched["risk_indicator"] = severity or "none"
            changed_files.append(enriched)

        checklist = self._build_checklist(snapshot, code, extraction, prediction, bundle)
        warnings = list(
            dict.fromkeys(
                [
                    *snapshot_warnings,
                    *extraction.warnings,
                    *( [code.message] if code.message and code.status != "complete" else [] ),
                    *prediction.get("warnings", []),
                ]
            )
        )

        after_checklist = time.perf_counter()
        completeness = {
            "features": extraction.overall_completeness,
            "diff": "complete" if not snapshot.files_truncated else "partial",
            "code_analysis": code.status,
            "prediction": "available" if prediction.get("status") == "ok" else "unavailable",
        }
        if prediction.get("status") != "ok" or code.status != "complete":
            completeness["overall"] = "partial"
        elif extraction.overall_completeness != "complete":
            completeness["overall"] = "partial"
        else:
            completeness["overall"] = "complete"

        model_status = self.registry.status()
        result = {
            "analysis_id": uuid.uuid4().hex,
            "generated_at": _iso_now(),
            "source": ref.to_dict(),
            "repository": repository,
            "change": change,
            "features": extraction.to_dict(),
            "prediction": prediction,
            "code_analysis": code.to_dict(),
            "changed_files": changed_files,
            "review_checklist": checklist,
            "warnings": warnings,
            "data_completeness": completeness,
            "thresholds": self.settings.risk_thresholds,
            "model_info": {
                "available": model_status["model_available"],
                "model_version": model_status["model_version"],
                "model_type": model_status["model_type"],
                "reason": model_status["reason"],
                "thresholds": self.settings.risk_thresholds,
            },
            "github": {**self.github_auth_info(), "rate_limit": _snapshot_dict(client)},
            "timings_ms": {
                "github_fetch": round((after_fetch - started) * 1000, 1),
                "feature_extraction": round((after_features - after_fetch) * 1000, 1),
                "prediction_and_shap": round((after_model - after_features) * 1000, 1),
                "diff_analysis": round((after_code - after_model) * 1000, 1),
                "response_assembly": round((after_checklist - after_code) * 1000, 1),
                "total": round((after_checklist - started) * 1000, 1),
            },
        }
        logger.info(
            "Analyzed %s (%s/%s): %d findings, prediction=%s",
            ref.canonical_url,
            ref.owner,
            ref.repo,
            len(code.findings),
            prediction.get("status"),
        )
        return result

    # -- model information ------------------------------------------------

    def model_info(self) -> dict[str, Any]:
        bundle = self.registry.get()
        status = self.registry.status()
        metadata = bundle.metadata if bundle else {}
        results_path = self.settings.models_dir / "results.json"
        results_status = None
        if results_path.exists():
            try:
                results_status = json.loads(results_path.read_text(encoding="utf-8")).get("status")
            except (ValueError, OSError):
                results_status = "unreadable"
        return {
            "available": bundle is not None,
            "model_type": status["model_type"],
            "model_version": status["model_version"],
            "feature_schema_version": status["feature_schema_version"],
            "features": [
                {
                    "name": name,
                    "label": FEATURE_LABELS[name],
                    "description": FEATURE_DESCRIPTIONS[name],
                }
                for name in FEATURES
            ],
            "thresholds": self.settings.risk_thresholds,
            "score_interpretation": SCORE_INTERPRETATION,
            "training": metadata.get("dataset"),
            "training_config": metadata.get("training_config"),
            "metrics": metadata.get("metrics"),
            "all_metrics": metadata.get("all_metrics"),
            "training_metadata": {
                "trained_at": metadata.get("trained_at"),
                "versions": metadata.get("versions"),
                "selection_reason": metadata.get("selection_reason"),
            },
            "explanation": metadata.get("explanation")
            or {
                "available": False,
                "reason": "No model metadata is available." if bundle is None else "Not recorded.",
            },
            "evaluation": {
                "results_available": results_path.exists(),
                "status": results_status,
            },
            "reason": status["reason"],
            "training_required": bundle is None,
        }

    # -- review checklist -------------------------------------------------

    def _build_checklist(
        self,
        snapshot: ChangeSnapshot,
        code: CodeAnalysis,
        extraction: Any,
        prediction: Mapping[str, Any],
        bundle: Any,
    ) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        seen: set[str] = set()

        def add(
            item_id: str,
            title: str,
            rationale: str,
            priority: str,
            files: list[str] | None = None,
        ) -> None:
            if item_id in seen:
                return
            seen.add(item_id)
            items.append(
                {
                    "id": item_id,
                    "title": title,
                    "rationale": rationale,
                    "priority": priority,
                    "files": (files or [])[:5],
                }
            )

        by_detector: dict[str, list[Finding]] = defaultdict(list)
        for finding in code.findings:
            by_detector[finding.detector].append(finding)

        def evidence(detector: str) -> tuple[list[str], str]:
            findings = by_detector.get(detector, [])
            files = sorted({finding.file for finding in findings})
            priority = "low"
            for finding in findings:
                if SEVERITY_ORDER[finding.severity] < SEVERITY_ORDER[priority]:
                    priority = finding.severity
            return files, priority

        rules = [
            (
                "hardcoded_secret",
                "Rotate any exposed credential before merging",
                "A credential-like literal was added. Confirm whether it is a real secret and rotate it if so.",
            ),
            (
                "sql_injection",
                "Confirm queries are parameterised",
                "A dynamic SQL string was detected. Verify placeholders and parameter tuples are used throughout.",
            ),
            (
                "command_injection",
                "Constrain shell/process execution",
                "Shell execution or dynamic command assembly was added. Check that inputs are trusted or allow-listed.",
            ),
            (
                "removed_validation",
                "Verify validation is still enforced",
                "Validation-like lines were removed. Confirm a caller or schema enforces the same constraints.",
            ),
            (
                "missing_none_handling",
                "Verify optional-value handling",
                "An optional-value guard was removed. Confirm the value cannot be absent at runtime.",
            ),
            (
                "auth_regression",
                "Verify authorization coverage",
                "An authorization check was removed. Confirm middleware or a parent handler still enforces it.",
            ),
            (
                "weakened_tests",
                "Confirm removed or skipped tests are obsolete",
                "Tests or assertions were removed or skipped. Replace the coverage or document why it is unnecessary.",
            ),
            (
                "boundary_change",
                "Add boundary-condition tests",
                "A comparison operator changed. Test the exact boundary value on both sides.",
            ),
            (
                "broad_exception",
                "Review error-handling behavior",
                "A broad exception handler was added. Confirm it logs and does not swallow failures silently.",
            ),
            (
                "unsafe_deserialization",
                "Harden deserialization",
                "A potentially unsafe deserialization call was added. Confirm the payload is trusted and validated.",
            ),
            (
                "risky_resource",
                "Review resource cleanup",
                "Risky file/resource handling was added. Confirm deterministic cleanup and safe temporary files.",
            ),
            (
                "breaking_api_change",
                "Check external API consumers",
                "A public symbol or route changed. Search callers and update documentation/changelog.",
            ),
        ]
        rule_by_detector = {rule[0]: rule for rule in rules}
        for detector, findings in by_detector.items():
            if detector not in rule_by_detector:
                continue
            _, title, rationale = rule_by_detector[detector]
            files, priority = evidence(detector)
            add(detector, title, rationale, priority, files)

        checks = snapshot.checks.to_dict() if snapshot.checks else None
        if checks and checks.get("conclusions"):
            failing = sum(
                count
                for conclusion, count in checks["conclusions"].items()
                if conclusion in {"failure", "timed_out", "cancelled", "action_required", "startup_failure"}
            )
            if failing or checks.get("status_state") in {"failure", "error"}:
                add(
                    "failing_checks",
                    "Review failing CI checks",
                    "GitHub reports failing or incomplete checks for this change.",
                    "high",
                )

        if snapshot.files_truncated or snapshot.patches_missing:
            unpatched = [file.filename for file in snapshot.files if file.patch is None][:5]
            add(
                "incomplete_diff",
                "Inspect files without textual patches",
                (
                    "Some files were truncated or had no patch (binary/oversized), so line-level "
                    "analysis does not cover them. Configure GITHUB_TOKEN to raise limits."
                ),
                "medium",
                unpatched,
            )

        if extraction.overall_completeness != "complete":
            add(
                "history_context",
                "Confirm historical context",
                (
                    "Some historical features are partial because of bounded GitHub history windows "
                    "or incomplete author metadata. Treat the risk ranking with extra caution."
                ),
                "medium",
            )

        if code.status != "complete":
            add(
                "diff_coverage",
                "Review changed files manually",
                "Line-level findings could not cover every changed file; inspect the displayed patches.",
                "medium",
            )

        if prediction.get("status") != "ok":
            add(
                "model_missing",
                "Train the model to enable risk scoring",
                "No trained model artifact is available, so only deterministic code findings are shown.",
                "medium",
            )

        if not items:
            add(
                "manual_review",
                "Review the changed files manually",
                "No rule-based finding matched. This does not mean the change is safe.",
                "low",
            )
        return items
