export type RiskCategory = "Low" | "Medium" | "High";
export type Severity = "high" | "medium" | "low" | "info";
export type PredictionStatus = "ok" | "unavailable";
export type ChangeKind = "pull" | "commit";

export interface Thresholds {
  low_max: number;
  high_min: number;
}

export interface GitHubAuthInfo {
  authenticated: boolean;
  mode: "authenticated" | "unauthenticated";
  token_configured: boolean;
  expected_hourly_limit: number;
  note?: string | null;
}

export interface GitHubRateLimitSnapshot {
  authenticated: boolean;
  mode: "authenticated" | "unauthenticated" | string;
  resource?: string | null;
  limit: number | null;
  remaining: number | null;
  used: number | null;
  reset_at: string | null;
  observed_at?: string | null;
  source?: string | null;
  near_limit?: boolean;
}

export interface GitHubApiError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}

export interface GitHubRateLimitResponse extends GitHubAuthInfo {
  rate_limit: GitHubRateLimitSnapshot | null;
  error: GitHubApiError | null;
  time: string;
}

export interface GitHubAnalysisInfo extends GitHubAuthInfo {
  rate_limit: GitHubRateLimitSnapshot | null;
}

export interface HealthResponse {
  status: string;
  model_available: boolean;
  model_version: string | null;
  model_type: string | null;
  feature_schema_version: string;
  reason: string | null;
  time: string;
  github?: GitHubAuthInfo | null;
}

export interface RiskFactor {
  feature: string;
  label: string;
  value: number;
  contribution: number;
  direction: "raises" | "lowers" | "neutral" | string;
  explanation: string;
  contribution_note?: string | null;
}

export interface Prediction {
  status: PredictionStatus;
  risk_score?: number | null;
  risk_category?: RiskCategory | null;
  model_version?: string | null;
  model_type?: string | null;
  model_output?: number | null;
  model_output_note?: string | null;
  input_features?: Record<string, number> | null;
  feature_order?: string[] | null;
  factors?: RiskFactor[];
  all_contributions?: RiskFactor[];
  base_value?: number | null;
  shap_available?: boolean;
  explanation_status?: string;
  explanation_method?: string | null;
  explanation_note?: string | null;
  explanation_error?: string | null;
  contribution_scale?: string | null;
  thresholds?: Thresholds;
  score_interpretation?: string;
  warnings?: string[];
  message?: string | null;
  reason?: string | null;
  model_training_required?: boolean | null;
  [key: string]: unknown;
}

export interface Source {
  kind: ChangeKind;
  owner: string;
  repo: string;
  number: number | null;
  sha: string | null;
  url: string;
}

export interface Repository {
  owner: string;
  repo: string;
  full_name: string;
  url: string;
}

export interface ReviewSummary {
  total: number;
  states: Record<string, number>;
}

export interface CheckSummary {
  available: boolean;
  check_runs_total: number | null;
  conclusions: Record<string, number>;
  status_state: string | null;
  warnings: string[];
}

export interface CommitMeta {
  sha: string;
  message: string;
  author_name: string | null;
  author_login: string | null;
  authored_at: string | null;
  parents: string[];
}

export interface Change {
  kind: "pull_request" | "commit";
  title: string;
  description: string | null;
  author_login: string | null;
  author_name: string | null;
  sha: string;
  number: number | null;
  state: string | null;
  merged: boolean | null;
  base_sha: string | null;
  parent_shas: string[];
  created_at: string;
  updated_at: string | null;
  additions: number;
  deletions: number;
  files_changed: number;
  reviews: ReviewSummary | null;
  checks: CheckSummary | null;
  commits: CommitMeta[];
  warnings: string[];
  files_truncated: boolean;
  patches_missing: number;
  diff_complete: boolean;
}

export interface FeatureBlock {
  values: Record<string, number>;
  order: string[];
  timezone: string;
  provenance: Record<string, string>;
  completeness: Record<string, string>;
  overall_completeness: "complete" | "partial" | "unavailable";
  aggregation: string;
  history: Record<string, unknown>;
  warnings: string[];
}

export type Verification = "potential" | "unverified" | "tool_confirmed";

export interface Finding {
  id: string;
  detector: string;
  detector_name: string;
  title: string;
  severity: Severity;
  confidence: "high" | "medium" | "low";
  verification: Verification;
  file: string;
  line: number | null;
  line_end: number | null;
  side: "new" | "old";
  evidence: string;
  removed_evidence: string | null;
  explanation: string;
  why_risky: string;
  remediation: string;
  detection_method: string;
}

export interface CodeAnalysis {
  status: "complete" | "partial" | "unavailable";
  findings: Finding[];
  summary: {
    total: number;
    by_severity: Record<string, number>;
    by_detector: Record<string, number>;
    files_with_findings: number;
    detectors_run: number;
  };
  coverage: {
    files_received: number;
    files_with_patch: number;
    files_without_patch: string[];
    parse_errors: { file: string; reason: string }[];
    files_analyzed: number;
    files_with_findings: number;
    findings_truncated: boolean;
    verification_note: string;
  };
  message: string | null;
}

export interface ChangedFile {
  filename: string;
  status: string;
  additions: number;
  deletions: number;
  changes: number;
  previous_filename: string | null;
  patch_available: boolean;
  patch: string | null;
  patch_truncated: boolean;
  findings_count: number;
  risk_indicator: Severity | "none";
}

export interface ChecklistItem {
  id: string;
  title: string;
  rationale: string;
  priority: Severity;
  files: string[];
}

export interface DataCompleteness {
  features: string;
  diff: "complete" | "partial";
  code_analysis: string;
  prediction: "available" | "unavailable";
  overall: "complete" | "partial";
}

export interface ModelInfoSummary {
  available: boolean;
  model_version: string | null;
  model_type: string | null;
  reason: string | null;
  thresholds: Thresholds;
}

export interface AnalysisResponse {
  analysis_id: string;
  generated_at: string;
  source: Source;
  repository: Repository;
  change: Change;
  features: FeatureBlock;
  prediction: Prediction;
  code_analysis: CodeAnalysis;
  changed_files: ChangedFile[];
  review_checklist: ChecklistItem[];
  warnings: string[];
  data_completeness: DataCompleteness;
  thresholds: Thresholds;
  model_info: ModelInfoSummary;
  github?: GitHubAnalysisInfo | null;
  timings_ms: Record<string, number>;
}

export interface FeatureDefinition {
  name: string;
  label: string;
  description: string;
}

export interface ModelInfoResponse {
  available: boolean;
  model_type: string | null;
  model_version: string | null;
  feature_schema_version: string;
  features: FeatureDefinition[];
  thresholds: Thresholds;
  score_interpretation: string;
  training: {
    rows?: number;
    positives?: number;
    positive_rate?: number;
    repositories?: string[];
    date_range?: { start: string | null; end: string | null };
    train?: Record<string, unknown>;
    test?: Record<string, unknown>;
    [key: string]: unknown;
  } | null;
  training_config: Record<string, unknown> | null;
  metrics: Record<string, unknown> | null;
  all_metrics: Record<string, unknown> | null;
  training_metadata: {
    trained_at: string | null;
    versions: Record<string, string> | null;
    selection_reason: string | null;
  };
  explanation: {
    available?: boolean;
    method?: string;
    reason?: string;
    [key: string]: unknown;
  };
  evaluation: {
    results_available: boolean;
    status: string | null;
  };
  reason: string | null;
  training_required: boolean;
}

export interface FeatureValues {
  files_changed: number;
  lines_added: number;
  lines_deleted: number;
  previous_author_commits: number;
  prior_bug_fixes_in_touched_files: number;
  commit_hour: number;
}

export interface ErrorEnvelope {
  error: {
    code: string;
    message: string;
    details?: Record<string, unknown>;
  };
}
