import { useMemo, useState } from "react";
import {
  AlertOctagon,
  ChevronDown,
  Code2,
  FileCode2,
  Filter,
  ScanSearch,
  ShieldQuestion,
  Wrench,
} from "lucide-react";
import type { CodeAnalysis, Finding, Severity } from "../types/analysis";
import { SEVERITY_ORDER, SEVERITY_TONE } from "../lib/format";

interface CodeFindingsProps {
  analysis: CodeAnalysis;
}

type FilterValue = "all" | Severity;

const FILTERS: FilterValue[] = ["all", "high", "medium", "low", "info"];

const verificationLabel: Record<Finding["verification"], string> = {
  potential: "Potential",
  unverified: "Unverified",
  tool_confirmed: "Tool confirmed",
};

function FindingCard({ finding }: { finding: Finding }) {
  const tone = SEVERITY_TONE[finding.severity];
  return (
    <details className="group rounded-xl border border-white/[0.07] bg-white/[0.018] transition open:border-white/15 open:bg-white/[0.03]">
      <summary className="flex cursor-pointer list-none flex-col gap-2 p-3.5 sm:flex-row sm:items-center">
        <span className={`inline-flex shrink-0 items-center gap-1.5 rounded-md border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${tone.chip}`}>
          <span className={`h-1.5 w-1.5 rounded-full ${tone.dot}`} aria-hidden="true" />
          {tone.label}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[12.5px] font-medium text-slate-100">{finding.title}</span>
          <span className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 font-mono text-[10px] text-slate-500">
            <span className="inline-flex items-center gap-1">
              <FileCode2 className="h-3 w-3" aria-hidden="true" />
              {finding.file}
              {finding.line !== null ? `:${finding.line}` : ""}
            </span>
            <span>· {finding.side === "old" ? "removed line" : "added line"}</span>
            <span>· {finding.detector_name}</span>
          </span>
        </span>
        <span className="flex shrink-0 items-center gap-1.5">
          <span className="chip !px-2 !py-0.5 !text-[9.5px]">{finding.confidence} confidence</span>
          <span className={`chip !px-2 !py-0.5 !text-[9.5px] ${finding.verification === "potential" ? "!border-violet-400/25 !text-violet-200" : ""}`}>
            {verificationLabel[finding.verification]}
          </span>
          <ChevronDown className="h-3.5 w-3.5 text-slate-500 transition group-open:rotate-180" aria-hidden="true" />
        </span>
      </summary>

      <div className="space-y-3 border-t border-white/[0.06] p-3.5">
        <div>
          <p className="section-label mb-1.5">Evidence from the diff</p>
          <pre className="code-surface whitespace-pre-wrap break-words p-3 text-[11.5px] text-slate-200">
            <code>{finding.evidence}</code>
          </pre>
          {finding.removed_evidence ? (
            <div className="mt-2">
              <p className="section-label mb-1">Replaced / removed line</p>
              <pre className="code-surface whitespace-pre-wrap break-words border-rose-400/15 bg-rose-500/[0.04] p-3 text-[11.5px] text-rose-200/90">
                <code>{finding.removed_evidence}</code>
              </pre>
            </div>
          ) : null}
        </div>

        <div className="grid gap-3 sm:grid-cols-3">
          <div>
            <p className="section-label mb-1">What changed</p>
            <p className="text-[11px] leading-relaxed text-slate-400">{finding.explanation}</p>
          </div>
          <div>
            <p className="section-label mb-1">Why it may be risky</p>
            <p className="text-[11px] leading-relaxed text-slate-400">{finding.why_risky}</p>
          </div>
          <div>
            <p className="section-label mb-1 flex items-center gap-1">
              <Wrench className="h-3 w-3" aria-hidden="true" />
              Suggested remediation
            </p>
            <p className="text-[11px] leading-relaxed text-slate-400">{finding.remediation}</p>
          </div>
        </div>

        <p className="flex items-start gap-1.5 border-t border-white/[0.05] pt-2.5 text-[10px] leading-relaxed text-slate-500">
          <Code2 className="mt-0.5 h-3 w-3 shrink-0" aria-hidden="true" />
          Detection: {finding.detection_method}. This is a pattern match, not a confirmed defect.
        </p>
      </div>
    </details>
  );
}

export default function CodeFindings({ analysis }: CodeFindingsProps) {
  const [filter, setFilter] = useState<FilterValue>("all");
  const counts = useMemo(() => {
    const result: Record<FilterValue, number> = { all: analysis.findings.length, high: 0, medium: 0, low: 0, info: 0 };
    for (const finding of analysis.findings) result[finding.severity] += 1;
    return result;
  }, [analysis.findings]);

  const visible = useMemo(() => {
    const filtered = filter === "all" ? analysis.findings : analysis.findings.filter((item) => item.severity === filter);
    return [...filtered].sort(
      (left, right) =>
        SEVERITY_ORDER[left.severity] - SEVERITY_ORDER[right.severity] ||
        left.file.localeCompare(right.file) ||
        (left.line ?? 0) - (right.line ?? 0),
    );
  }, [analysis.findings, filter]);

  const severitySummary = (["high", "medium", "low", "info"] as Severity[])
    .filter((severity) => counts[severity] > 0)
    .map((severity) => `${counts[severity]} ${severity}`)
    .join(" · ");

  return (
    <section className="glass-panel p-5 sm:p-6" aria-labelledby="code-findings-title">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 id="code-findings-title" className="flex items-center gap-2 text-base font-semibold text-white">
            <ScanSearch className="h-4 w-4 text-aqua-400" aria-hidden="true" />
            Potential code findings
          </h2>
          <p className="mt-1 max-w-2xl text-[11.5px] leading-relaxed text-slate-400">
            Deterministic checks over the actual changed lines. These are separate from the ML ranking
            and are not confirmed bugs.
          </p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <span className="chip">{analysis.summary.total} findings</span>
          {severitySummary ? <span className="chip">{severitySummary}</span> : null}
          <span className={`chip ${analysis.status === "complete" ? "!border-emerald-400/25 !text-emerald-200" : "!border-amber-400/30 !text-amber-200"}`}>
            {analysis.status} coverage
          </span>
        </div>
      </div>

      {analysis.message ? (
        <p className="mt-4 flex items-start gap-2 rounded-lg border border-amber-400/20 bg-amber-400/[0.05] p-3 text-[11px] leading-relaxed text-amber-100/80">
          <AlertOctagon className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          {analysis.message}
        </p>
      ) : null}

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-slate-500">
          <Filter className="h-3 w-3" aria-hidden="true" />
          Severity
        </span>
        <div className="flex flex-wrap gap-1.5" role="group" aria-label="Filter findings by severity">
          {FILTERS.map((value) => (
            <button
              key={value}
              type="button"
              onClick={() => setFilter(value)}
              aria-pressed={filter === value}
              disabled={counts[value] === 0 && value !== "all"}
              className={`rounded-full border px-2.5 py-1 text-[10.5px] font-medium transition disabled:cursor-not-allowed disabled:opacity-35 ${
                filter === value
                  ? "border-brand-400/50 bg-brand-400/15 text-brand-100"
                  : "border-white/10 bg-white/[0.02] text-slate-400 hover:border-white/20 hover:text-slate-200"
              }`}
            >
              {value === "all" ? "All" : SEVERITY_TONE[value].label}
              <span className="ml-1 font-mono text-[9px] opacity-70">{counts[value]}</span>
            </button>
          ))}
        </div>
        <span className="ml-auto text-[10px] text-slate-500">
          {analysis.coverage.files_analyzed}/{analysis.coverage.files_received} files with patches ·{" "}
          {analysis.summary.detectors_run} detectors
        </span>
      </div>

      {visible.length ? (
        <div className="mt-4 space-y-2">
          {visible.map((finding) => (
            <FindingCard key={finding.id} finding={finding} />
          ))}
        </div>
      ) : (
        <div className="mt-5 flex flex-col items-center gap-2 rounded-xl border border-dashed border-white/10 bg-white/[0.015] p-8 text-center">
          <ShieldQuestion className="h-6 w-6 text-slate-500" aria-hidden="true" />
          <p className="text-[12px] font-medium text-slate-300">
            {analysis.status === "unavailable"
              ? "No textual patches were available to analyze."
              : filter === "all"
                ? "No rule-based finding matched this change."
                : `No ${filter} severity findings.`}
          </p>
          <p className="max-w-md text-[11px] leading-relaxed text-slate-500">
            Absence of findings does not mean the change is safe. Review the diff and the historical risk
            signals together.
          </p>
        </div>
      )}

      <p className="mt-4 border-t border-white/[0.06] pt-3 text-[10px] leading-relaxed text-slate-500">
        {analysis.coverage.verification_note} Files without patches:{" "}
        {analysis.coverage.files_without_patch.length}
        {analysis.coverage.findings_truncated ? " · findings truncated to the display limit" : ""}
      </p>
    </section>
  );
}
