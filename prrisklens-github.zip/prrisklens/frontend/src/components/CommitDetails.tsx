import { useState } from "react";
import {
  CalendarClock,
  CheckCircle2,
  ChevronDown,
  CircleSlash,
  ExternalLink,
  GitBranch,
  GitCommitHorizontal,
  GitPullRequest,
  ListChecks,
  MessageSquare,
  ShieldCheck,
  User,
  XCircle,
} from "lucide-react";
import type { Change, Repository, ReviewSummary, CheckSummary, Source } from "../types/analysis";
import { formatDate, formatNumber, shortSha, titleCase } from "../lib/format";

interface CommitDetailsProps {
  change: Change;
  source: Source;
  repository: Repository;
  generatedAt: string;
}

const COMMIT_PREVIEW = 6;

function stateChip(change: Change): { label: string; className: string } {
  if (change.kind === "commit") {
    return { label: "Commit", className: "!border-sky-400/25 !text-sky-200" };
  }
  if (change.merged) return { label: "Merged", className: "!border-violet-400/25 !text-violet-200" };
  if (change.state === "open") return { label: "Open", className: "!border-emerald-400/25 !text-emerald-200" };
  if (change.state === "closed") return { label: "Closed", className: "!border-rose-400/25 !text-rose-200" };
  return { label: titleCase(change.state ?? "Unknown"), className: "" };
}

function MetaRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b border-white/[0.05] py-1.5 last:border-0">
      <dt className="shrink-0 text-[10.5px] uppercase tracking-wider text-slate-500">{label}</dt>
      <dd className="min-w-0 truncate text-right text-[11.5px] text-slate-300">{children}</dd>
    </div>
  );
}

function ReviewsBlock({ reviews }: { reviews: ReviewSummary }) {
  const entries = Object.entries(reviews.states).sort((a, b) => b[1] - a[1]);
  return (
    <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
      <p className="flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-slate-400">
        <MessageSquare className="h-3 w-3" aria-hidden="true" />
        Reviews · {formatNumber(reviews.total)}
      </p>
      {entries.length ? (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {entries.map(([state, count]) => (
            <span key={state} className="rounded-md border border-white/10 bg-white/[0.03] px-2 py-0.5 text-[10px] text-slate-300">
              {titleCase(state)} · {count}
            </span>
          ))}
        </div>
      ) : (
        <p className="mt-2 text-[11px] text-slate-500">No review decisions recorded.</p>
      )}
    </div>
  );
}

function ChecksBlock({ checks }: { checks: CheckSummary | null }) {
  if (!checks) {
    return (
      <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
        <p className="flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-slate-400">
          <ListChecks className="h-3 w-3" aria-hidden="true" />
          CI checks
        </p>
        <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
          Check status was not available from GitHub for this change.
        </p>
      </div>
    );
  }

  const entries = Object.entries(checks.conclusions).sort((a, b) => b[1] - a[1]);
  const failing = checks.status_state === "failure" || checks.status_state === "error";

  if (!checks.available) {
    return (
      <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
        <p className="flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-slate-400">
          <ListChecks className="h-3 w-3" aria-hidden="true" />
          CI checks
        </p>
        <p className="mt-2 text-[11px] leading-relaxed text-slate-500">No check-run data was returned.</p>
        {checks.warnings.map((warning) => (
          <p key={warning} className="mt-1.5 text-[10.5px] leading-relaxed text-amber-200/75">
            {warning}
          </p>
        ))}
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
      <p className="flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-slate-400">
        {failing ? (
          <XCircle className="h-3 w-3 text-rose-300" aria-hidden="true" />
        ) : (
          <CheckCircle2 className="h-3 w-3 text-emerald-300" aria-hidden="true" />
        )}
        CI checks · {formatNumber(checks.check_runs_total ?? 0)}
      </p>
      <p className="mt-1.5 text-[11px] text-slate-400">
        Combined status: <span className={failing ? "text-rose-300" : "text-slate-200"}>{checks.status_state ?? "unknown"}</span>
      </p>
      {entries.length ? (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {entries.map(([conclusion, count]) => (
            <span
              key={conclusion}
              className={`rounded-md border px-2 py-0.5 text-[10px] ${
                conclusion === "success"
                  ? "border-emerald-400/20 bg-emerald-400/[0.06] text-emerald-200"
                  : conclusion === "failure" || conclusion === "timed_out"
                    ? "border-rose-400/20 bg-rose-400/[0.06] text-rose-200"
                    : "border-white/10 bg-white/[0.03] text-slate-300"
              }`}
            >
              {titleCase(conclusion)} · {count}
            </span>
          ))}
        </div>
      ) : (
        <p className="mt-2 text-[11px] text-slate-500">Checks exist but none have a conclusion yet.</p>
      )}
      {checks.warnings.map((warning) => (
        <p key={warning} className="mt-1.5 text-[10.5px] leading-relaxed text-amber-200/75">
          {warning}
        </p>
      ))}
    </div>
  );
}

export default function CommitDetails({ change, source, repository, generatedAt }: CommitDetailsProps) {
  const [showAllCommits, setShowAllCommits] = useState(false);
  const state = stateChip(change);
  const commits = showAllCommits ? change.commits : change.commits.slice(0, COMMIT_PREVIEW);
  const hiddenCommits = change.commits.length - commits.length;
  const Icon = change.kind === "pull_request" ? GitPullRequest : GitCommitHorizontal;

  return (
    <section className="glass-panel p-5 sm:p-6" aria-labelledby="commit-details-title">
      <div className="flex items-start justify-between gap-3">
        <h2 id="commit-details-title" className="section-label">
          Change details
        </h2>
        <span className={`chip ${state.className}`}>
          <Icon className="h-3 w-3" aria-hidden="true" />
          {state.label}
        </span>
      </div>

      <p className="mt-3 text-balance text-sm font-semibold leading-snug text-white">{change.title}</p>
      <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-400">
        <span className="inline-flex items-center gap-1">
          <User className="h-3 w-3" aria-hidden="true" />
          {change.author_login ?? change.author_name ?? "Unknown author"}
        </span>
        <span aria-hidden="true">·</span>
        <span className="font-mono text-slate-500">
          {repository.full_name}
          {change.number ? ` #${change.number}` : ""}
        </span>
      </p>

      <a
        href={source.url}
        target="_blank"
        rel="noreferrer noopener"
        className="btn-ghost mt-4 w-full !py-2 !text-[12px]"
      >
        <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
        Open on GitHub
      </a>

      <dl className="mt-4 text-left">
        <MetaRow label="Head SHA">
          <span className="font-mono text-[10.5px]" title={change.sha}>
            {shortSha(change.sha, 12)}
          </span>
        </MetaRow>
        <MetaRow label="Base SHA">
          <span className="font-mono text-[10.5px]" title={change.base_sha ?? undefined}>
            {shortSha(change.base_sha, 12)}
          </span>
        </MetaRow>
        <MetaRow label="Parent commits">
          {change.parent_shas.length ? (
            <span className="font-mono text-[10.5px]" title={change.parent_shas.join(", ")}>
              {change.parent_shas.map((parent) => shortSha(parent)).join(", ")}
            </span>
          ) : (
            "None returned"
          )}
        </MetaRow>
        <MetaRow label="Created">
          <span className="inline-flex items-center gap-1">
            <CalendarClock className="h-3 w-3 text-slate-500" aria-hidden="true" />
            {formatDate(change.created_at)}
          </span>
        </MetaRow>
        <MetaRow label="Updated">{formatDate(change.updated_at)}</MetaRow>
        <MetaRow label="Change size">
          {formatNumber(change.files_changed)} files · +{formatNumber(change.additions)} −
          {formatNumber(change.deletions)}
        </MetaRow>
        <MetaRow label="Diff coverage">
          <span className="inline-flex items-center gap-1">
            {change.diff_complete ? (
              <ShieldCheck className="h-3 w-3 text-emerald-300" aria-hidden="true" />
            ) : (
              <CircleSlash className="h-3 w-3 text-amber-300" aria-hidden="true" />
            )}
            {change.diff_complete ? "Complete file list" : "Truncated file list"}
          </span>
        </MetaRow>
        <MetaRow label="Analyzed at">{formatDate(generatedAt)}</MetaRow>
      </dl>

      {change.description ? (
        <details className="group mt-4 rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
          <summary className="flex cursor-pointer list-none items-center gap-2 text-[11px] font-medium text-slate-300">
            <MessageSquare className="h-3.5 w-3.5 text-slate-500" aria-hidden="true" />
            Description
            <ChevronDown className="ml-auto h-3.5 w-3.5 text-slate-500 transition group-open:rotate-180" aria-hidden="true" />
          </summary>
          <p className="mt-2 max-h-60 overflow-auto whitespace-pre-wrap break-words text-[11.5px] leading-relaxed text-slate-400">
            {change.description}
          </p>
        </details>
      ) : null}

      <div className="mt-3 grid gap-3">
        {change.reviews ? <ReviewsBlock reviews={change.reviews} /> : null}
        <ChecksBlock checks={change.checks} />
      </div>

      <div className="mt-4">
        <p className="flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-slate-400">
          <GitBranch className="h-3 w-3" aria-hidden="true" />
          Commits · {formatNumber(change.commits.length)}
        </p>
        {change.commits.length ? (
          <>
            <ol className="mt-2 space-y-1.5">
              {commits.map((commit) => (
                <li key={commit.sha} className="rounded-lg border border-white/[0.06] bg-white/[0.015] p-2">
                  <p className="truncate text-[11.5px] text-slate-200" title={commit.message}>
                    {commit.message.split("\n")[0] || "(no message)"}
                  </p>
                  <p className="mt-0.5 flex flex-wrap items-center gap-x-2 font-mono text-[9.5px] text-slate-500">
                    <span>{shortSha(commit.sha)}</span>
                    <span>· {commit.author_login ?? commit.author_name ?? "unknown"}</span>
                    <span>· {formatDate(commit.authored_at)}</span>
                    {commit.parents.length > 1 ? <span className="text-violet-300">· merge</span> : null}
                  </p>
                </li>
              ))}
            </ol>
            {hiddenCommits > 0 ? (
              <button
                type="button"
                onClick={() => setShowAllCommits(true)}
                className="mt-2 text-[11px] font-medium text-brand-300 hover:text-brand-200"
              >
                Show {formatNumber(hiddenCommits)} more commits
              </button>
            ) : null}
          </>
        ) : (
          <p className="mt-2 text-[11px] text-slate-500">No commit metadata was returned.</p>
        )}
      </div>
    </section>
  );
}
