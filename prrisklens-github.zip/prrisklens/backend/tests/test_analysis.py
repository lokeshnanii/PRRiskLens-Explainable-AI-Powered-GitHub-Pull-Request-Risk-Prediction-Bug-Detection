"""Tests for the deterministic diff parser and every code-finding detector."""

from __future__ import annotations

import json

from analysis import parse_patch
from conftest import make_file

from analysis import analyze_changes


def analyze(filename: str, patch: str, *, status: str = "modified"):
    return analyze_changes([make_file(filename, patch, status=status)])


def detectors(found) -> set[str]:
    return {finding.detector for finding in found.findings}


def findings_for(found, detector: str):
    return [finding for finding in found.findings if finding.detector == detector]


# ---------------------------------------------------------------------------
# Patch parsing and orchestration
# ---------------------------------------------------------------------------


def test_parse_patch_reads_hunks_and_no_newline_marker():
    parsed = parse_patch("@@ -1,2 +1,2 @@\n-old\n+new\n context\n\\ No newline at end of file")
    assert parsed.ok is True
    assert len(parsed.hunks) == 1
    hunk = parsed.hunks[0]
    assert [line.kind for line in hunk.lines] == ["del", "add", "context"]
    assert hunk.added[0].text == "new"
    assert hunk.added[0].new_no == 1
    assert hunk.removed[0].old_no == 1


def test_parse_patch_handles_empty_patch():
    parsed = parse_patch(None)
    assert parsed.ok is False


def test_analysis_statuses():
    assert analyze_changes([]).status == "unavailable"

    binary_only = analyze_changes([make_file("logo.png", None, status="added")])
    assert binary_only.status == "unavailable"
    assert "No textual patches" in (binary_only.message or "")

    mixed = analyze_changes(
        [
            make_file("app.py", "@@ -0,0 +1 @@\n+x = 1\n"),
            make_file("logo.png", None, status="added"),
        ]
    )
    assert mixed.status == "partial"
    assert mixed.coverage["files_without_patch"] == ["logo.png"]

    documented = analyze_changes([make_file("README.md", "@@ -1 +1 @@\n-old\n+new\n")])
    assert documented.status == "complete"
    assert documented.findings == []


def test_findings_are_serialisable_and_stable():
    found = analyze("app/config.py", '@@ -0,0 +1 @@\n+API_KEY = "sk-live1234567890abcdefghij"\n')
    payload = json.dumps(found.to_dict())
    assert "hardcoded_secret" in payload
    first = found.findings[0]
    assert first.id == first.id
    assert first.verification in {"potential", "unverified"}
    assert first.line == 1
    assert first.side == "new"


# ---------------------------------------------------------------------------
# Detectors
# ---------------------------------------------------------------------------


def test_hardcoded_secret_detected():
    found = analyze("app/config.py", '@@ -0,0 +1 @@\n+API_KEY = "sk-live1234567890abcdefghij"\n')
    assert "hardcoded_secret" in detectors(found)
    finding = findings_for(found, "hardcoded_secret")[0]
    assert finding.severity == "high"
    assert "API_KEY" in finding.evidence


def test_hardcoded_secret_placeholder_and_comment_ignored():
    placeholder = analyze("app/config.py", '@@ -0,0 +1 @@\n+API_KEY = "your_api_key_here"\n')
    assert "hardcoded_secret" not in detectors(placeholder)

    commented = analyze("app/config.py", '@@ -0,0 +1 @@\n+# API_KEY = "sk-live1234567890abcdefghij"\n')
    assert "hardcoded_secret" not in detectors(commented)


def test_secret_in_test_file_is_lower_severity():
    found = analyze("tests/test_api.py", '@@ -0,0 +1 @@\n+API_KEY = "sk-test1234567890abcdefghij"\n')
    finding = findings_for(found, "hardcoded_secret")[0]
    assert finding.severity == "medium"


def test_sql_injection_detected_in_execution_context():
    patch = (
        "@@ -1,2 +1,3 @@\n"
        " def handler(cursor, user_id):\n"
        '-    return cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()\n'
        '+    query = f"SELECT * FROM users WHERE id = {user_id}"\n'
        "+    return cursor.execute(query).fetchone()\n"
    )
    found = analyze("app/db.py", patch)
    assert "sql_injection" in detectors(found)
    finding = findings_for(found, "sql_injection")[0]
    assert finding.severity == "high"
    assert finding.line == 2


def test_parameterised_sql_is_not_flagged():
    found = analyze(
        "app/db.py",
        '@@ -0,0 +1 @@\n+    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))\n',
    )
    assert "sql_injection" not in detectors(found)


def test_sql_detection_skips_test_files():
    found = analyze(
        "tests/test_db.py",
        '@@ -0,0 +1 @@\n+    cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")\n',
    )
    assert "sql_injection" not in detectors(found)


def test_command_injection_with_shell_true():
    found = analyze(
        "app/run.py",
        '@@ -0,0 +1 @@\n+    subprocess.run(f"grep {pattern} file", shell=True)\n',
    )
    assert "command_injection" in detectors(found)
    finding = findings_for(found, "command_injection")[0]
    assert finding.severity == "high"
    assert finding.confidence == "medium"


def test_os_system_is_flagged():
    found = analyze("app/run.py", '@@ -0,0 +1 @@\n+    os.system("rm -rf " + target)\n')
    assert "command_injection" in detectors(found)


def test_removed_validation_detected():
    patch = (
        "@@ -1,3 +1,1 @@\n"
        " def greet(name):\n"
        "-    if not name:\n"
        '-        raise ValueError("name required")\n'
        '+    return f"hi {name}"\n'
    )
    found = analyze("app/greet.py", patch)
    assert "removed_validation" in detectors(found)
    finding = findings_for(found, "removed_validation")[0]
    assert finding.side == "old"
    assert finding.verification == "unverified"


def test_replaced_validation_is_not_flagged():
    patch = (
        "@@ -1,3 +1,3 @@\n"
        " def greet(name):\n"
        "-    if not name:\n"
        '-        raise ValueError("name required")\n'
        "+    if not name:\n"
        '+        raise ValueError("still required")\n'
    )
    found = analyze("app/greet.py", patch)
    assert "removed_validation" not in detectors(found)


def test_broad_exception_handler():
    patch = "@@ -0,0 +1,4 @@\n+try:\n+    parse(data)\n+except Exception:\n+    pass\n"
    found = analyze("app/parse.py", patch)
    assert "broad_exception" in detectors(found)
    assert findings_for(found, "broad_exception")[0].severity == "medium"


def test_boundary_condition_change():
    patch = (
        "@@ -1,2 +1,2 @@\n"
        " def allowed(items):\n"
        "-    if len(items) >= 10:\n"
        "+    if len(items) > 10:\n"
    )
    found = analyze("app/limits.py", patch)
    assert "boundary_change" in detectors(found)
    assert ">= to >" in findings_for(found, "boundary_change")[0].title


def test_unsafe_deserialization():
    found = analyze("app/cache.py", "@@ -0,0 +1 @@\n+    data = pickle.loads(payload)\n")
    assert "unsafe_deserialization" in detectors(found)
    assert findings_for(found, "unsafe_deserialization")[0].severity == "high"


def test_safe_yaml_loader_is_ignored():
    found = analyze(
        "app/config.py",
        "@@ -0,0 +1 @@\n+    config = yaml.load(raw, Loader=yaml.SafeLoader)\n",
    )
    assert "unsafe_deserialization" not in detectors(found)


def test_missing_none_guard():
    patch = (
        "@@ -1,3 +1,1 @@\n"
        " def display(user):\n"
        "-    if user is None:\n"
        "-        return None\n"
        '+    return user["name"]\n'
    )
    found = analyze("app/view.py", patch)
    assert "missing_none_handling" in detectors(found)
    finding = findings_for(found, "missing_none_handling")[0]
    assert finding.side == "old"
    assert finding.verification == "unverified"


def test_none_guard_replacement_is_ignored():
    patch = (
        "@@ -1,3 +1,4 @@\n"
        " def display(user):\n"
        "-    if user is None:\n"
        "-        return None\n"
        '+    if user is not None:\n'
        '+        return user["name"]\n'
        "+    return None\n"
    )
    found = analyze("app/view.py", patch)
    assert "missing_none_handling" not in detectors(found)


def test_risky_temp_file_and_unclosed_handle():
    found = analyze(
        "app/files.py",
        "@@ -0,0 +1,2 @@\n+    path = tempfile.mktemp(suffix=\".log\")\n+    handle = open(path)\n",
    )
    risky = findings_for(found, "risky_resource")
    assert {finding.severity for finding in risky} == {"medium", "low"}


def test_context_manager_is_not_flagged():
    found = analyze(
        "app/files.py",
        '@@ -0,0 +1 @@\n+    with open("data.txt") as handle:\n',
    )
    assert "risky_resource" not in detectors(found)


def test_weakened_tests_removed_assertions():
    patch = (
        "@@ -1,3 +1,1 @@\n"
        " def test_add():\n"
        "-    assert add(1, 2) == 3\n"
        "-    assert add(-1, 1) == 0\n"
        "+    add(1, 2)\n"
    )
    found = analyze("tests/test_math.py", patch)
    assert "weakened_tests" in detectors(found)
    assert findings_for(found, "weakened_tests")[0].severity == "medium"


def test_deleted_test_file():
    found = analyze(
        "tests/test_old.py",
        "@@ -1,2 +0,0 @@\n-def test_x():\n-    assert True\n",
        status="removed",
    )
    finding = findings_for(found, "weakened_tests")[0]
    assert finding.severity == "high"
    assert finding.title == "Test file deleted"


def test_skipped_test_marker():
    found = analyze(
        "tests/test_flaky.py",
        '@@ -0,0 +1 @@\n+@pytest.mark.skip(reason="flaky")\n',
    )
    assert "weakened_tests" in detectors(found)


def test_authorization_regression():
    patch = "@@ -1,2 +1,1 @@\n-@login_required\n def view():\n"
    found = analyze("app/views.py", patch)
    assert "auth_regression" in detectors(found)
    assert findings_for(found, "auth_regression")[0].severity == "high"


def test_retained_authorization_is_not_flagged():
    patch = (
        "@@ -1,3 +1,3 @@\n"
        " @login_required\n"
        " def view():\n"
        '-    return "a"\n'
        '+    return "b"\n'
    )
    found = analyze("app/views.py", patch)
    assert "auth_regression" not in detectors(found)


def test_removed_public_function():
    patch = (
        "@@ -1,2 +1,2 @@\n"
        "-def public_api(x):\n"
        "+def _private_helper(x):\n"
        "     return x\n"
    )
    found = analyze("app/api.py", patch)
    titles = [finding.title for finding in findings_for(found, "breaking_api_change")]
    assert any("public_api" in title for title in titles)


def test_changed_public_signature():
    patch = "@@ -1,2 +1,2 @@\n-def public_api(x):\n+def public_api(x, y=1):\n     return x\n"
    found = analyze("app/api.py", patch)
    titles = [finding.title for finding in findings_for(found, "breaking_api_change")]
    assert any("Signature" in title for title in titles)


def test_removed_route():
    patch = "@@ -1,2 +1 @@\n-@app.route('/health')\n def index():\n"
    found = analyze("app/routes.py", patch)
    titles = [finding.title for finding in findings_for(found, "breaking_api_change")]
    assert "HTTP route removed without replacement" in titles


def test_comments_and_docs_are_ignored():
    found = analyze(
        "app/notes.py",
        '@@ -0,0 +1,2 @@\n+# password = "hunter2hunter2"\n+// os.system("ls")\n',
    )
    assert found.findings == []
