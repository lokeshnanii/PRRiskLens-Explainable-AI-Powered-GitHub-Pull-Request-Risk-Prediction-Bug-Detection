"""Regression tests for approximate SZZ labelling.

The integration test builds a small real git repository. It exercises the
PyDriller ``Git`` entry point used by ``szz.label_repository`` and verifies that
blame attributes a deleted line to the commit that introduced it, while a fix
commit is never labelled as its own introducing commit.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

import szz


def _git(repo: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", "-C", str(repo), *args],
        capture_output=True,
        text=True,
        check=True,
    )
    return completed.stdout.strip()


def _commit(repo: Path, message: str) -> str:
    _git(repo, "add", "-A")
    _git(repo, "commit", "-q", "-m", message)
    return _git(repo, "rev-parse", "HEAD")


@pytest.fixture
def szz_repo(tmp_path: Path) -> tuple[Path, dict[str, str]]:
    repo = tmp_path / "repo"
    repo.mkdir()
    _git(repo, "init", "-q")
    _git(repo, "config", "user.email", "test@example.com")
    _git(repo, "config", "user.name", "Test User")

    module = repo / "module.py"
    module.write_text("def stable():\n    return 1\n", encoding="utf-8")
    initial = _commit(repo, "Add module")

    module.write_text(
        "def stable():\n    return 1\n\ndef broken():\n    return None.attribute\n",
        encoding="utf-8",
    )
    introducing = _commit(repo, "Add helper")

    module.write_text(
        "def stable():\n    return 1\n\ndef broken():\n    return 0\n",
        encoding="utf-8",
    )
    fixing = _commit(repo, "Fix crash in broken helper")
    return repo, {"initial": initial, "introducing": introducing, "fix": fixing}


def _record(sha: str, message: str, parent: str) -> dict[str, object]:
    return {
        "repo": "fixture/repo",
        "sha": sha,
        "message": message,
        "author_date": "2024-01-01T00:00:00Z",
        "parents": [parent],
        "files": ["module.py"],
    }


def test_label_repository_traces_introducing_commit(
    szz_repo: tuple[Path, dict[str, str]], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    repo, shas = szz_repo
    monkeypatch.setattr(szz, "ensure_clone", lambda slug, clone_dir, **kwargs: repo)

    records = [
        _record(shas["initial"], "Add module", "0" * 40),
        _record(shas["introducing"], "Add helper", shas["initial"]),
        _record(shas["fix"], "Fix crash in broken helper", shas["introducing"]),
    ]
    rows, status = szz.label_repository(
        "fixture/repo",
        records,
        clone_dir=tmp_path,
        max_fixes=5,
        max_files_per_fix=5,
        max_spans_per_file=5,
        max_blame_calls=10,
        blame_timeout=30,
    )

    assert status["status"] == "ok", status
    assert status["candidates"] == 1
    assert status["fixes_traced"] == 1
    assert status["fixes_untraceable"] == 0

    traced = [row for row in rows if row["provenance"] == "szz_candidate"]
    assert len(traced) == 1, rows
    edge = traced[0]
    assert edge["fix_sha"] == shas["fix"]
    assert edge["introducing_sha"] == shas["introducing"]
    assert edge["in_window"] == "true"
    assert edge["file"] == "module.py"
    assert all(row["introducing_sha"] != row["fix_sha"] for row in rows)
