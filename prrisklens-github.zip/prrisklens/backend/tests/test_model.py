"""Tests for leakage guards, chronological evaluation, training and inference."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import pytest

from conftest import iso, make_training_frame, utc
from core import FEATURES, FeatureValidationError, risk_category
from dataset import build_training_frame
from inference import ModelBundle, ModelRegistry, predict_with_bundle
from train import (
    InsufficientDataError,
    chronological_split,
    evaluate_predictions,
    train_and_evaluate,
)


# ---------------------------------------------------------------------------
# Dataset construction and leakage guards
# ---------------------------------------------------------------------------


def _raw(sha: str, author: str, when: datetime, files: list[str], message: str = "Update files", **extra):
    return {
        "repo": "fixture/repo",
        "sha": sha,
        "author_name": author,
        "author_email": f"{author.lower()}@example.com",
        "author_date": iso(when),
        "message": message,
        "files_changed": len(files),
        "lines_added": 10,
        "lines_deleted": 2,
        "file_paths": json.dumps(files),
        "is_merge": False,
        **extra,
    }


def dataset_records() -> list[dict]:
    t0 = utc(2023, 1, 1, 10)
    return [
        _raw("a" * 40, "Ada", t0, ["src/x.py"], "Add x"),
        _raw("b" * 40, "Ada", utc(2023, 1, 2, 10), ["src/x.py"], "Refactor x"),
        _raw("c" * 40, "Grace", utc(2023, 1, 3, 10), ["src/x.py"], "Fix crash in x"),
        _raw("d" * 40, "Ada", utc(2023, 1, 4, 10), ["src/x.py"], "Update x"),
        _raw("e" * 40, "Linus", utc(2023, 1, 5, 10), ["src/x.py", "src/y.py"], "Add y"),
        _raw("f" * 40, "Linus", utc(2023, 1, 5, 10), ["src/y.py"], "Tweak y"),
    ]


def test_build_training_frame_is_leak_free():
    labels = [
        {"fix_sha": "c" * 40, "introducing_sha": "b" * 40, "provenance": "szz_candidate"},
        {"fix_sha": "c" * 40, "introducing_sha": "a" * 40, "provenance": "untraceable"},
    ]
    frame, meta = build_training_frame(dataset_records(), labels)
    assert list(frame.columns)[:3] == ["repo", "sha", "author_date"]
    assert list(frame[list(FEATURES)]) == list(FEATURES)
    by_sha = {row["sha"]: row for row in frame.to_dict(orient="records")}

    first = by_sha["a" * 40]
    assert first["previous_author_commits"] == 0
    assert first["prior_bug_fixes_in_touched_files"] == 0
    assert first["label"] == 0  # untraceable labels are ignored

    second = by_sha["b" * 40]
    assert second["previous_author_commits"] == 1
    assert second["prior_bug_fixes_in_touched_files"] == 0
    assert second["label"] == 1

    fix_commit = by_sha["c" * 40]
    assert fix_commit["label"] == 0  # the fix commit is never its own introducing commit
    assert fix_commit["bug_fix_message"] == 1

    after_fix = by_sha["d" * 40]
    assert after_fix["previous_author_commits"] == 2
    assert after_fix["prior_bug_fixes_in_touched_files"] == 1  # the earlier fix touched x

    # Equal-timestamp commits cannot influence each other. Only `e` touches x,
    # where the earlier bug fix landed; `f` touches y, so it sees no prior fix.
    group = [by_sha["e" * 40], by_sha["f" * 40]]
    assert [row["previous_author_commits"] for row in group] == [0, 0]
    assert [row["prior_bug_fixes_in_touched_files"] for row in group] == [1, 0]

    assert meta["rows"] == 6
    assert meta["positives"] == 1
    assert meta["labels"]["szz_label_rows"] == 1
    assert meta["labels"]["untraceable_rows"] == 1
    assert "strictly earlier" in meta["leakage_guard"]


def test_build_training_frame_skips_bad_rows():
    records = dataset_records() + [
        _raw("9" * 40, "Ada", utc(2023, 1, 6), ["a.py"], error="mining failed"),
        _raw("8" * 40, "Ada", utc(2023, 1, 6), ["a.py"], is_merge=True),
        _raw("7" * 40, "Ada", utc(2023, 1, 6), [], "empty diff"),
        {**_raw("6" * 40, "Ada", utc(2023, 1, 6), ["a.py"]), "author_email": "", "author_name": ""},
        {**_raw("5" * 40, "Ada", utc(2023, 1, 6), ["a.py"]), "lines_added": "oops"},
    ]
    records.append({**_raw("4" * 40, "Ada", utc(2023, 1, 6), ["a.py"]), "author_date": "not-a-date"})
    frame, meta = build_training_frame(records, [])
    assert len(frame) == 6
    assert meta["skipped"] == {
        "row_error": 1,
        "merge_commit": 1,
        "empty_diff": 1,
        "missing_author": 1,
        "invalid_counts": 1,
        "missing_timestamp": 1,
    }


# ---------------------------------------------------------------------------
# Chronological split
# ---------------------------------------------------------------------------


def test_chronological_split_is_ordered():
    frame = make_training_frame(20)
    split = chronological_split(frame, 0.7)
    # The row at the split index is kept in training so timestamps never straddle
    # the boundary; the remainder is strictly later.
    assert len(split.train) == 15
    assert len(split.test) == 5
    assert pd.to_datetime(split.train["author_date"], utc=True).max() <= pd.to_datetime(
        split.test["author_date"], utc=True
    ).min()
    assert "Oldest" in split.note


def test_chronological_split_keeps_equal_timestamps_together():
    times = [utc(2023, 1, day) for day in range(1, 7)]
    rows = []
    for index, stamp in enumerate(times):
        rows.append({"sha": f"{index:040x}", "author_date": iso(stamp), "label": index % 2, **{name: index for name in FEATURES}})
    # Three commits share the boundary timestamp; a later commit must remain in test.
    rows.append({"sha": "9" * 40, "author_date": iso(times[-1]), "label": 1, **{name: 1 for name in FEATURES}})
    rows.append({"sha": "8" * 40, "author_date": iso(times[-1]), "label": 0, **{name: 1 for name in FEATURES}})
    for offset, sha in enumerate(("7", "6", "5"), start=1):
        rows.append(
            {
                "sha": sha * 40,
                "author_date": iso(utc(2023, 2, offset)),
                "label": 0,
                **{name: 1 for name in FEATURES},
            }
        )
    frame = pd.DataFrame(rows)
    split = chronological_split(frame, 0.7)
    boundary = pd.to_datetime(iso(times[-1]), utc=True)
    train_times = pd.to_datetime(split.train["author_date"], utc=True)
    test_times = pd.to_datetime(split.test["author_date"], utc=True)
    assert (train_times <= boundary).all()
    assert (test_times > boundary).all()
    assert len(split.test) == 3


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------


def test_evaluate_predictions_perfect_ranking():
    metrics = evaluate_predictions(np.array([0, 0, 1, 1]), np.array([0.1, 0.2, 0.8, 0.9]))
    assert metrics["roc_auc"] == 1.0
    assert metrics["pr_auc_average_precision"] == 1.0
    assert metrics["confusion_matrix"] == {"tn": 2, "fp": 0, "fn": 0, "tp": 2}
    assert (metrics["precision"], metrics["recall"], metrics["f1"]) == (1.0, 1.0, 1.0)
    assert metrics["top_10_percent_capture"]["ranked_count"] == 1
    assert metrics["top_10_percent_capture"]["positives_captured"] == 1
    assert metrics["top_10_percent_capture"]["positives_total"] == 2
    assert metrics["top_10_percent_capture"]["capture_rate"] == 0.5


def test_evaluate_predictions_reports_undefined_metrics():
    metrics = evaluate_predictions(np.array([0, 0, 0]), np.array([0.1, 0.2, 0.3]))
    assert metrics["roc_auc"] is None
    assert metrics["pr_auc_average_precision"] is None
    assert metrics["top_10_percent_capture"]["capture_rate"] is None
    assert any("ROC-AUC is undefined" in note for note in metrics["notes"])
    assert any("PR-AUC" in note for note in metrics["notes"])


def test_evaluate_predictions_threshold_edge():
    metrics = evaluate_predictions(np.array([0, 1]), np.array([0.4, 0.6]), threshold=0.9)
    assert metrics["confusion_matrix"] == {"tn": 1, "fp": 0, "fn": 1, "tp": 0}
    assert metrics["precision"] is None  # nothing exceeded the threshold
    assert metrics["recall"] == 0.0
    assert metrics["f1"] is None


def test_evaluate_predictions_rejects_bad_input():
    with pytest.raises(ValueError):
        evaluate_predictions(np.array([0, 1]), np.array([0.1]))
    with pytest.raises(ValueError):
        evaluate_predictions(np.array([0, 1]), np.array([0.1, np.inf]))


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------


def test_training_stops_with_diagnostics_when_data_is_small(tmp_path: Path):
    frame = make_training_frame(20)
    with pytest.raises(InsufficientDataError):
        train_and_evaluate(
            frame,
            models_dir=tmp_path / "models",
            results_path=tmp_path / "results.json",
        )
    results = json.loads((tmp_path / "results.json").read_text())
    assert results["status"] == "insufficient_data"
    assert results["diagnostics"]
    assert not (tmp_path / "models" / "model.joblib").exists()


def test_training_writes_real_artifacts(trained_models: Path):
    for name in ("model.joblib", "xgboost_model.joblib", "logreg_model.joblib", "background.joblib", "metadata.json", "results.json"):
        assert (trained_models / name).exists(), name

    results = json.loads((trained_models / "results.json").read_text())
    assert results["status"] == "ok"
    assert results["selected_model"] in {"xgboost", "logistic_regression"}
    assert results["split"]["method"] == "chronological"
    assert results["feature_schema_version"] == "1.0.0"
    for model_name in ("logistic_regression", "xgboost"):
        metrics = results["models"][model_name]["metrics"]
        assert metrics["test_size"] == results["dataset"]["test"]["rows"]
        assert metrics["confusion_matrix"]["tn"] + metrics["confusion_matrix"]["fp"] + metrics["confusion_matrix"]["fn"] + metrics["confusion_matrix"]["tp"] == metrics["test_size"]
        capture = metrics["top_10_percent_capture"]
        assert capture["positives_captured"] <= capture["positives_total"]
        assert capture["capture_rate"] is None or 0 <= capture["capture_rate"] <= 1

    metadata = json.loads((trained_models / "metadata.json").read_text())
    assert metadata["features"] == list(FEATURES)
    assert metadata["metrics"] == results["models"][results["selected_model"]]["metrics"]
    assert metadata["training_config"]["split"].startswith("chronological")


# ---------------------------------------------------------------------------
# Registry, inference and SHAP
# ---------------------------------------------------------------------------


def test_registry_reports_missing_artifact(tmp_path: Path):
    registry = ModelRegistry(tmp_path)
    assert registry.get() is None
    status = registry.status()
    assert status["model_available"] is False
    assert "No trained model" in status["reason"]


def test_registry_rejects_incompatible_artifact(tmp_path: Path):
    joblib.dump({"kind": "xgboost", "features": ["wrong"], "model": object()}, tmp_path / "model.joblib")
    registry = ModelRegistry(tmp_path)
    assert registry.get() is None
    assert "schema" in registry.status()["reason"].lower()


@pytest.fixture(scope="module")
def bundles(trained_models: Path) -> dict[str, ModelBundle]:
    xgb_payload = joblib.load(trained_models / "xgboost_model.joblib")
    lr_payload = joblib.load(trained_models / "logreg_model.joblib")
    background = np.asarray(joblib.load(trained_models / "background.joblib"), dtype=float)
    return {
        "xgboost": ModelBundle(
            kind="xgboost",
            model=xgb_payload["model"],
            model_version=xgb_payload["model_version"],
            schema_version=xgb_payload["feature_schema_version"],
            threshold=0.5,
            training_rows=xgb_payload["training_rows"],
            background=background,
        ),
        "logistic": ModelBundle(
            kind="logistic",
            model=lr_payload["model"],
            model_version=lr_payload["model_version"],
            schema_version=lr_payload["feature_schema_version"],
            threshold=0.5,
            scaler=lr_payload["scaler"],
            background=background,
            training_rows=lr_payload["training_rows"],
        ),
    }


VALUES = {
    "files_changed": 8,
    "lines_added": 180,
    "lines_deleted": 40,
    "previous_author_commits": 25,
    "prior_bug_fixes_in_touched_files": 3,
    "commit_hour": 14,
}


@pytest.mark.parametrize("kind", ["xgboost", "logistic"])
def test_prediction_and_shap_for_both_model_families(bundles, kind):
    bundle = bundles[kind]
    result = predict_with_bundle(bundle, VALUES, low_threshold=35, high_threshold=70)

    assert result["status"] == "ok"
    assert 0 <= result["risk_score"] <= 100
    assert result["risk_category"] == risk_category(result["risk_score"], 35, 70)
    assert result["input_features"] == VALUES
    assert result["feature_order"] == list(FEATURES)
    assert result["model_type"] == kind
    assert result["model_version"].startswith(kind if kind == "xgboost" else "logistic")
    assert result["shap_available"] is True
    assert result["explanation_status"] == "available"
    assert result["contribution_scale"] == "log-odds"
    assert len(result["all_contributions"]) == 6
    assert 1 <= len(result["factors"]) <= 3
    assert all(factor["direction"] == "raises" for factor in result["factors"])
    assert [factor["contribution"] for factor in result["factors"]] == sorted(
        [factor["contribution"] for factor in result["factors"]], reverse=True
    )
    assert result["base_value"] is not None
    assert result["thresholds"] == {"low_max": 35, "high_min": 70}


def test_prediction_rejects_invalid_features(bundles):
    with pytest.raises(FeatureValidationError):
        predict_with_bundle(bundles["xgboost"], {**VALUES, "commit_hour": 99}, low_threshold=35, high_threshold=70)


def test_prediction_reports_small_training_warning(bundles):
    result = predict_with_bundle(bundles["xgboost"], VALUES, low_threshold=35, high_threshold=70)
    assert any("weak signal" in warning for warning in result["warnings"])
