import { useCallback, useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  Brain,
  ExternalLink,
  GitCommitHorizontal,
  GitPullRequest,
  Info,
  ScanSearch,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import type {
  AnalysisResponse,
  FeatureValues,
  GitHubRateLimitResponse,
  HealthResponse,
  ModelInfoResponse,
  Prediction,
  Thresholds,
} from "./types/analysis";
import { api } from "./services/api";
import { formatDate } from "./lib/format";
import Header from "./components/Header";
import HeroSection from "./components/HeroSection";
import AnalysisForm from "./components/AnalysisForm";
import ManualFeatureForm from "./components/ManualFeatureForm";
import LoadingState from "./components/LoadingState";
import ErrorState from "./components/ErrorState";
import RiskSummary from "./components/RiskSummary";
import RiskFactors from "./components/RiskFactors";
import CodeFindings from "./components/CodeFindings";
import ChangedFiles from "./components/ChangedFiles";
import CommitDetails from "./components/CommitDetails";
import ReviewChecklist from "./components/ReviewChecklist";
import MethodologyPanel from "./components/MethodologyPanel";
import Footer from "./components/Footer";

type Mode = "url" | "manual";

const FALLBACK_THRESHOLDS: Thresholds = { low_max: 35, high_min: 70 };

const COMPLETENESS_TONE: Record<string, string> = {
  complete: "!border-emerald-400/25 !text-emerald-200",
  partial: "!border-amber-400/25 !text-amber-200",
};

function EmptyState() {
  const cards = [
    {
      icon: Brain,
      title: "Historical risk signal",
      detail:
        "Six time-aware features scored by a supervised model, with SHAP contributions and configurable Low/Medium/High bands.",
    },
    {
      icon: ScanSearch,
      title: "Diff evidence, kept separate",
      detail:
        "Deterministic detectors run over the real changed lines and report file, line, evidence and remediation — not a model score.",
    },
    {
      icon: ShieldCheck,
      title: "Honest failure modes",
      detail:
        "No model artifact means no score: the dashboard says so explicitly while still showing genuine code findings.",
    },
  ];

  return (
    <div className="mt-5 grid gap-3 sm:grid-cols-3">
      {cards.map((card) => {
        const Icon = card.icon;
        return (
          <div key={card.title} className="glass-panel-soft p-4">
            <span className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/[0.03] text-aqua-300">
              <Icon className="h-4 w-4" aria-hidden="true" />
            </span>
            <p className="mt-2.5 text-[12.5px] font-semibold text-slate-100">{card.title}</p>
            <p className="mt-1 text-[11px] leading-relaxed text-slate-400">{card.detail}</p>
          </div>
        );
      })}
    </div>
  );
}

function ResultBanner({ analysis }: { analysis: AnalysisResponse }) {
  const { change, repository, data_completeness: completeness, warnings, source } = analysis;
  const kindIcon =
    change.kind === "pull_request" ? (
      <GitPullRequest className="h-3.5 w-3.5" aria-hidden="true" />
    ) : (
      <GitCommitHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
    );
  const overallTone = COMPLETENESS_TONE[completeness.overall] ?? "";
  const failingChecks =
    change.checks?.available && change.checks.status_state && change.checks.status_state !== "success";

  return (
    <div className="glass-panel p-4 sm:p-5" aria-live="polite">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-white/10 bg-gradient-to-br from-brand-500/20 to-aqua-400/10 text-brand-200">
            {kindIcon}
          </span>
          <div className="min-w-0">
            <p className="truncate text-[13px] font-semibold text-white">
              {repository.full_name}
              {change.number ? ` · #${change.number}` : ""}
            </p>
            <p className="mt-0.5 truncate text-[11.5px] text-slate-400">{change.title}</p>
            <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[10px] text-slate-500">
              <span>analysis {analysis.analysis_id.slice(0, 12)}</span>
              <span aria-hidden="true">·</span>
              <span>{formatDate(analysis.generated_at)}</span>
              <span aria-hidden="true">·</span>
              <a href={source.url} target="_blank" rel="noreferrer noopener" className="inline-flex items-center gap-1 text-brand-300 hover:text-brand-200">
                <ExternalLink className="h-2.5 w-2.5" aria-hidden="true" />
                GitHub
              </a>
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          <span className={`chip ${overallTone}`}>data {completeness.overall}</span>
          <span className="chip">{analysis.code_analysis.summary.total} findings</span>
          <span className={`chip ${analysis.prediction.status === "ok" ? "!border-emerald-400/25 !text-emerald-200" : "!border-amber-400/25 !text-amber-200"}`}>
            {analysis.prediction.status === "ok" ? "model scored" : "no score"}
          </span>
          {failingChecks ? <span className="chip !border-rose-400/25 !text-rose-200">CI failing</span> : null}
          {warnings.length ? <span className="chip !border-amber-400/25 !text-amber-200">{warnings.length} warnings</span> : null}
        </div>
      </div>

      {warnings.length ? (
        <details className="group mt-3 rounded-lg border border-amber-400/15 bg-amber-400/[0.04] p-3">
          <summary className="flex cursor-pointer list-none items-center gap-2 text-[11px] font-medium text-amber-200">
            <AlertTriangle className="h-3.5 w-3.5" aria-hidden="true" />
            Analysis warnings and data limitations
            <span className="ml-auto text-[10px] text-amber-200/60 group-open:hidden">show</span>
          </summary>
          <ul className="mt-2 space-y-1.5">
            {warnings.map((warning) => (
              <li key={warning} className="text-[11px] leading-relaxed text-amber-100/75">
                {warning}
              </li>
            ))}
          </ul>
        </details>
      ) : null}
    </div>
  );
}

export default function App() {
  const [mode, setMode] = useState<Mode>("url");
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [healthLoading, setHealthLoading] = useState(true);
  const [modelInfo, setModelInfo] = useState<ModelInfoResponse | null>(null);
  const [rateLimit, setRateLimit] = useState<GitHubRateLimitResponse | null>(null);
  const [rateLimitLoading, setRateLimitLoading] = useState(true);

  const [analysis, setAnalysis] = useState<AnalysisResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [lastUrl, setLastUrl] = useState<string | null>(null);

  const [manualPrediction, setManualPrediction] = useState<Prediction | null>(null);
  const [manualLoading, setManualLoading] = useState(false);
  const [manualError, setManualError] = useState<unknown>(null);
  const [manualValues, setManualValues] = useState<FeatureValues | null>(null);

  const resultsRef = useRef<HTMLDivElement>(null);

  const loadModelInfo = useCallback(async () => {
    try {
      setModelInfo(await api.modelInfo());
    } catch {
      setModelInfo(null);
    }
  }, []);

  const loadRateLimit = useCallback(async () => {
    setRateLimitLoading(true);
    try {
      setRateLimit(await api.rateLimit());
    } catch {
      setRateLimit(null);
    } finally {
      setRateLimitLoading(false);
    }
  }, []);

  const refreshHealth = useCallback(async () => {
    setHealthLoading(true);
    try {
      setHealth(await api.health());
    } catch {
      setHealth(null);
    } finally {
      setHealthLoading(false);
    }
    void loadModelInfo();
    void loadRateLimit();
  }, [loadModelInfo, loadRateLimit]);

  useEffect(() => {
    void refreshHealth();
  }, [refreshHealth]);

  useEffect(() => {
    if (analysis || error || manualPrediction || manualError) {
      resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [analysis, error, manualPrediction, manualError]);

  const runAnalysis = useCallback(async (url: string) => {
    setLastUrl(url);
    setLoading(true);
    setError(null);
    setAnalysis(null);
    setManualPrediction(null);
    setManualError(null);
    try {
      const result = await api.analyzeUrl(url);
      setAnalysis(result);
      if (!result.model_info.available) {
        void loadModelInfo();
      }
      if (result.github) {
        setRateLimit({
          authenticated: result.github.authenticated,
          mode: result.github.mode,
          token_configured: result.github.token_configured,
          expected_hourly_limit: result.github.expected_hourly_limit,
          note: result.github.note,
          rate_limit: result.github.rate_limit,
          error: null,
          time: result.generated_at,
        });
      }
    } catch (caught) {
      setError(caught);
      // Refresh the quota even when the analysis failed so the header can
      // explain an exhausted limit and show the reset time.
      void loadRateLimit();
    } finally {
      setLoading(false);
    }
  }, [loadModelInfo, loadRateLimit]);

  const runManual = useCallback(async (values: FeatureValues) => {
    setManualValues(values);
    setManualLoading(true);
    setManualError(null);
    setManualPrediction(null);
    setAnalysis(null);
    setError(null);
    try {
      setManualPrediction(await api.predict(values));
    } catch (caught) {
      setManualError(caught);
    } finally {
      setManualLoading(false);
    }
  }, []);

  function clearUrlResults() {
    setAnalysis(null);
    setError(null);
    setLastUrl(null);
  }

  function switchMode(next: Mode) {
    if (next === mode) return;
    setMode(next);
    setAnalysis(null);
    setError(null);
    setManualPrediction(null);
    setManualError(null);
  }

  const thresholds = modelInfo?.thresholds ?? FALLBACK_THRESHOLDS;
  const modelAvailable = Boolean(modelInfo?.available ?? health?.model_available);

  return (
    <div id="top" className="min-h-screen">
      <Header
        health={health}
        healthLoading={healthLoading}
        onRefreshHealth={() => void refreshHealth()}
        rateLimit={rateLimit}
        rateLimitLoading={rateLimitLoading}
        onRefreshRateLimit={() => void loadRateLimit()}
      />

      <main>
        <HeroSection />

        <div className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
          <section id="analyze" className="scroll-mt-24" aria-labelledby="analyze-title">
            <div className="glass-panel p-5 sm:p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 id="analyze-title" className="flex items-center gap-2 text-base font-semibold text-white">
                    <Sparkles className="h-4 w-4 text-brand-300" aria-hidden="true" />
                    Analyze a pull request or commit
                  </h2>
                  <p className="mt-1 max-w-2xl text-[11.5px] leading-relaxed text-slate-400">
                    Fetches real GitHub metadata, diffs and history. Use the manual tab to score feature
                    values directly without a GitHub request.
                  </p>
                </div>
                <div className="flex rounded-xl border border-white/10 bg-ink-950/50 p-1" role="group" aria-label="Input mode">
                  <button
                    type="button"
                    onClick={() => switchMode("url")}
                    aria-pressed={mode === "url"}
                    className={`rounded-lg px-3 py-1.5 text-[11px] font-medium transition ${
                      mode === "url" ? "bg-white/10 text-white" : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    GitHub URL
                  </button>
                  <button
                    type="button"
                    onClick={() => switchMode("manual")}
                    aria-pressed={mode === "manual"}
                    className={`rounded-lg px-3 py-1.5 text-[11px] font-medium transition ${
                      mode === "manual" ? "bg-white/10 text-white" : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    Manual features
                  </button>
                </div>
              </div>

              <div className="mt-4">
                {mode === "url" ? (
                  <AnalysisForm onSubmit={(url) => void runAnalysis(url)} onClear={clearUrlResults} loading={loading} />
                ) : (
                  <ManualFeatureForm onSubmit={(values) => void runManual(values)} loading={manualLoading} modelAvailable={modelAvailable} />
                )}
              </div>
            </div>

            <div ref={resultsRef} className="mt-5 scroll-mt-20 space-y-4">
              {loading && mode === "url" ? <LoadingState /> : null}

              {error ? (
                <ErrorState error={error} onRetry={lastUrl ? () => void runAnalysis(lastUrl) : undefined} />
              ) : null}

              {manualError ? (
                <ErrorState error={manualError} onRetry={manualValues ? () => void runManual(manualValues) : undefined} />
              ) : null}

              {manualPrediction ? (
                <div className="space-y-4 animate-fade-up">
                  <div className="rounded-xl border border-brand-400/20 bg-brand-400/[0.04] p-3 text-[11px] leading-relaxed text-slate-300">
                    <span className="inline-flex items-center gap-1.5 font-medium text-brand-200">
                      <Info className="h-3.5 w-3.5" aria-hidden="true" />
                      Manual feature scoring
                    </span>{" "}
                    No GitHub request was made. The score reflects only the six values you entered, and the
                    code-finding panel is not part of this mode.
                  </div>
                  <div className="grid gap-4 xl:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
                    <RiskSummary prediction={manualPrediction} thresholds={manualPrediction.thresholds ?? thresholds} />
                    <RiskFactors prediction={manualPrediction} />
                  </div>
                </div>
              ) : null}

              {analysis ? (
                <div className="animate-fade-up space-y-4">
                  <ResultBanner analysis={analysis} />
                  <div className="grid gap-4 xl:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
                    <RiskSummary
                      prediction={analysis.prediction}
                      thresholds={analysis.thresholds}
                      completeness={analysis.data_completeness}
                      warnings={analysis.warnings}
                      timings={analysis.timings_ms}
                      modelInfo={analysis.model_info}
                    />
                    <RiskFactors prediction={analysis.prediction} features={analysis.features} />
                  </div>
                  <CodeFindings analysis={analysis.code_analysis} />
                  <div className="grid gap-4 xl:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
                    <ChangedFiles change={analysis.change} files={analysis.changed_files} />
                    <div className="space-y-4">
                      <CommitDetails
                        change={analysis.change}
                        source={analysis.source}
                        repository={analysis.repository}
                        generatedAt={analysis.generated_at}
                      />
                      <ReviewChecklist items={analysis.review_checklist} />
                    </div>
                  </div>
                </div>
              ) : null}

              {!analysis && !manualPrediction && !loading && !manualLoading && !error && !manualError ? <EmptyState /> : null}
            </div>
          </section>

          <section id="methodology" className="mt-12 scroll-mt-24" aria-labelledby="methodology-title">
            <MethodologyPanel modelInfo={modelInfo} backendOnline={Boolean(health)} />
          </section>
        </div>
      </main>

      <Footer />
    </div>
  );
}
