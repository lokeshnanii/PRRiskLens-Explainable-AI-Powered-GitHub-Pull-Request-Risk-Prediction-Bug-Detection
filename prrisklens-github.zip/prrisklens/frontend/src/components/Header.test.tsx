import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import Header from "./Header";
import type { GitHubRateLimitResponse, HealthResponse } from "../types/analysis";

const health: HealthResponse = {
  status: "ok",
  model_available: true,
  model_version: "xgboost-test",
  model_type: "xgboost",
  feature_schema_version: "1.0.0",
  reason: null,
  time: "2026-11-01T10:00:00Z",
  github: {
    authenticated: true,
    mode: "authenticated",
    token_configured: true,
    expected_hourly_limit: 5000,
    note: null,
  },
};

function renderHeader(rateLimit: GitHubRateLimitResponse | null, loading = false) {
  return render(
    <Header
      health={health}
      healthLoading={false}
      onRefreshHealth={vi.fn()}
      rateLimit={rateLimit}
      rateLimitLoading={loading}
      onRefreshRateLimit={vi.fn()}
    />,
  );
}

describe("Header GitHub quota", () => {
  it("shows the remaining authenticated quota", () => {
    renderHeader({
      authenticated: true,
      mode: "authenticated",
      token_configured: true,
      expected_hourly_limit: 5000,
      note: null,
      rate_limit: {
        authenticated: true,
        mode: "authenticated",
        limit: 5000,
        remaining: 4987,
        used: 13,
        reset_at: "2026-11-01T11:00:00Z",
        near_limit: false,
      },
      error: null,
      time: "2026-11-01T10:00:00Z",
    });

    const quota = screen.getByRole("button", { name: /refresh github api quota/i });
    expect(quota).toHaveTextContent("4,987/5,000");
    expect(quota).toHaveTextContent("token");
    expect(quota).toHaveAttribute("title", expect.stringContaining("Authenticated GitHub quota"));
    expect(quota).toHaveAttribute("title", expect.stringContaining("4,987 of 5,000"));
  });

  it("shows public mode when the backend has no token", () => {
    renderHeader({
      authenticated: false,
      mode: "unauthenticated",
      token_configured: false,
      expected_hourly_limit: 60,
      note: null,
      rate_limit: {
        authenticated: false,
        mode: "unauthenticated",
        limit: 60,
        remaining: 59,
        used: 1,
        reset_at: "2026-11-01T11:00:00Z",
        near_limit: false,
      },
      error: null,
      time: "2026-11-01T10:00:00Z",
    });

    const quota = screen.getByRole("button", { name: /refresh github api quota/i });
    expect(quota).toHaveTextContent("59/60");
    expect(quota).toHaveTextContent("public");
    expect(quota).toHaveAttribute("title", expect.stringContaining("Unauthenticated GitHub quota"));
  });

  it("explains a rejected token instead of inventing quota numbers", () => {
    renderHeader({
      authenticated: true,
      mode: "authenticated",
      token_configured: true,
      expected_hourly_limit: 5000,
      note: null,
      rate_limit: null,
      error: {
        code: "github_unauthorized",
        message: "GitHub rejected the configured GITHUB_TOKEN (401).",
      },
      time: "2026-11-01T10:00:00Z",
    });

    const quota = screen.getByRole("button", { name: /refresh github api quota/i });
    expect(quota).toHaveTextContent("Token rejected");
    expect(quota).toHaveAttribute("title", expect.stringContaining("GitHub rejected"));
  });

  it("marks a nearly exhausted quota", () => {
    renderHeader({
      authenticated: true,
      mode: "authenticated",
      token_configured: true,
      expected_hourly_limit: 5000,
      note: null,
      rate_limit: {
        authenticated: true,
        mode: "authenticated",
        limit: 5000,
        remaining: 12,
        used: 4988,
        reset_at: "2026-11-01T11:00:00Z",
        near_limit: true,
      },
      error: null,
      time: "2026-11-01T10:00:00Z",
    });

    const quota = screen.getByRole("button", { name: /refresh github api quota/i });
    expect(quota).toHaveTextContent("12/5,000");
    expect(quota.className).toContain("text-rose-200");
  });
});
